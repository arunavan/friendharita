package com.zeronorth.util;

public class ResponseUtils {

    public static final String DEFAULT_PAGE_NUM = "0" ;
    public static final String DEFAULT_PAGE_SIZE = "10" ;

}
