package com.zeronorth.model;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "batch3redisemployees")
//@Getter
//@Setter
//@ToString
//@NoArgsConstructor
public class Employee extends BaseEntity{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
    Integer id;
    private String name;
    private int age;
    private Double salary;
    
  //  public Integer getId() {
	//	return id;
	//}
	public void setId(Integer id) {
		this.id = id;
	}
	Employee() {}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + ", salary=" + salary + "]";
	}
    

}
