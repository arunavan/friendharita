package com.zeronorth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMysqlRedisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMysqlRedisApplication.class, args);
	}

}
