-- CREATE VIEWS FOR MPA PUBLISH JOBS
--DELIVERY JOBS
-- QUERY
SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, bdn.bmt_number as bmt_number, job.bdn_party_name as supplier_name, bdnparty.registration_no as bunker_supplier_uen, bdn.bdn_number, bdn.vessel_name, bdn.vessel_imo,
bdn.gross_tonnage, location.code, location.name, '1' as delivery_type, "I" as supply_type, grade.code as fuel_type_code, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, ocr.delivered as mfm_supplied_quantity, 
bdn.quantity_supplied as bdn_supplied_quantity, date(bdn.commenced_pumping_start) as operation_date, bdn.commenced_pumping_start as commence_pumping_time, bdn.commenced_pumping_stop as complete_pumping_time, 
bdn.vessel_along_side as alongside_time, timelog_details.date_time as castoff_time, TIMEDIFF(bdn.commenced_pumping_stop , bdn.commenced_pumping_start) as duration_of_delivery, bdn.note_of_protest_issued as protest_note, 
bdn.customer_feedback as customer_rating, 'Y' as totalisersAutoPopulated, mpa_publish_status, mpa_publish_error_msg, mpa_publish_response, 
bdn.bdn_file_binary, job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id

from jobs job, bdn_parties bdnparty, bdn_data bdn, location, grade, mfm_reading_data mfm, timelog_data timelog, timelog_checklist_items timelog_details, ocr_result ocr

where job.status="COMPLETED" and (job.mpa_publish_status!='PUBLISHED' OR job.mpa_publish_status is null)
and job.job_type='delivery' 
and job.id=bdn.job_id
and job.id=ocr.job_id
and job.bdn_party_id=bdnparty.id
and SUBSTRING_INDEX(bdn.location, '-',1)=location.code 
and grade.name=bdn.fuel_supply_first
and mfm.job_id = job.id 
and timelog.job_id = job.id 
and timelog.id = timelog_details.timelogChecklist_id 
and timelog_details.item_name='Barge Left Location / Anchorage / Terminal'
group by job.id

--VIEW
drop view if exists mpa_jobs_delivery_v2;
CREATE VIEW mpa_jobs_delivery_v2 as (
SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, bdn.bmt_number as bmt_number, job.bdn_party_name as supplier_name, bdnparty.registration_no as bunker_supplier_uen, bdn.bdn_number, bdn.vessel_name, bdn.vessel_imo,
bdn.gross_tonnage, location.code, location.name, '1' as delivery_type, "I" as supply_type, grade.code as fuel_type_code, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, ocr.delivered as mfm_supplied_quantity, 
bdn.quantity_supplied as bdn_supplied_quantity, date(bdn.commenced_pumping_start) as operation_date, bdn.commenced_pumping_start as commence_pumping_time, bdn.commenced_pumping_stop as complete_pumping_time, 
bdn.vessel_along_side as alongside_time, timelog_details.date_time as castoff_time, TIMEDIFF(bdn.commenced_pumping_stop , bdn.commenced_pumping_start) as duration_of_delivery, bdn.note_of_protest_issued as protest_note, 
bdn.customer_feedback as customer_rating, 'Y' as totalisersAutoPopulated, mpa_publish_status, mpa_publish_error_msg, mpa_publish_response, 
bdn.bdn_file_binary, job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id

from jobs job, bdn_parties bdnparty, bdn_data bdn, location, grade, mfm_reading_data mfm, timelog_data timelog, timelog_checklist_items timelog_details, ocr_result ocr

where job.status="COMPLETED" and (job.mpa_publish_status!='PUBLISHED' OR job.mpa_publish_status is null)
and job.job_type='delivery' 
and job.id=bdn.job_id
and job.id=ocr.job_id
and job.bdn_party_id=bdnparty.id
and SUBSTRING_INDEX(bdn.location, '-',1)=location.code 
and grade.name=bdn.fuel_supply_first
and mfm.job_id = job.id 
and timelog.job_id = job.id 
and timelog.id = timelog_details.timelogChecklist_id 
and timelog_details.item_name='Barge Left Location / Anchorage / Terminal'
group by job.id
);



------------------------------------------------------------------------------------------------
--LOADING JOBS
------------------------------------------------------------------------------------------------


SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, mfm.bmt_number as bmt_number,
bol.bl_no as loadNo, location.code, location.name, '1' as loadType, grade.code as fuel_type_code, 
bol.bl_qty as agreedLoadQuantity, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, bol.bl_qty as coq_quanity, ocr.delivered as mfm_quantity,
"1" as load_type, date(bol.commenced_loading_datetime) as operation_date, bol.commenced_loading_datetime as commence_pumping_time, bol.completed_loading_datetime as complete_pumping_time, 
bol.barge_arrived_location_datetime as berthingTime, bol.barge_left_location_datetime as departureTime, TIMEDIFF(bol.completed_loading_datetime , bol.commenced_loading_datetime) as duration_of_delivery, 
TIMEDIFF(bol.barge_left_location_datetime , bol.barge_arrived_location_datetime) as durationAlongsideBerth, 
 'N' as totalisersAutoPopulated, 'Others' as reason_not_auto_populated, mpa_publish_status, mpa_publish_error_msg, mpa_publish_response, 
job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id 

from jobs job, cargo_loading_data bol, location, grade, mfm_reading_data mfm, ocr_result ocr 

where job.status="COMPLETED" and (job.mpa_publish_status!='PUBLISHED' OR job.mpa_publish_status is null)
and job.job_type='loading' 
and job.id=bol.job_id
and job.id=ocr.job_id
and SUBSTRING_INDEX(bol.location_name, '-',1)=location.code 
and grade.name=bol.grade
and mfm.job_id = job.id 
group by job.id;

---VIEW
---------

drop view if exists mpa_jobs_loading_v2;
CREATE VIEW mpa_jobs_loading_v2 as (
SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, mfm.bmt_number as bmt_number,
bol.bl_no as loadNo, location.code, location.name, '1' as loadType, grade.code as fuel_type_code, 
bol.bl_qty as agreedLoadQuantity, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, bol.bl_qty as coq_quanity, ocr.delivered as mfm_quantity,
"1" as load_type, date(bol.commenced_loading_datetime) as operation_date, bol.commenced_loading_datetime as commence_pumping_time, bol.completed_loading_datetime as complete_pumping_time, 
bol.barge_arrived_location_datetime as berthingTime, bol.barge_left_location_datetime as departureTime, TIMEDIFF(bol.completed_loading_datetime , bol.commenced_loading_datetime) as duration_of_delivery, 
TIMEDIFF(bol.barge_left_location_datetime , bol.barge_arrived_location_datetime) as durationAlongsideBerth, 
 'N' as totalisersAutoPopulated, 'Others' as reason_not_auto_populated, mpa_publish_status, mpa_publish_error_msg, mpa_publish_response, 
job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id 

from jobs job, cargo_loading_data bol, location, grade, mfm_reading_data mfm, ocr_result ocr 

where job.status="COMPLETED" and (job.mpa_publish_status!='PUBLISHED' OR job.mpa_publish_status is null)
and job.job_type='loading' 
and job.id=bol.job_id
and job.id=ocr.job_id
and SUBSTRING_INDEX(bol.location_name, '-',1)=location.code 
and grade.name=bol.grade
and mfm.job_id = job.id 
group by job.id
);


------------------------------------------------------------------------------------------------
--TRANSFER-OUT JOBS
------------------------------------------------------------------------------------------------

--QUERY
-------

SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, mfm.bmt_number as bmt_number, 
barge.name as receiving_barge_name, barge.sb_number as receiveBunkerTankerLicenceNo, job.bdn_party_name as supplier_name, mfm.bdn_number, location.code, location.name, '1' as delivery_type, "I" as supply_type, grade.code as fuel_type_code, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, ocr.delivered as mfm_supplied_quantity, 
transfer.supply_mfm_fig as bdn_supplied_quantity, 

transfer.transfer_commenced as commence_pumping_time, transfer.transfer_completed as complete_pumping_time, 
transfer.barge_arrived_location_datetime as berthingTime, transfer.barge_left_location_datetime as departureTime, TIMEDIFF(transfer.transfer_completed , transfer.transfer_commenced) as duration_of_delivery, 
TIMEDIFF(transfer.barge_left_location_datetime , transfer.barge_arrived_location_datetime) as durationAlongsideBerth, 
 'N' as totalisersAutoPopulated, 'Others' as reason_not_auto_populated, 
 date(transfer.transfer_commenced) as operation_date, 
mpa_publish_status, mpa_publish_error_msg, mpa_publish_response, job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id

from jobs job, location, grade, mfm_reading_data mfm, timelog_data timelog, timelog_checklist_items timelog_details, bunker_transfer_data transfer, barge, ocr_result ocr

where job.status ="COMPLETED" and (job.mpa_publish_status !='PUBLISHED'  OR job.mpa_publish_status is null)
and job.job_type ='transfer_out' 
and job.id=ocr.job_id
and mfm.job_id=job.id
and SUBSTRING_INDEX(transfer.location_of_transfer, '-',1) =location.code 
and grade.name =SUBSTRING_INDEX(transfer.product, '/',1)
and barge.name COLLATE utf8_unicode_ci = transfer.receiving_bunker_tanker COLLATE utf8_unicode_ci
and transfer.job_id=job.id
group by job.id;


---VIEW
---------



drop view if exists mpa_jobs_transfer_out_v2;

CREATE VIEW mpa_jobs_transfer_out_v2 as (
SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, mfm.bmt_number as bmt_number, 
barge.name as receiving_barge_name, barge.sb_number as receiveBunkerTankerLicenceNo, job.bdn_party_name as supplier_name, mfm.bdn_number, location.code, location.name, '1' as delivery_type, "I" as supply_type, grade.code as fuel_type_code, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, ocr.delivered as mfm_supplied_quantity, 
transfer.supply_mfm_fig as bdn_supplied_quantity, 

transfer.transfer_commenced as commence_pumping_time, transfer.transfer_completed as complete_pumping_time, 
transfer.barge_arrived_location_datetime as berthingTime, transfer.barge_left_location_datetime as departureTime, TIMEDIFF(transfer.transfer_completed , transfer.transfer_commenced) as duration_of_delivery, 
TIMEDIFF(transfer.barge_left_location_datetime , transfer.barge_arrived_location_datetime) as durationAlongsideBerth, 
 'N' as totalisersAutoPopulated, 'Others' as reason_not_auto_populated, 
 date(transfer.transfer_commenced) as operation_date, 
mpa_publish_status, mpa_publish_error_msg, mpa_publish_response, job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id

from jobs job, location, grade, mfm_reading_data mfm, timelog_data timelog, timelog_checklist_items timelog_details, bunker_transfer_data transfer, barge, ocr_result ocr

where job.status ="COMPLETED" and (job.mpa_publish_status !='PUBLISHED'  OR job.mpa_publish_status is null)
and job.job_type ='transfer_out' 
and job.id=ocr.job_id
and mfm.job_id=job.id
and SUBSTRING_INDEX(transfer.location_of_transfer, '-',1) =location.code 
and grade.name =SUBSTRING_INDEX(transfer.product, '/',1)
and barge.name COLLATE utf8_unicode_ci = transfer.receiving_bunker_tanker COLLATE utf8_unicode_ci
and transfer.job_id=job.id
group by job.id
);

