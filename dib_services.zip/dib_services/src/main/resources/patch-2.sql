-- CREATE VIEWS FOR BUNKER DATA PUBLISH JOBS
--DELIVERY JOBS
-- QUERY
SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, bdn.bmt_number as bmt_number, job.bdn_party_name as supplier_name, bdnparty.registration_no as bunker_supplier_uen, bdn.bdn_number, bdn.vessel_name, bdn.vessel_imo,
bdn.gross_tonnage, location.code, location.name, '1' as delivery_type, "I" as supply_type, grade.code as fuel_type_code, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, mfm.quantity_supplied as mfm_supplied_quantity, 
bdn.quantity_supplied as bdn_supplied_quantity, date(bdn.commenced_pumping_start) as operation_date, bdn.commenced_pumping_start as commence_pumping_time, bdn.commenced_pumping_stop as complete_pumping_time, 
bdn.vessel_along_side as alongside_time, timelog_details.date_time as castoff_time, TIMEDIFF(bdn.commenced_pumping_stop , bdn.commenced_pumping_start) as duration_of_delivery, bdn.note_of_protest_issued as protest_note, 
bdn.customer_feedback as customer_rating, 'N' as totalisersAutoPopulated, 'Others' as reason_not_auto_populated, 
barge.sgtradex_id, barge.sgtradex_name, barge.sgtradex_data_ref_id, barge.sgtradex_vendor_uen, barge.sgtradex_on_behalf_of_id,
bdn.bdn_file_binary, job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id, mpa_publish_status, mpa_publish_error_msg, mpa_publish_response,
sgtradex_publish_status, sgtradex_publish_error_msg, sgtradex_publish_response


from jobs job, bdn_parties bdnparty, bdn_data bdn, location, grade, mfm_reading_data mfm, timelog_data timelog, timelog_checklist_items timelog_details, barge

where job.status="COMPLETED" and (job.sgtradex_publish_status!='PUBLISHED' OR job.sgtradex_publish_status is null)
and job.job_type='delivery' 
and job.id=bdn.job_id
and job.barge_id = barge.id
and job.bdn_party_id=bdnparty.id
and SUBSTRING_INDEX(bdn.location, '-',1)=location.code 
and grade.name=bdn.fuel_supply_first	
and mfm.job_id = job.id 
and timelog.job_id = job.id 
and timelog.id = timelog_details.timelogChecklist_id 
and timelog_details.item_name='Barge Left Location / Anchorage'
group by job.id


--VIEW
drop view if exists bunker_data_publish_delivery;
CREATE VIEW bunker_data_publish_delivery as (
SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, bdn.bmt_number as bmt_number, job.bdn_party_name as supplier_name, bdnparty.registration_no as bunker_supplier_uen, bdn.bdn_number, bdn.vessel_name, bdn.vessel_imo,
bdn.gross_tonnage, location.code, location.name, '1' as delivery_type, "I" as supply_type, grade.code as fuel_type_code, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, mfm.quantity_supplied as mfm_supplied_quantity, 
bdn.quantity_supplied as bdn_supplied_quantity, date(bdn.commenced_pumping_start) as operation_date, bdn.commenced_pumping_start as commence_pumping_time, bdn.commenced_pumping_stop as complete_pumping_time, 
bdn.vessel_along_side as alongside_time, timelog_details.date_time as castoff_time, TIMEDIFF(bdn.commenced_pumping_stop , bdn.commenced_pumping_start) as duration_of_delivery, bdn.note_of_protest_issued as protest_note, 
bdn.customer_feedback as customer_rating, 'N' as totalisersAutoPopulated, 'Others' as reason_not_auto_populated, 
barge.sgtradex_id, barge.sgtradex_name, barge.sgtradex_data_ref_id, barge.sgtradex_vendor_uen, barge.sgtradex_on_behalf_of_id,
bdn.bdn_file_binary, job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id, mpa_publish_status, mpa_publish_error_msg, mpa_publish_response,
sgtradex_publish_status, sgtradex_publish_error_msg, sgtradex_publish_response


from jobs job, bdn_parties bdnparty, bdn_data bdn, location, grade, mfm_reading_data mfm, timelog_data timelog, timelog_checklist_items timelog_details, barge

where job.status="COMPLETED" and (job.sgtradex_publish_status!='PUBLISHED' OR job.sgtradex_publish_status is null)
and job.job_type='delivery' 
and job.id=bdn.job_id
and job.barge_id = barge.id
and job.bdn_party_id=bdnparty.id
and SUBSTRING_INDEX(bdn.location, '-',1)=location.code 
and grade.name=bdn.fuel_supply_first	
and mfm.job_id = job.id 
and timelog.job_id = job.id 
and timelog.id = timelog_details.timelogChecklist_id 
and timelog_details.item_name='Barge Left Location / Anchorage'
group by job.id
);



------------------------------------------------------------------------------------------------
--LOADING JOBS
------------------------------------------------------------------------------------------------


SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, mfm.bmt_number as bmt_number,
bol.bl_no as loadNo, location.code, location.name, '1' as loadType, grade.code as fuel_type_code, 
bol.bl_qty as agreedLoadQuantity, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, bol.bl_qty as coq_quanity, bol.mfm_qty as mfm_quantity,
"1" as load_type, date(bol.commenced_loading_datetime) as operation_date, bol.commenced_loading_datetime as commence_pumping_time, bol.completed_loading_datetime as complete_pumping_time, 
bol.barge_arrived_location_datetime as berthingTime, bol.barge_left_location_datetime as departureTime, TIMEDIFF(bol.completed_loading_datetime , bol.commenced_loading_datetime) as duration_of_delivery, 
TIMEDIFF(bol.barge_left_location_datetime , bol.barge_arrived_location_datetime) as durationAlongsideBerth, 
 'N' as totalisersAutoPopulated, 'Others' as reason_not_auto_populated, 
barge.sgtradex_id, barge.sgtradex_name, barge.sgtradex_data_ref_id, barge.sgtradex_vendor_uen, barge.sgtradex_on_behalf_of_id,
mpa_publish_status, mpa_publish_error_msg, mpa_publish_response,
 sgtradex_publish_status, sgtradex_publish_error_msg, sgtradex_publish_response,
job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id 

from jobs job, cargo_loading_data bol, location, grade, mfm_reading_data mfm, barge

where job.status="COMPLETED" and (job.sgtradex_publish_status!='PUBLISHED' OR job.sgtradex_publish_status is null)
and job.job_type='loading' 
and job.id=bol.job_id
and job.barge_id = barge.id
and SUBSTRING_INDEX(bol.location_name, '-',1)=location.code 
and grade.name=bol.grade
and mfm.job_id = job.id 
group by job.id;

---VIEW
---------

drop view if exists bunker_data_publish_loading;
CREATE VIEW bunker_data_publish_loading as (

SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, mfm.bmt_number as bmt_number,
bol.bl_no as loadNo, location.code, location.name, '1' as loadType, grade.code as fuel_type_code, 
bol.bl_qty as agreedLoadQuantity, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, bol.bl_qty as coq_quanity, bol.mfm_qty as mfm_quantity,
"1" as load_type, date(bol.commenced_loading_datetime) as operation_date, bol.commenced_loading_datetime as commence_pumping_time, bol.completed_loading_datetime as complete_pumping_time, 
bol.barge_arrived_location_datetime as berthingTime, bol.barge_left_location_datetime as departureTime, TIMEDIFF(bol.completed_loading_datetime , bol.commenced_loading_datetime) as duration_of_delivery, 
TIMEDIFF(bol.barge_left_location_datetime , bol.barge_arrived_location_datetime) as durationAlongsideBerth, 
 'N' as totalisersAutoPopulated, 'Others' as reason_not_auto_populated, 
barge.sgtradex_id, barge.sgtradex_name, barge.sgtradex_data_ref_id, barge.sgtradex_vendor_uen, barge.sgtradex_on_behalf_of_id,
mpa_publish_status, mpa_publish_error_msg, mpa_publish_response,
 sgtradex_publish_status, sgtradex_publish_error_msg, sgtradex_publish_response,
job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id 

from jobs job, cargo_loading_data bol, location, grade, mfm_reading_data mfm, barge

where job.status="COMPLETED" and (job.sgtradex_publish_status!='PUBLISHED' OR job.sgtradex_publish_status is null)
and job.job_type='loading' 
and job.id=bol.job_id
and job.barge_id = barge.id
and SUBSTRING_INDEX(bol.location_name, '-',1)=location.code 
and grade.name=bol.grade
and mfm.job_id = job.id 
group by job.id
);


------------------------------------------------------------------------------------------------
--TRANSFER-OUT JOBS
------------------------------------------------------------------------------------------------

--QUERY
-------

SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, bdn.bmt_number as bmt_number, 
barge.name as receiving_barge_name, barge.sb_number as receiveBunkerTankerLicenceNo, job.bdn_party_name as supplier_name, bdn.bdn_number, location.code, location.name, '1' as delivery_type, "I" as supply_type, grade.code as fuel_type_code, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, mfm.quantity_supplied as mfm_supplied_quantity, 
bdn.quantity_supplied as bdn_supplied_quantity, 

transfer.transfer_commenced as commence_pumping_time, transfer.transfer_completed as complete_pumping_time, 
transfer.barge_arrived_location_datetime as berthingTime, transfer.barge_left_location_datetime as departureTime, TIMEDIFF(transfer.transfer_completed , transfer.transfer_commenced) as duration_of_delivery, 
TIMEDIFF(transfer.barge_left_location_datetime , transfer.barge_arrived_location_datetime) as durationAlongsideBerth, 
 'N' as totalisersAutoPopulated, 'Others' as reason_not_auto_populated, 
 date(transfer.transfer_commenced) as operation_date, bdn.note_of_protest_issued as protest_note, 
barge.sgtradex_id, barge.sgtradex_name, barge.sgtradex_data_ref_id, barge.sgtradex_vendor_uen, barge.sgtradex_on_behalf_of_id,
mpa_publish_status, mpa_publish_error_msg, mpa_publish_response, 
 sgtradex_publish_status, sgtradex_publish_error_msg, sgtradex_publish_response,
bdn.bdn_file_binary, job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id

from jobs job, bdn_data bdn, location, grade, mfm_reading_data mfm, bunker_transfer_data transfer, barge

where job.status ="COMPLETED" and (job.sgtradex_publish_status !='PUBLISHED'  OR job.sgtradex_publish_status is null)
and job.job_type ='transfer_out' 
and job.id =bdn.job_id
and job.barge_id = barge.id
and mfm.job_id=job.id
and SUBSTRING_INDEX(bdn.location, '-',1) =location.code 
and grade.name =bdn.fuel_supply_first
and barge.name = transfer.supplying_bunker_tanker
and transfer.job_id=job.id
group by job.id


---VIEW
---------



drop view if exists bunker_data_publish_transfer_out;

CREATE VIEW bunker_data_publish_transfer_out as (
SELECT job.id, job.job_type, job.barge_licence_no, job.barge_name, bdn.bmt_number as bmt_number, 
barge.name as receiving_barge_name, barge.sb_number as receiveBunkerTankerLicenceNo, job.bdn_party_name as supplier_name, bdn.bdn_number, location.code, location.name, '1' as delivery_type, "I" as supply_type, grade.code as fuel_type_code, mfm.delivery_totaliser_reading_a as start_delivery_meter_totaliser, 
mfm.loading_totaliser_reading_x as start_loading_meter_totaliser, mfm.delivery_totaliser_reading_b as end_delivery_meter_totaliser, mfm.loading_totaliser_reading_y as end_loading_meter_totaliser, mfm.quantity_supplied as mfm_supplied_quantity, 
bdn.quantity_supplied as bdn_supplied_quantity, 

transfer.transfer_commenced as commence_pumping_time, transfer.transfer_completed as complete_pumping_time, 
transfer.barge_arrived_location_datetime as berthingTime, transfer.barge_left_location_datetime as departureTime, TIMEDIFF(transfer.transfer_completed , transfer.transfer_commenced) as duration_of_delivery, 
TIMEDIFF(transfer.barge_left_location_datetime , transfer.barge_arrived_location_datetime) as durationAlongsideBerth, 
 'N' as totalisersAutoPopulated, 'Others' as reason_not_auto_populated, 
 date(transfer.transfer_commenced) as operation_date, bdn.note_of_protest_issued as protest_note, 
barge.sgtradex_id, barge.sgtradex_name, barge.sgtradex_data_ref_id, barge.sgtradex_vendor_uen, barge.sgtradex_on_behalf_of_id,
mpa_publish_status, mpa_publish_error_msg, mpa_publish_response, 
 sgtradex_publish_status, sgtradex_publish_error_msg, sgtradex_publish_response,
bdn.bdn_file_binary, job.blockchain_registration_status, job.blockchain_registration_error_msg, job.blockchain_registration_response, blockchain_file_id

from jobs job, bdn_data bdn, location, grade, mfm_reading_data mfm, bunker_transfer_data transfer, barge

where job.status ="COMPLETED" and (job.sgtradex_publish_status !='PUBLISHED'  OR job.sgtradex_publish_status is null)
and job.job_type ='transfer_out' 
and job.id =bdn.job_id
and job.barge_id = barge.id
and mfm.job_id=job.id
and SUBSTRING_INDEX(bdn.location, '-',1) =location.code 
and grade.name =bdn.fuel_supply_first
and barge.name = transfer.supplying_bunker_tanker
and transfer.job_id=job.id
group by job.id
);

