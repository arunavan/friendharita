-- adding ADMIN, SURVEYOR, WORKING_SURVEYOR roles


INSERT INTO role (id, role)
SELECT * FROM (SELECT 0,  'ADMIN') AS tmp
WHERE NOT EXISTS (
    SELECT role FROM role WHERE role = 'ADMIN'
) LIMIT 1;


INSERT INTO role (id, role)
SELECT * FROM (SELECT 0, 'MANAGER') AS tmp
WHERE NOT EXISTS (
    SELECT role FROM role WHERE role = 'MANAGER'
) LIMIT 1;


INSERT INTO role (id, role)
SELECT * FROM (SELECT 0, 'CARGO OFFICER') AS tmp
WHERE NOT EXISTS (
    SELECT role FROM role WHERE role = 'CARGO OFFICER'
) LIMIT 1;


INSERT INTO role (id, role)
SELECT * FROM (SELECT 0, 'CHIEF ENGINEER') AS tmp
WHERE NOT EXISTS (
    SELECT role FROM role WHERE role = 'CHIEF ENGINEER'
) LIMIT 1;

-- End roles

-- ADMIN User Add

SET @account_enabled = 1, 
	@account_expired = 0, 
	@account_locked = 0, 
	@created_date = SYSDATE(), 
	@email = 'admin@dib.com', 
	@first_name = 'admin', 
	@last_name = 'admin', 
	@password = '$2a$10$cFTz2a7lLrtgbygczPm9oeYOdJN.baX6k0VdvXCwIUpMmMyGxWJqa', 
	@phone_number = '123456789' , 
	@updated_date = SYSDATE(), 
	@updated_by = NULL;
INSERT INTO user
    (account_enabled,account_expired,account_locked,created_date,email,first_name,last_name, 
	PASSWORD,phone_number,updated_date,updated_by)
VALUES
    (@account_enabled,@account_expired,@account_locked,@created_date,@email,@first_name,@last_name, 
	@password, @phone_number,@updated_date,@updated_by)
ON DUPLICATE KEY UPDATE

account_enabled = @account_enabled, 
account_expired = @account_expired, 
account_locked = @account_locked, 
created_date = @created_date, 
email = @email, 
first_name = @first_name, 
last_name = @last_name, 
PASSWORD = @password, 
phone_number = @phone_number, 
updated_date = @updated_date, 
updated_by =	@updated_by;


-- user role map

SET @user_id = (SELECT id FROM user WHERE email = 'admin@dib.com' LIMIT 1),
@role_id = (SELECT id FROM role WHERE role = 'ADMIN' LIMIT 1); 
INSERT INTO user_role
    (user_id,role_id)
VALUES
    (@user_id,@role_id)
ON DUPLICATE KEY UPDATE
 user_id =  @user_id,
role_id = @role_id; 
