package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.india.bts.dib.domain.NOPData;

public interface NOPDataRepository extends JpaRepository<NOPData, Long> {
	
	NOPData findByJobId(long jobId);

	@Modifying
	@Transactional
	@Query(value="UPDATE note_of_protest_data SET nop_file_binary= :nop_file_binary WHERE job_id = :jobId ", nativeQuery=true)
	void updateBinaryData(@Param("nop_file_binary") String nop_file_binary,@Param("jobId") Long jobId);

	@Modifying
	@Transactional
	@Query(value ="UPDATE note_of_protest_data SET operation_start_hours =:operation_start_hours ,operation_end_hours =:operation_end_hours,nominated_qty=:nominated_qty WHERE job_id = :jobId ", nativeQuery=true)
	void updatePumpingStartEndTimes(@Param("operation_start_hours") String commenced_pumping_start, @Param("operation_end_hours") String commenced_pumping_stop,@Param("nominated_qty") String nominated_qty,
			@Param("jobId") Long jobId);

	//updating signatures to null if any changes made in meterticket
	@Modifying
	@Transactional
	@Query(value ="UPDATE note_of_protest_data SET ce_pre_sign_datetime = null ,co_pre_sign_datetime= null,sur_pre_sign_datetime= null,nop_file_binary=null,"
			+ "CO_Sign=null,CE_Sign=null,SV_Sign=null WHERE job_id = :jobId ", nativeQuery=true)
	void clearDateFields(@Param("jobId") Long jobId);

}
