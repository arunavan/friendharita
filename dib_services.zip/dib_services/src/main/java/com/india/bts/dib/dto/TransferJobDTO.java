package com.india.bts.dib.dto;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.india.bts.dib.domain.JOBTYPE;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
public class TransferJobDTO {
	
	@ApiModelProperty(notes = "specify the jobtype", required = true, example = "loading, delivery, transfer")
	@Enumerated(EnumType.STRING)
    private JOBTYPE jobType;
	
	private long bdnPartyId;

	private TransferOrderDTO transferOrder;
	
	private String client;

}
