package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.india.bts.dib.domain.Location;

public interface LocationRepository extends JpaRepository<Location, Long> {
	
	Location findByName(String name);


}
