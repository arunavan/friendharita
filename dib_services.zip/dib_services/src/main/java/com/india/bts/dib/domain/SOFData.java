package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="sof_data") 
public class SOFData implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6360097131484204215L;
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20)
	private long jobId;
	@Column(nullable=true, name = "date", columnDefinition = "DATE")
	private String date;
	@Column(nullable=true, name = "time", columnDefinition = "TIME")
	private String time;
	@Column(nullable=true, name = "bunker_tanker_name", length=200)
	private String bunkerTankerName;
	@Column(nullable=true, name = "vessel_name", length=200)
	private String vesselName;
	@Column(nullable=true, name = "reference", length=500)
	private String reference;
	@Column(nullable=true, name = "location", length=200)
	private String location;

	
	@Column(nullable=true, name = "cargo_officer_name", length=200)
	private String cargoOfficerName;
	@Column(nullable=true, name = "chief_enineer_name", length=200)
	private String chiefEngineerName;
	@Column(nullable=true, name = "surveyor_name", length=200)
	private String surveyorName;

	@OneToMany(mappedBy="sofData",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private List<SOFQuestion> sofQuestions;
	

	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "cargo_officer_signature_date_time", columnDefinition="DATETIME", nullable = false)
    LocalDateTime cargoOfficerSignatureDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "chief_engineer_signature_date_time", columnDefinition="DATETIME", nullable = false)
    LocalDateTime chiefEngineerSignatureDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "surveyor_signature_date_time", columnDefinition="DATETIME", nullable = true)
    LocalDateTime surveyorSignatureDateTime;

	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	}
