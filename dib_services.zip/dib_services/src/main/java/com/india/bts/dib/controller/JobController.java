package com.india.bts.dib.controller;

import java.io.ByteArrayOutputStream;


import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.EsignTimestamp;
import com.india.bts.dib.domain.File;
import com.india.bts.dib.domain.Attachment;
import com.india.bts.dib.domain.BDNData;
import com.india.bts.dib.domain.BunkerRequisitionData;
import com.india.bts.dib.domain.BunkerSafetyChecklistData;
import com.india.bts.dib.domain.BunkerTransferData;
import com.india.bts.dib.domain.CargoLoadingData;
import com.india.bts.dib.domain.DiscrepancyData;
import com.india.bts.dib.domain.ESignaturesData;
import com.india.bts.dib.domain.EmailContent;
import com.india.bts.dib.domain.JOBTYPE;
import com.india.bts.dib.domain.Job;
import com.india.bts.dib.domain.MFMReadingData;
import com.india.bts.dib.domain.MFMSealsChecklistData;
import com.india.bts.dib.domain.NOPData;
import com.india.bts.dib.domain.Nomination;
import com.india.bts.dib.domain.OcrResult;
import com.india.bts.dib.domain.Sof;
import com.india.bts.dib.domain.StatusType;
import com.india.bts.dib.domain.TaskType;
import com.india.bts.dib.domain.TimelogData;
import com.india.bts.dib.domain.User;
import com.india.bts.dib.domain.UserRole;
import com.india.bts.dib.dto.PurchaseJobDTO;
import com.india.bts.dib.dto.PurchaseJobUpdateDTO;
import com.india.bts.dib.dto.SalesJobDTO;
import com.india.bts.dib.dto.SalesJobUpdateDTO;
import com.india.bts.dib.dto.TransferJobDTO;
import com.india.bts.dib.dto.TransferJobUpdateDTO;
import com.india.bts.dib.repository.AttachmentRepository;
import com.india.bts.dib.repository.BDNDataRepository;
import com.india.bts.dib.repository.BDNPartyRepository;
import com.india.bts.dib.repository.BunkerRequistionRepository;
import com.india.bts.dib.repository.BunkerSafetyChecklistRepository;
import com.india.bts.dib.repository.DBFileRepository;
import com.india.bts.dib.repository.JobRepository;
import com.india.bts.dib.repository.MFMReadingDataRepository;
import com.india.bts.dib.repository.MFMSealChecklistRepository;
import com.india.bts.dib.repository.MFMSealsChecklistRepository;
import com.india.bts.dib.repository.NOPDataRepository;
import com.india.bts.dib.repository.UserRepository;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.service.AsynServices;
import com.india.bts.dib.service.DBFileServiceImpl;
import com.india.bts.dib.service.FileStorageService;
import com.india.bts.dib.service.JobService;
import com.india.bts.dib.service.JobServiceImpl;
import com.india.bts.dib.service.MailContentBuilder;
import com.india.bts.dib.service.RestService;
import com.india.bts.dib.utils.Constants;
import com.india.bts.dib.utils.InvalidEmailException;
import com.india.bts.dib.utils.ResponseObject;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

@RestController
@Slf4j
@EnableAsync
public class JobController {

	@Autowired
	JobServiceImpl jobService;
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	RestService restService;
	@Autowired
	CurrentUserService currentUserService;
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	DBFileRepository dbFileRepository;
	
	@Autowired
	JavaMailSender mailSender;
	
	@Autowired
	BDNPartyRepository bdnPartyRepository;
	
	@Autowired
	BunkerRequistionRepository bunkerRequistionRepository;
	
	@Autowired
	MFMSealsChecklistRepository mfmSealsChecklistRepository;
	
	@Autowired
	MFMReadingDataRepository mfmReadingRepository;
	
	@Autowired
	BunkerSafetyChecklistRepository bunkerSafetyChecklistRepository;
	
	@Autowired
	JobRepository jobRepository;
	
	
	@Autowired
	FileStorageService fileService;
	
	@Autowired
	AttachmentRepository attachmentRepository;
	
	@Autowired
	AsynServices asynServices;
	@Autowired
	BDNDataRepository bdnDataRepository;
	@Autowired
	MFMSealChecklistRepository mFMSealChecklistRepository;
	
	@Autowired
	NOPDataRepository nOPDataRepository;
	@Autowired
	DocumentController documentcontroller;
	@Autowired
	MailContentBuilder mailContentBuilder;
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/transfer", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createTransferJob(@RequestBody TransferJobDTO trasferJob) {
		Job postRequest = null;
		try {
			
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "CARGO OFFICER" })) {
//					if (!currentUserService.getCurrentUser().getBargeId()
//							.equals(trasferJob.getTransferOrder().getBargeId())) {
//						return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//								HttpStatus.FORBIDDEN);
//					}
//				} else {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);	
//				
//				}
//			}
			postRequest = modelMapper.map(trasferJob.getTransferOrder(), Job.class);
			postRequest.setJobType(trasferJob.getJobType());
			if(trasferJob.getTransferOrder().getSourceType()==null && trasferJob.getTransferOrder().getIs_Updated()==1){
				postRequest.setSourceType("eBDN");
				}
			postRequest.setId(null);
			
			System.out.println("TrasOrdeNo:"+ postRequest.getTransferOrderNo() );
			System.out.println("TrasOrdeNo:"+ postRequest.getJobType() );

			// Try override the exising job if transferorder already exists
			Job existingJob = jobService.findByTransferOrderNoAndJobType(postRequest.getTransferOrderNo(),postRequest.getJobType() );
			if(existingJob != null) {
				postRequest.setId(existingJob.getId());
				postRequest.setStatus(existingJob.getStatus());
				postRequest = jobService.updateJob(postRequest);

			}else {
				postRequest = jobService.createJob(postRequest);
			}
	
		} catch (Exception e) {
			log.error("Unable to add job", e);
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(postRequest, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/transfer", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateTransferJob(@RequestBody TransferJobUpdateDTO trasferJob) {
		Job postRequest = null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "CARGO OFFICER" })) {
//					if (!currentUserService.getCurrentUser().getBargeId()
//							.equals(trasferJob.getTransferOrder().getBargeId())) {
//						return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//								HttpStatus.FORBIDDEN);
//					}
//				} else {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);	
//				
//				}
//			}
			postRequest = modelMapper.map(trasferJob.getTransferOrder(), Job.class);
			postRequest.setJobType(trasferJob.getJobType());
			postRequest.setStatus(trasferJob.getStatus());
			postRequest.setId(trasferJob.getId());
			if(trasferJob.getTransferOrder().getSourceType()==null && trasferJob.getTransferOrder().getIs_Updated()==1){
				postRequest.setSourceType("eBDN");
				}
			postRequest = jobService.updateJob(postRequest);

		} catch (Exception e) {
			log.error("Unable to add job", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(postRequest, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/delivery", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createSalesOrder(@RequestBody SalesJobDTO salesJob) {
		Job postRequest = null;
		Nomination nomination =null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "CARGO OFFICER" })) {
//					if (!currentUserService.getCurrentUser().getBargeId()
//							.equals(salesJob.getSalesOrder().getBargeId())) {
//						return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//								HttpStatus.FORBIDDEN);
//					}
//				} else {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);	
//				
//				}
//			}
			log.info("POST req:" + salesJob.toString());
			postRequest = modelMapper.map(salesJob.getSalesOrder(), Job.class);
			postRequest.setJobType(salesJob.getJobType());
			postRequest.setClient(salesJob.getClient());
			if(salesJob.getSalesOrder().getSourceType()==null && salesJob.getSalesOrder().getIs_Updated()==1){
			postRequest.setSourceType("eBDN");
			}
			postRequest.setId(null);
			//postRequest.setMode(1);
			postRequest = jobService.findAndUpdateBargeData(postRequest);
			postRequest = jobService.findAndUpdateBdnParty(postRequest);
			postRequest = jobService.findAndUpdateLocation(postRequest);
			nomination =modelMapper.map(salesJob.getSalesOrder().getNominations().get(0), Nomination.class);
			log.info("Mapped Request:" + postRequest.toString());
			// changed the method for INTEGRATION with IBMS
			//Job existingJob = jobService.findByStemNo(postRequest.getStemNo());
			//Job existingJob = jobService.findByStemNoAndbargeName(postRequest.getStemNo(),postRequest.getBargeName());
			Job existingJob = jobService.findByStemNoAndbargeNameAndproductName(postRequest.getStemNo(),postRequest.getBargeName(),nomination.getmPAGrade());
			if(existingJob != null) {
				postRequest.setId(existingJob.getId());
				postRequest.setStatus(existingJob.getStatus());
				postRequest = jobService.updateJob(postRequest);
			}else {
				
				postRequest = jobService.createJob(postRequest);
			}

		} catch (Exception e) {
			log.error("Unable to add job", e);
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(postRequest, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/delivery", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateSalesOrder(@RequestBody SalesJobUpdateDTO salesJob) {
		Job postRequest = null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "CARGO OFFICER" })) {
//					if (!currentUserService.getCurrentUser().getBargeId()
//							.equals(salesJob.getSalesOrder().getBargeId())) {
//						return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//								HttpStatus.FORBIDDEN);
//					}
//				} else {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);	
//				
//				}
//			}
			log.info("PUT req:" + salesJob.toString());
			postRequest = modelMapper.map(salesJob.getSalesOrder(), Job.class);
			postRequest.setJobType(salesJob.getJobType());
			postRequest.setStatus(salesJob.getStatus());
			postRequest.setId(salesJob.getId());
			if(salesJob.getSalesOrder().getSourceType()==null && salesJob.getSalesOrder().getIs_Updated()==1){
				postRequest.setSourceType("eBDN");
				}
			//postRequest.setMode(1);
			
			log.info("PUT job:" + postRequest.toString());
			postRequest = jobService.updateJob(postRequest);

		} catch (Exception e) {
			log.error("Unable to add job", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(postRequest, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/loading", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createPurchaseOrder(@RequestBody PurchaseJobDTO purchaseJob) {
		Job postRequest = null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "CARGO OFFICER" })) {
//					if (!currentUserService.getCurrentUser().getBargeId()
//							.equals(purchaseJob.getPurchaseOrder().getBargeId())) {
//						return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//								HttpStatus.FORBIDDEN);
//					}
//				} else {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);	
//				}
//			}
			postRequest = modelMapper.map(purchaseJob.getPurchaseOrder(), Job.class);
			postRequest.setJobType(purchaseJob.getJobType());
			if(purchaseJob.getPurchaseOrder().getSourceType()== null && purchaseJob.getPurchaseOrder().getIs_Updated()==1){
				postRequest.setSourceType("eBDN");
				}
			log.info("job:" + postRequest.toString());
			postRequest.setId(null);
			Nomination nomination =modelMapper.map(purchaseJob.getPurchaseOrder().getNominations().get(0), Nomination.class);
			// Try override the exising job if job already exists
			// changed the method for INTEGRATION with IBMS
			//Job existingJob = jobService.findByPurchaseOrderNo(postRequest.getPurchaseOrderNo());
			Job existingJob = jobService.findByPurchaseOrderNoAndBargeNameAndproductName(postRequest.getPurchaseOrderNo(),postRequest.getBargeName(),nomination.getmPAGrade());
			if(existingJob != null) {
				postRequest.setId(existingJob.getId());
				postRequest.setStatus(existingJob.getStatus());
				postRequest = jobService.updateJob(postRequest);

			}else {
				postRequest = jobService.createJob(postRequest);
			}

		} catch (Exception e) {
			log.error("Unable to add job", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(postRequest, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/loading", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updatePurchaseOrder(@RequestBody PurchaseJobUpdateDTO purchaseJob) {
		Job postRequest = null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "CARGO OFFICER" })) {
//					if (!currentUserService.getCurrentUser().getBargeId()
//							.equals(purchaseJob.getPurchaseOrder().getBargeId())) {
//						return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//								HttpStatus.FORBIDDEN);
//					}
//				} else {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);	
//				
//				}
//			}
			postRequest = modelMapper.map(purchaseJob.getPurchaseOrder(), Job.class);
			postRequest.setJobType(purchaseJob.getJobType());
			postRequest.setStatus(purchaseJob.getStatus());
			postRequest.setId(purchaseJob.getId());
			if(purchaseJob.getPurchaseOrder().getSourceType()== null && purchaseJob.getPurchaseOrder().getIs_Updated()==1){
				postRequest.setSourceType("eBDN");
				}
			postRequest = jobService.updateJob(postRequest);

		} catch (Exception e) {
			log.error("Unable to add job", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(postRequest, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/status/{jobId}", method = RequestMethod.POST)
	@ResponseBody
	public Object updateJobStatusToConfirm(@PathVariable("jobId") Long jobId,
			@RequestParam(value = "status", defaultValue = "EXECUTING") StatusType status, 
			@RequestParam(value = "sendEmailForVesselLogin", defaultValue = "false") Boolean sendEmailForVesselLogin,
			@RequestParam(value = "sendEmailForSurveyorLogin", defaultValue = "false") Boolean sendEmailForSurveyorLogin,
			@RequestParam(value = "Env") String environment
			) throws Exception {
		Job updatedJob = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//					if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//						return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//								HttpStatus.FORBIDDEN);
//					}
//			}
			Constants.Environment=environment;
			updatedJob = jobService.updateJobStatus(status.toString(), jobId);
			
			if(sendEmailForVesselLogin)
			{
				jobService.createThreadToSendEmail(updatedJob, TaskType.SEND_EMAIL_FOR_VESSEL_LOGIN);
			}
			if(sendEmailForSurveyorLogin)
			{
				jobService.createThreadToSendEmail(updatedJob, TaskType.SEND_EMAIL_FOR_SURVEYOR_LOGIN);
			}
			
			if(status==StatusType.COMPLETED)
			{
				System.out.println("Job status is changed to COMPLETED so triggering MPA publisher to publish the completed jobs to MPA");
				//restService.runMPAPublisher();
	
			}
			
////			THIS ACTIVITY IS PULLED OUT AS THE STATUS UPDATE IS NOT REFLECTING IN THE JOB.FIND() UNTIL THE TRANSACTION IS COMMITED.
//			boolean retry = true;
//			while(retry)
//			{
//				Job updatedJob = jobRepository.findById(jobId).get();
//
//				//IF JOB STATUS IS UPDATED AS COMPLETED THEN PUSH THE JOB DETAILS TO MPA USING PYTHON MPA PUBLISHER LOCAL API
//				if(updatedJob!=null && updatedJob.getStatus()==StatusType.COMPLETED)
//				{
//					System.out.println("Job status is changed to COMPLETED so triggering MPA publisher to publish the completed jobs to MPA");
//					restService.runMPAPublisher();
//				}
//				else if(status.equalsIgnoreCase("COMPLETED"))
//				{
//					System.out.println("Error: Inconsiste system state, application sent the status as: "+status+" but after updating the job status to BD, the job is:"+updatedJob+", and the updated db status is showing up as:"+updatedJob.getStatus().toString());
//				}
//				else
//				{
//					System.out.println("Job status is:"+status+" so not triggering MPA publish activity.");
//				}
//				
//			}

		} catch (Exception e) {
			log.error("Unable to update job status to confirm with job id:" + jobId, e);
			throw new Exception("Internal Server Error, Unable to update job status to confirm with job id:" + jobId
					+ "possible error: " + e.getMessage());
		}
		return new ResponseEntity<Object>(updatedJob, HttpStatus.OK);
	}
	
	
	
	
	@RequestMapping(value = Utilities.APP_VERSION + "/job/sentContigencyMail/{jobId}", method = RequestMethod.POST)
	@ResponseBody
	public Object sentContigencyMail(@PathVariable("jobId") Long jobId, @RequestParam(value = "emails") String emails) throws Exception {
		Job job = jobService.getById(jobId);
		DateTimeFormatter pattern = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		String template = null;
		template = Constants.CONTIGENCY_EMAIL_TEMPLATE;
		Map<String, String> tokens = new HashMap<>(); 	
		try {
			EmailContent emailContent = new EmailContent();
			emailContent.setToEmailId(emails);
			emailContent.setFromEmailId(Constants.EMAIL_FROM_EMAIL_ID);
			emailContent.setSubject("Contingency Mode ON");
			tokens.put("BARGE_NAME", job.getBargeName());
			tokens.put("VESSEL_NAME", job.getVesselName());
			String formattedDate = LocalDate.now().format(pattern); 
			tokens.put("DATE",formattedDate);
     		tokens.put("CO_NAME", job.getCargoOfficer());
     		if(job.getContigencyCeVerified()==1) {
     			tokens.put("Contigency_CE_Verified", "1.I have verified with CE that he is not able to access the app via shipboard computer.");
     		}
     		if(job.getContigencyCeEmailFailed()==1) {
     			tokens.put("Contigency_CE_EmailFailed","2.Issues faced by CE did not receive credential email despite resending.");
     		}else if(job.getContigencyCeAccessFailed()==1) {
     			tokens.put("Contigency_CE_AccessFailed","2.Issues faced by CE is not able to access the app via shipboard computer/other device after logging using CE credential.");
     		}if(job.getContigencyCeLoginFailed()==1) {
     			tokens.put("Contigency_CE_LoginFailed","3.I have confirmed that CE is not able to login with his credential via my tablet");
     		}if(job.getContigencyCeApprovalSupervisor()==1) {
     			tokens.put("Contigency_CE_Approval_Supervisor","4.I have obtained approval from my supervisor to activate contingency mode. ");
     		}
     		tokens.put("REMARKS",job.getContigencyRemarks());
			String emailBody = mailContentBuilder.build(template,tokens);
			emailContent.setBody(emailBody);
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);
			message.setFrom(emailContent.getFromEmailId());
			String[] toEmailIds = cleanup(emailContent.getToEmailId());
			if (toEmailIds == null || toEmailIds.length == 0 || StringUtils.isBlank(toEmailIds[0])) {
				log.error("To email id not found for email content with id:" + emailContent.getId()
						+ ", so not sending email.");
				throw new InvalidEmailException("To email id not found for email content with id:" + emailContent.getId()
						+ ", so not sending email.");
			}
			if (toEmailIds != null && toEmailIds.length > 0) {
				for (String emailId : toEmailIds) {
					if (!Utilities.isValidEmailAddress(emailId)) {
						log.error("To email id not found for email content with id:" + emailContent.getId()
								+ ", so not sending email.");
						throw new InvalidEmailException("To email id not found for email content with id:" + emailContent.getId()
								+ ", so not sending email.");
					}
				}
			}
			messageHelper.setTo(toEmailIds);
			messageHelper.setSubject(emailContent.getSubject());
			messageHelper.setText(emailContent.getBody(), true);
			mailSender.send(message);
		} catch (Exception e) {
				throw e;
			}
		
		return "email sent sucessfully";
	}
	
	@Value("${file.upload}")
	private String fileupload ;
	
	@RequestMapping(value = Utilities.APP_VERSION + "/job/sentDocuments/{jobId}", method = RequestMethod.POST)
	@ResponseBody
	public Object sentDocuments(@PathVariable("jobId") Long jobId, @RequestParam(value = "emails") String emails,@RequestBody HashMap<String, String[]> map
			) throws Exception {
		Job updatedJob = null;
		String[] documents =map.get("documents");
		Job job = jobService.getById(jobId);
		String grade ="";
		grade =jobRepository.getGrade(jobId);
		File MFMTicket = new File();
		String targetPath="";
		Resource fileResource=null;
		byte[] bytes =null;
		
		try {
			Calendar cal = Calendar.getInstance();
			EmailContent emailContent = new EmailContent();
			emailContent.setToEmailId(emails);
			emailContent.setFromEmailId(Constants.EMAIL_FROM_EMAIL_ID);
			emailContent.setSubject("Bunkering Documents "+job.getVesselName()+" "+"("+grade+")"+" "+job.getEta());
			emailContent.setBody("Below attached the Bunkering Documents");
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);
			message.setFrom(emailContent.getFromEmailId());
			String[] toEmailIds = cleanup(emailContent.getToEmailId());
			if (toEmailIds == null || toEmailIds.length == 0 || StringUtils.isBlank(toEmailIds[0])) {
				log.error("To email id not found for email content with id:" + emailContent.getId()
						+ ", so not sending email.");
				throw new InvalidEmailException("To email id not found for email content with id:" + emailContent.getId()
						+ ", so not sending email.");
			}
			if (toEmailIds != null && toEmailIds.length > 0) {
				for (String emailId : toEmailIds) {
					if (!Utilities.isValidEmailAddress(emailId)) {
						log.error("To email id not found for email content with id:" + emailContent.getId()
								+ ", so not sending email.");
						throw new InvalidEmailException("To email id not found for email content with id:" + emailContent.getId()
								+ ", so not sending email.");
					}
				}
			}
			messageHelper.setTo(toEmailIds);
			messageHelper.setSubject(emailContent.getSubject());
			messageHelper.setText(emailContent.getBody(), true);
				
			for(String doc :documents) {
				if(doc.equals("ebdn")) {
					doc="Bunker DeliveryNote.pdf";
				}else if(doc.equals("breq")) {
					doc="Bunker Requisition.pdf";
				}else if(doc.equals("safety")) {
					doc="Bunker Safety Checklist.pdf";
				}else if(doc.equals("mfm")) {
					doc="MFM Meter Reading.pdf";
				}else if(doc.equals("seals")) {
					doc="MFM Seals Checklist.pdf";
				}else if(doc.equals("nop")) {
					doc="Note of Protest.pdf";
				}else if(doc.equals("meterticket")) {
					MFMTicket = dbFileRepository.getLatestMeterTicket(jobId);
					if(MFMTicket != null) {
						bytes = Base64.getDecoder().decode(MFMTicket.getContent());
						ByteArrayOutputStream buffer = new ByteArrayOutputStream();
						buffer.write(bytes);
						targetPath =fileService.storeFile(MFMTicket.getFileName(), buffer,jobId);
						fileResource=fileService.loadFileAsResource(targetPath);
						doc=MFMTicket.getFileName();
					}
				}else if(doc.equals("cargoloading")) {
					doc="CargoLoading.pdf";
				}else if(doc.equals("timelog")) {
					doc="TimeLog.pdf";
				}else if(doc.equals("sof")) {
					doc="SOF.pdf";
				}else {
					Optional<Attachment> dto =attachmentRepository.findById(Long.parseLong(doc));
					if(dto!=null && !dto.get().getWorkflow().equalsIgnoreCase("VESSEL_STAMPS") && !dto.get().getWorkflow().equalsIgnoreCase("SURVEYOR_STAMPS")) {
						doc=dto.get().getFileName();
					}
				}
				//Resource fileResource=fileService.loadFileAsResource("C:\\EBDN\\Documents\\"+cal.get(Calendar.YEAR)+"\\"+jobId+"\\"+doc);
				Path filePath = Paths.get(fileupload+"\\"+cal.get(Calendar.YEAR)+"\\"+jobId+"\\"+doc);
				Resource resource = new UrlResource(filePath.toUri());
						if (resource.exists()) {
							messageHelper.addAttachment(doc,resource);
						} else {
						continue;
						}	
			}
//			File resource = new ClassPathResource(
//				      "documents/User Manuals/Chief Engineer.pdf").getFile();
			//FileSystemResource file = new FileSystemResource("D:/BOLISETTI SRIVIDYA CV.PDF");
			mailSender.send(message);
			jobRepository.updateEmailStatus("DONE", jobId);
			
			
			
			} catch (Exception e) {
				jobRepository.updateEmailStatus("", jobId);
			throw e;
		}
		return new ResponseEntity<Object>(updatedJob, HttpStatus.OK);
	}
	private String[] cleanup(String emailIds) {
		if (StringUtils.isNotBlank(emailIds)) {
			String[] tokens = emailIds.split(",");
			List<String> emails = new ArrayList<>();
			for (String email : tokens) {
				if (StringUtils.contains(email, "@") && StringUtils.contains(email, ".")) {
					emails.add(email);
				} else {
					log.error("Invalid email:" + email);
				}
			}
			if (emails.size() > 0) {
				log.debug("Cleaned up emails:" + emails);
				String[] emailIdsArray = new String[emails.size()];
				emailIdsArray = emails.toArray(emailIdsArray);
				return emailIdsArray;
			}
		}
		return null;
	}
	
	
	

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{id}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> get(@PathVariable("id") long id) {
//		Optional<Job> job = null;
		Job job = null;
		try {	
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			job = jobService.getById(id);
		} catch (Exception e) {
			log.error("Unable to get job", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
//		return new ResponseEntity<Object>(job.get(), HttpStatus.OK);
		return new ResponseEntity<Object>(job, HttpStatus.OK);

	}
	
	

	@RequestMapping(value = Utilities.APP_VERSION + "/job/all", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAll() {
		List<Job> pages = null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);	
//		}
			pages = jobService.getAll();
		} catch (Exception e) {
			log.error("Unable to get all grages, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(pages, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/all/{jobType}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAll(@PathVariable("jobType") JOBTYPE jobType) {
		List<Job> pages = null;
		try {
			pages = jobService.getAllByJobType(jobType);
		} catch (Exception e) {
			log.error("Unable to get all grages, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(pages, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{id}", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Object> delete(@PathVariable("id") long id) {
		try {
			jobService.delete(id);
		} catch (Exception e) {
			log.error("Unable to delete grade, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>("Deleted grade with id:" + id, HttpStatus.OK);
	}

	/*
	 * BUNKER REQUISTION FORM -- START
	 */

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/bunker-requistion", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createBunkerRequistion(@PathVariable("jobId") long id,
			@RequestBody BunkerRequisitionData bunkerRequisitionData) {
		try {
			Job job = jobService.getById(id);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			BunkerRequisitionData data = jobService.getBunkerRequisition(bunkerRequisitionData.getJobId());
			if(data !=null ) {
				bunkerRequisitionData.setId(data.getId());
			}

			log.debug("Creating Bunker Requistion For Job ID:" + id);
			bunkerRequisitionData = jobService.createBunkerRequisition(bunkerRequisitionData);
			if(bunkerRequisitionData!=null) {
				asynServices.generateBinaryData(id, "C:\\EBDN\\Templates\\BunkerReq.jrxml","breq",Constants.moduleId_Delivery,Constants.transactionId_Req);
				//uploadBinaryData(binaryString,id,"breq");
			}

		} catch (Exception e) {
			log.error("Unable to create bunker requistion for job id:" + id, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bunkerRequisitionData != null) {
			bunkerRequisitionData.setReqFileBinary(null);
		}
		return new ResponseEntity<Object>(bunkerRequisitionData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/bunker-requistion", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateBunkerRequisition(@PathVariable("jobId") long jobId,
			@RequestBody BunkerRequisitionData bunkerRequisitionData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
			//	}
			//}
			BunkerRequisitionData data = jobService.getBunkerRequisition(bunkerRequisitionData.getJobId());
			if(data !=null ) {
				bunkerRequisitionData.setId(data.getId());
			}
			log.debug("Updating bunker requisition form for job id:" + jobId);
			bunkerRequisitionData = jobService.updateBunkerRequisition(bunkerRequisitionData);
			 BDNData bdnData = jobService.getBDNData(jobId);
			 if(bdnData!=null) {
				 bdnDataRepository.updateManditoryFields(bunkerRequisitionData.getJobId(),bunkerRequisitionData.getViscosity(),
						bunkerRequisitionData.getDensity(),bunkerRequisitionData.getWaterContent(),bunkerRequisitionData.getSulpherContent(),
						bunkerRequisitionData.getFlashPoit());
			 }
			if(bunkerRequisitionData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\BunkerReq.jrxml","breq",Constants.moduleId_Delivery,Constants.transactionId_Req);
			}

		} catch (Exception e) {
			log.error("Unable to update bunker requistion form for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bunkerRequisitionData != null) {
			bunkerRequisitionData.setReqFileBinary(null);
		}
		return new ResponseEntity<Object>(bunkerRequisitionData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/bunker-requistion", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getBunkerRequisition(@PathVariable("jobId") long jobId) {
		BunkerRequisitionData bunkerRequisitionData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			bunkerRequisitionData = jobService.getBunkerRequisition(jobId);
		} catch (Exception e) {
			log.error("Unable to get bunker requisition data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bunkerRequisitionData != null) {
			bunkerRequisitionData.setReqFileBinary(null);
		}
		return new ResponseEntity<Object>(bunkerRequisitionData, HttpStatus.OK);
	}

	/*
	 * BUNKER SAFETY CHECKLIST -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/bunker-safety-checklist", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createBunkerSafetyChecklist(@PathVariable("jobId") long jobId,
			@RequestBody BunkerSafetyChecklistData bunkerSafetyChecklistData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Creating Bunker Safety Checklist For Job Id:" + jobId);
			bunkerSafetyChecklistData = jobService.createBunkerSafetyChecklist(bunkerSafetyChecklistData);
			if(bunkerSafetyChecklistData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\Safety_Checklist.jrxml","safety",Constants.moduleId_Delivery,Constants.transactionId_Safety);
				//uploadBinaryData(binaryString,jobId,"safety");
			}
		} catch (Exception e) {
			log.error("Unable to create bunker safety checklist for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bunkerSafetyChecklistData != null) {
			bunkerSafetyChecklistData.setSafetyFileBinary(null);
		}
		return new ResponseEntity<Object>(bunkerSafetyChecklistData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/bunker-safety-checklist", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateBunkerSafetyChecklist(@PathVariable("jobId") long jobId,
			@RequestBody BunkerSafetyChecklistData bunkerSafetyChecklistData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Updating bunker safety checklist for job id:" + jobId);
			bunkerSafetyChecklistData = jobService.updateBunkerSafetyChecklist(bunkerSafetyChecklistData);
			if(bunkerSafetyChecklistData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\Safety_Checklist.jrxml","safety",Constants.moduleId_Delivery,Constants.transactionId_Safety);
				//uploadBinaryData(binaryString,jobId,"safety");
			}

		} catch (Exception e) {
			log.error("Unable to update bunker safety checklist for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bunkerSafetyChecklistData != null) {
			bunkerSafetyChecklistData.setSafetyFileBinary(null);
		}
		return new ResponseEntity<Object>(bunkerSafetyChecklistData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/bunker-safety-checklist", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getBunkerSafetyChecklist(@PathVariable("jobId") long jobId) {
		BunkerSafetyChecklistData bunkerSafetyChecklistData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			bunkerSafetyChecklistData = jobService.getBunkerSafetyChecklist(jobId);
		} catch (Exception e) {
			log.error("Unable to get bunker safety checklist data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bunkerSafetyChecklistData != null) {
			bunkerSafetyChecklistData.setSafetyFileBinary(null);
		}
		return new ResponseEntity<Object>(bunkerSafetyChecklistData, HttpStatus.OK);
	}

	/*
	 * MFM SEALS CHECKLIST -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/mfm-seals-checklist", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createMFMSealsChecklist(@PathVariable("jobId") long jobId,
			@RequestBody MFMSealsChecklistData mFMSealsChecklistData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Creating MFM Seals Checklist For Job Id:" + jobId);
			mFMSealsChecklistData = jobService.createMFMSealsChecklist(mFMSealsChecklistData);
			if(mFMSealsChecklistData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\Seals_Checklist.jrxml","seals",Constants.moduleId_Delivery,Constants.transactionId_Seals);
				//uploadBinaryData(binaryString,jobId,"seals");
			}

		} catch (Exception e) {
			log.error("Unable to create MFM seals checklist for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(mFMSealsChecklistData != null) {
			mFMSealsChecklistData.setSealFileBinary(null);
		}
		return new ResponseEntity<Object>(mFMSealsChecklistData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/mfm-seals-checklist", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateMFMSealsChecklist(@PathVariable("jobId") long jobId,
			@RequestBody MFMSealsChecklistData mFMSealsChecklistData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Updating MFM seals checklist for job id:" + jobId);
			mFMSealsChecklistData = jobService.updateMFMSealsChecklist(mFMSealsChecklistData);
			if(mFMSealsChecklistData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\Seals_Checklist.jrxml","seals",Constants.moduleId_Delivery,Constants.transactionId_Seals);
				//uploadBinaryData(binaryString,jobId,"seals");
			}

		} catch (Exception e) {
			log.error("Unable to update MFM seals checklist for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(mFMSealsChecklistData != null) {
			mFMSealsChecklistData.setSealFileBinary(null);
		}
		return new ResponseEntity<Object>(mFMSealsChecklistData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/mfm-seals-checklist", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getMFMSealsChecklist(@PathVariable("jobId") long jobId) {
		MFMSealsChecklistData mfmSealsChecklistData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			mfmSealsChecklistData = jobService.getMFMSealsChecklist(jobId);
		} catch (Exception e) {
			log.error("Unable to get MFM seals checklist data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(mfmSealsChecklistData != null) {
			mfmSealsChecklistData.setSealFileBinary(null);
		}
		return new ResponseEntity<Object>(mfmSealsChecklistData, HttpStatus.OK);
	}

	/*
	 * TIMELOG -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/timelog", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createTimelog(@PathVariable("jobId") long jobId,
			@RequestBody TimelogData timelogData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Creating Timelog data for job Id:" + jobId);
			timelogData = jobService.createTimeLogData(timelogData);
			if(timelogData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\TimeLog.jrxml","timelog",Constants.moduleId_Delivery,Constants.transactionId_timelog);
				timelogData.setTimelogFileBinary(null);
			}

		} catch (Exception e) {
			log.error("Unable to create Timelog data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(timelogData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/timelog", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateTimelogData(@PathVariable("jobId") long jobId,
			@RequestBody TimelogData timelogData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Updating Timelog data for job id:" + jobId);
			timelogData = jobService.updateTimelogData(timelogData);
			if(timelogData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\TimeLog.jrxml","timelog",Constants.moduleId_Delivery,Constants.transactionId_timelog);
				timelogData.setTimelogFileBinary(null);
			}

		} catch (Exception e) {
			log.error("Unable to update Timelog data for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(timelogData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/timelog", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getTimelogData(@PathVariable("jobId") long jobId) {
		TimelogData timelogData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			timelogData = jobService.getTimelogData(jobId);
		} catch (Exception e) {
			log.error("Unable to get Timelog data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(timelogData!=null) {
			timelogData.setTimelogFileBinary(null);
		}
		return new ResponseEntity<Object>(timelogData, HttpStatus.OK);
	}

	/*
	 * MFM READING DATA -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/mfm-reading-data", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createMFMReadingData(@PathVariable("jobId") long jobId,
			@RequestBody MFMReadingData mfmReadingData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Creating MFM Reading data for job Id:" + jobId);
			mfmReadingData = jobService.createMFMReadingData(mfmReadingData);
			//for updating deliveryqty from mfm to delivery note
			BDNData bdnData = jobService.getBDNData(jobId);
			if(bdnData!=null) {
				 bdnDataRepository.updateDeliverqty(mfmReadingData.getQuantitySupplied(),jobId);
			}
			if(mfmReadingData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\MFMReading.jrxml","mfm",Constants.moduleId_Delivery,Constants.transactionId_mfm);
				//uploadBinaryData(binaryString,jobId,"mfm");
			}

		} catch (Exception e) {
			log.error("Unable to create MFM Reading data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(mfmReadingData != null) {
			mfmReadingData.setMfmFileBinary(null);
		}
		return new ResponseEntity<Object>(mfmReadingData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/mfm-reading-data", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateMFMReadingData(@PathVariable("jobId") long jobId,
			@RequestBody MFMReadingData mfmReadingData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Updating MFM Reading data for job id:" + jobId);
			mfmReadingData = jobService.updateMFMReadingData(mfmReadingData);
			//for updating deliveryqty from mfm to delivery note
			BDNData bdnData = jobService.getBDNData(jobId);
			if(bdnData!=null) {
				 bdnDataRepository.updateDeliverqty(mfmReadingData.getQuantitySupplied(),jobId);
			}
			if(mfmReadingData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\MFMReading.jrxml","mfm",Constants.moduleId_Delivery,Constants.transactionId_mfm);
				//uploadBinaryData(binaryString,jobId,"mfm");
			}

		} catch (Exception e) {
			log.error("Unable to update MFM Reading data for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(mfmReadingData != null) {
			mfmReadingData.setMfmFileBinary(null);
		}
		return new ResponseEntity<Object>(mfmReadingData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/mfm-reading-data", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getMFMReadingData(@PathVariable("jobId") long jobId) {
		MFMReadingData timelogData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			timelogData = jobService.getMFMReadingData(jobId);
		} catch (Exception e) {
			log.error("Unable to get MFM Reading data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(timelogData != null) {
			timelogData.setMfmFileBinary(null);
		}
		return new ResponseEntity<Object>(timelogData, HttpStatus.OK);
	}

	/*
	 * SOF DATA -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/sof-data", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createSOFData(@PathVariable("jobId") long jobId, @RequestBody Sof sofData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Creating SOF data for job Id:" + jobId);
			sofData = jobService.createSOFData(sofData);
			if(sofData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\SOF.jrxml","sof",Constants.moduleId_Delivery,Constants.transactionId_sof);
				sofData.setSofFileBinary(null);
			}


		} catch (Exception e) {
			log.error("Unable to create SOF data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(sofData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/sof-data", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateSOFData(@PathVariable("jobId") long jobId, @RequestBody Sof sofData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Updating SOF data for job id:" + jobId);
			sofData = jobService.updateSOFData(sofData);
			if(sofData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\SOF.jrxml","sof",Constants.moduleId_Delivery,Constants.transactionId_sof);
				sofData.setSofFileBinary(null);
			}

		} catch (Exception e) {
			log.error("Unable to update SOF data for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(sofData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/sof-data", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getSOFData(@PathVariable("jobId") long jobId) {
		Sof sofData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			sofData = jobService.getSOFData(jobId);
		} catch (Exception e) {
			log.error("Unable to get SOF data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(sofData!=null) {
			sofData.setSofFileBinary(null);
		}
		return new ResponseEntity<Object>(sofData, HttpStatus.OK);
	}

	/*
	 * BDN DATA -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/bdn-data", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createBDNData(@PathVariable("jobId") long jobId, @RequestBody BDNData bdnData) {
		byte[] dataList = null;
		String targetPath="";
		Resource fileResource=null;
		String folderName="";
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Creating BDN data for job Id:" + jobId);
			bdnData.setJobId(jobId);
			bdnData = jobService.createBDNData(bdnData);
			if(bdnData != null) {
				String binaryString=documentcontroller.generateBinaryData(jobId, "C:\\EBDN\\Templates\\BDNData.jrxml");
				bdnData.setBdnFileBinary(binaryString);
				bdnData = jobService.updateBDNData(bdnData);
				asynServices.saveAttachment(jobId, Constants.moduleId_Delivery, 1, binaryString, "ebdn", Constants.transactionId_bdn);
			}
			try {
				if(bdnData!=null) {
//					String binaryString=documentcontroller.generateBinaryData(jobId, "C:\\EBDN\\Templates\\BDNData.jrxml");
//					uploadBinaryData(binaryString,jobId,"ebdn");
//					asynServices.saveAttachment(jobId, Constants.moduleId_Delivery, 1, binaryString, "ebdn", Constants.transactionId_bdn);
					folderName ="Bunker DeliveryNote.pdf";
					String data = "{\"job_id\":"+jobId+"}";
					restService.jsonAttachment(data);
					BDNData bdnDataNew = bdnDataRepository.findByJobId(jobId);
					dataList = Base64.getDecoder().decode(bdnDataNew.getBdnFileBinary());
					ByteArrayOutputStream buffer = new ByteArrayOutputStream();
					buffer.write(dataList);
					targetPath =fileService.storeFile(folderName, buffer,jobId);
					//asynServices.compressPdf(targetPath);
					fileResource=fileService.loadFileAsResource(targetPath);
					//asynServices.saveAttachment(jobId, Constants.moduleId_Delivery, 1, bdnDataNew.getBdnFileBinary(), "ebdn", Constants.transactionId_bdn);
			}
			}catch(Exception e) {
				log.error("Unable to generate the BDN REPORT" + jobId, e);
			}

		} catch (Exception e) {
			log.error("Unable to create BDN data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bdnData != null) {
			bdnData.setBdnFileBinary(null);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/bdn-data", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateBDNData(@PathVariable("jobId") long jobId, @RequestBody BDNData bdnData) {
		byte[] dataList = null;
		String targetPath="";
		Resource fileResource=null;
		String folderName="";
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Updating BDN data for job id:" + jobId);
//			String binaryString=documentcontroller.generateBinaryData(jobId, "C:\\EBDN\\Templates\\BDNData.jrxml");
//			System.out.print(binaryString);
//			bdnData.setBdnFileBinary(binaryString);
			bdnData = jobService.updateBDNData(bdnData);
			if(bdnData != null) {
				String binaryString=documentcontroller.generateBinaryData(jobId, "C:\\EBDN\\Templates\\BDNData.jrxml");
				bdnData.setBdnFileBinary(binaryString);
				bdnData = jobService.updateBDNData(bdnData);
				asynServices.saveAttachment(jobId, Constants.moduleId_Delivery, 1, binaryString, "ebdn", Constants.transactionId_bdn);
			}
			try {
				if(bdnData!=null) {
					//String binaryString=documentcontroller.generateBinaryData(jobId, "C:\\EBDN\\Templates\\BDNData.jrxml");
					//uploadBinaryData(binaryString,jobId,"ebdn");
					//asynServices.saveAttachment(jobId, Constants.moduleId_Delivery, 1, binaryString, "ebdn", Constants.transactionId_bdn);
					folderName ="Bunker DeliveryNote.pdf";
					String data = "{\"job_id\":"+jobId+"}";
					restService.jsonAttachment(data);
					BDNData bdnDataNew = bdnDataRepository.findByJobId(jobId);
					dataList = Base64.getDecoder().decode(bdnDataNew.getBdnFileBinary());
					ByteArrayOutputStream buffer = new ByteArrayOutputStream();
					buffer.write(dataList);
					targetPath =fileService.storeFile(folderName, buffer,jobId);
					//asynServices.compressPdf(targetPath);
					fileResource=fileService.loadFileAsResource(targetPath);
					//asynServices.saveAttachment(jobId, Constants.moduleId_Delivery, 1, bdnDataNew.getBdnFileBinary(), "ebdn", Constants.transactionId_bdn);
			}
			}catch(Exception e) {
				log.error("Unable to generate the BDN REPORT" + jobId, e);
			}
		} catch (Exception e) {
			log.error("Unable to update BDN data for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bdnData != null) {
			bdnData.setBdnFileBinary(null);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/bdn-data", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getBDNData(@PathVariable("jobId") long jobId) {
		BDNData bdnData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			bdnData = jobService.getBDNData(jobId);
		} catch (Exception e) {
			log.error("Unable to get BDN data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bdnData != null) {
			bdnData.setBdnFileBinary(null);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	/*
	 * NOP DATA -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/nop-data", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createNOPData(@PathVariable("jobId") long jobId, @RequestBody NOPData bdnData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Creating NOP data for job Id:" + jobId);
			bdnData.setJobId(jobId);
			bdnData = jobService.createNOPData(bdnData);
			if(bdnData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\NOP.jrxml","nop",Constants.moduleId_Delivery,Constants.transactionId_nop);
			}

		} catch (Exception e) {
			log.error("Unable to create NOP data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bdnData != null) {
			bdnData.setNopFileBinary(null);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/nop-data", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateNOPData(@PathVariable("jobId") long jobId, @RequestBody NOPData bdnData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Updating NOP data for job id:" + jobId);
			bdnData = jobService.updateNOPData(bdnData);
			//nOPDataRepository.updateBinaryData("ABC", jobId);
			if(bdnData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\NOP.jrxml","nop",Constants.moduleId_Delivery,Constants.transactionId_nop);
			}
		} catch (Exception e) {
			log.error("Unable to update SOF data for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bdnData != null) {
			bdnData.setNopFileBinary(null);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/nop-data", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getNOPData(@PathVariable("jobId") long jobId) {
		NOPData bdnData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			bdnData = jobService.getNOPData(jobId);
		} catch (Exception e) {
			log.error("Unable to get NOP data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bdnData != null) {
			bdnData.setNopFileBinary(null);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}
	
	/*
	 * DISCREPANCY DATA -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/discrepancy-data", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createDiscrepancyData(@PathVariable("jobId") long jobId, @RequestBody DiscrepancyData bdnData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Creating NOP data for job Id:" + jobId);
			bdnData.setJobId(jobId);
			bdnData = jobService.createDiscrepancyData(bdnData);

		} catch (Exception e) {
			log.error("Unable to create NOP data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/discrepancy-data", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateDiscrepancyData(@PathVariable("jobId") long jobId, @RequestBody DiscrepancyData bdnData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Updating NOP data for job id:" + jobId);
			bdnData = jobService.updateDiscrepancyData(bdnData);

		} catch (Exception e) {
			log.error("Unable to update SOF data for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/discrepancy-data", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getDiscrepancyData(@PathVariable("jobId") long jobId) {
		DiscrepancyData bdnData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			bdnData = jobService.getDiscrepancyData(jobId);
		} catch (Exception e) {
			log.error("Unable to get NOP data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}


	/*
	 * ESIGNATURES DATA -- 
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/esignatures-data", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createESignaturesData(@PathVariable("jobId") long jobId, @RequestBody ESignaturesData eSignData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			
			log.debug("Creating eSign data for job Id:" + jobId);
			ESignaturesData existingESigData = jobService.getESignData(jobId);
			Map<String, String> newSigns = Constants.GSON.fromJson(eSignData.getEsignature(), Map.class);
			Map<String, String> existingSigns = null;
			Map<String, String> finalSigns = new HashMap<String, String>();
			Set<String> fullSet = new HashSet<String>();
			if(existingESigData!=null)
			{
				eSignData.setId(existingESigData.getId());
				existingSigns= Constants.GSON.fromJson(existingESigData.getEsignature(), Map.class);
				fullSet.addAll(existingSigns.keySet());
			}
			else
			{
				existingSigns = new HashMap<String, String>();
			}
			eSignData.setJobId(jobId);
			
//			GET THE COMPLETE LIST OF KEYS FROM OLD AND NEW SIGNATURE SET
			fullSet.addAll(newSigns.keySet());
			
			for (String key : fullSet) {
				String value = null;
				//IF SIGNATURE NOT EXISTS IN OLD SET THEN, TAKE THE NEW ONE
				if(!newSigns.containsKey(key))
				{
					value = existingSigns.get(key);
				}
				//IF SIGNATURE NOT EXISTS IN THE NEW SET THEN, TAKE THE OLD ONE
				else if(!existingSigns.containsKey(key))
				{
					value = newSigns.get(key);
				}
				//IF SIGNATURE EXISTS IN BOTH THE NEW SET AND THE OLD SET THEN CHECK THE TIMESTAMPS
				else
				{
					long timestampOld = Utilities.getTimeStampOfSignature(existingSigns.get(key));
					long timestampNew = Utilities.getTimeStampOfSignature(newSigns.get(key));
					if(timestampNew>=timestampOld)
					{
						value = newSigns.get(key);
					}
					else
					{
						value = existingSigns.get(key);
					}
						
				}
				finalSigns.put(key, value);
			}
			eSignData.setEsignature(Constants.GSON.toJson(finalSigns));
			eSignData = jobService.createESignData(eSignData);

			

		} catch (Exception e) {
			log.error("Unable to create ESign data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(eSignData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/esignatures-data", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateESignaturesData(@PathVariable("jobId") long jobId, @RequestBody ESignaturesData eSignData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			ESignaturesData data = jobService.getESignData(jobId);
			if(data!=null) {
				eSignData.setId(data.getId());
			}
			log.debug("Updating ESign data for job id:" + jobId);
			eSignData = jobService.updateESignData(eSignData);

		} catch (Exception e) {
			log.error("Unable to update ESign data for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(eSignData, HttpStatus.OK);
	}
	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/esignatures-data", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getESignaturesData(@PathVariable("jobId") long jobId) {
		ESignaturesData eSignData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			eSignData = jobService.getESignData(jobId);
		} catch (Exception e) {
			log.error("Unable to get ESign data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(eSignData, HttpStatus.OK);
	}


	/*
	 * BUNKER TRANSFER DATA -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/bunker-transfer-data", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createBunkerTransferData(@PathVariable("jobId") long jobId,
			@RequestBody BunkerTransferData bdnData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Creating NOP data for job Id:" + jobId);
			bdnData.setJobId(jobId);
			bdnData = jobService.createBunkerTransferData(bdnData);

		} catch (Exception e) {
			log.error("Unable to create NOP data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/bunker-transfer-data", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateBunkerTransferData(@PathVariable("jobId") long jobId,
			@RequestBody BunkerTransferData bdnData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			log.debug("Updating NOP data for job id:" + jobId);
			bdnData = jobService.updateBunkerTransferData(bdnData);

		} catch (Exception e) {
			log.error("Unable to update SOF data for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/bunker-transfer-data", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getBunkerTransferData(@PathVariable("jobId") long jobId) {
		BunkerTransferData bdnData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			bdnData = jobService.getBunkerTransferData(jobId);
		} catch (Exception e) {
			log.error("Unable to get NOP data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	/*
	 * CARGO LOADING DATA -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/cargo-loading-data", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createCargoLoadingData(@PathVariable("jobId") long jobId,
			@RequestBody CargoLoadingData bdnData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			CargoLoadingData data = jobService.getCargoLoadingData(bdnData.getJobId());
			if(data != null ) {
				bdnData.setId(data.getId());
			}
			log.debug("Creating CargoLoadingData for job Id:" + jobId);
			bdnData.setJobId(jobId);
			bdnData = jobService.createCargoLoadingData(bdnData);
			//for generating reports
			if(bdnData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\CargoLoading.jrxml","cargoloading",Constants.moduleId_Loading,1);
				bdnData.setCargoFileBinary(null);
			}

		} catch (Exception e) {
			log.error("Unable to create NOP data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/cargo-loading-data", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateCargoLoadingData(@PathVariable("jobId") long jobId,
			@RequestBody CargoLoadingData bdnData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			CargoLoadingData data = jobService.getCargoLoadingData(bdnData.getJobId());
			if(data != null ) {
				bdnData.setId(data.getId());
			}
			log.debug("Updating NOP data for job id:" + jobId);
			bdnData = jobService.updateCargoLoadingData(bdnData);
			if(bdnData!=null) {
				asynServices.generateBinaryData(jobId, "C:\\EBDN\\Templates\\CargoLoading.jrxml","cargoloading",Constants.moduleId_Loading,1);
				bdnData.setCargoFileBinary(null);
			}

		} catch (Exception e) {
			log.error("Unable to update SOF data for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}
	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/cargo-loading-data", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getCargoLoadingData(@PathVariable("jobId") long jobId) {
		CargoLoadingData bdnData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			bdnData = jobService.getCargoLoadingData(jobId);
		} catch (Exception e) {
			log.error("Unable to get NOP data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(bdnData!=null) {
			bdnData.setCargoFileBinary(null);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}
	
	/*
	 * OCR DATA -- START
	 */
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/ocr-result", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createOcrResult(@PathVariable("jobId") long jobId,
			@RequestBody OcrResult bdnData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			OcrResult ocrResult = jobService.getOcrResult(jobId);
			if(ocrResult != null) {
				bdnData.setId(ocrResult.getId());
			}
			
			log.debug("Creating NOP data for job Id:" + jobId);
			bdnData.setJobId(jobId);
			bdnData = jobService.createOcrResult(bdnData);

		} catch (Exception e) {
			log.error("Unable to create NOP data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/ocr-result", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateOcrResult(@PathVariable("jobId") long jobId,
			@RequestBody OcrResult bdnData) {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			OcrResult ocrResult = jobService.getOcrResult(jobId);
			if(ocrResult != null) {
				bdnData.setId(ocrResult.getId());
			}
			log.debug("Updating NOP data for job id:" + jobId);
			bdnData = jobService.updateOcrResult(bdnData);

		} catch (Exception e) {
			log.error("Unable to update SOF data for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}
	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/ocr-result", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getOcrResult(@PathVariable("jobId") long jobId) {
		OcrResult bdnData = null;
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			bdnData = jobService.getOcrResult(jobId);
		} catch (Exception e) {
			log.error("Unable to get NOP data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}
	
	@RequestMapping(value = Utilities.APP_VERSION + "/job/{jobId}/esigntimestamps", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> addAdditionalJobData(@PathVariable("jobId") long jobId, @RequestBody EsignTimestamp eSignTimestamp) {
		Object data = null;
		try {
			//,,timelog,,sof-data,bdn-data,nop-data,discrepancy-data
			
			if(eSignTimestamp.getWorkflowType().equalsIgnoreCase("bunker-requistion")) {
				BunkerRequisitionData buRqData = jobService.getBunkerRequisition(eSignTimestamp.getJobId());
			
				if(buRqData != null) {
					buRqData.setSurPreSignDateTime(eSignTimestamp.getSurPreSignDateTime());
					buRqData.setSurPostSignDateTime(eSignTimestamp.getSurPostSignDateTime());
					buRqData = jobService.updateBunkerRequisition(buRqData);
				}
				data = buRqData; 
				 
			} else if(eSignTimestamp.getWorkflowType().equalsIgnoreCase("mfm-seals-checklist")) {
				//MFMSealsChecklistData sealData = jobService.getMFMSealsChecklist(eSignTimestamp.getJobId());
//				if(sealData != null) {
//					sealData.setSurPreSignDateTime(eSignTimestamp.getSurPreSignDateTime());
//					sealData.setSurPostSignDateTime(eSignTimestamp.getSurPostSignDateTime());
//					sealData = jobService.updateMFMSealsChecklist(sealData);
//				}
				MFMSealsChecklistData sealData = mfmSealsChecklistRepository.findByJobId(jobId);
				if(sealData != null) {	
				mFMSealChecklistRepository.updateTimeStamps(eSignTimestamp.getJobId(),eSignTimestamp.getSurPreSignDateTime(),eSignTimestamp.getSurPostSignDateTime());
				}
				data=sealData;
				 
			}else if(eSignTimestamp.getWorkflowType().equalsIgnoreCase("bunker-safety-checklist")) {
				BunkerSafetyChecklistData safData = jobService.getBunkerSafetyChecklist(eSignTimestamp.getJobId());
				if(safData != null) {
					safData.setSurPreSignDateTime(eSignTimestamp.getSurPreSignDateTime());
					safData.setSurPostSignDateTime(eSignTimestamp.getSurPostSignDateTime());
					safData = jobService.updateBunkerSafetyChecklist(safData);
				}
				data = safData; 
				
			} else if(eSignTimestamp.getWorkflowType().equalsIgnoreCase("mfm-reading-data")) {
				MFMReadingData redingData = jobService.getMFMReadingData(eSignTimestamp.getJobId());
				 if(redingData != null) {
					 redingData.setSurPreSignDateTime(eSignTimestamp.getSurPreSignDateTime());
					 redingData.setSurPostSignDateTime(eSignTimestamp.getSurPostSignDateTime());
					 redingData = jobService.updateMFMReadingData(redingData);
					}
					data = redingData; 
				 
			} else if(eSignTimestamp.getWorkflowType().equalsIgnoreCase("nop-data")) {
				NOPData nopData = jobService.getNOPData(eSignTimestamp.getJobId());
				 if( nopData != null) {
					 nopData.setSurPreSignDateTime(eSignTimestamp.getSurPreSignDateTime());
					 nopData = jobService.updateNOPData(nopData);
					}
					data = nopData; 
				 
			}
			
			if(data == null ) {
				return new ResponseEntity<Object>(new ResponseObject(404, eSignTimestamp.getWorkflowType()+ " for "+ eSignTimestamp.getJobId()+" Not found ", null, false),
						HttpStatus.NOT_FOUND);
			}else {
				
			}
			log.debug("Update additional data for Job ID:" + eSignTimestamp.getJobId());

		} catch (Exception e) {
			log.error("Unable to update additional data for job id:" + eSignTimestamp.getJobId(), e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		return new ResponseEntity<Object>(data, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = Utilities.APP_VERSION + "/job/couser/update", method = RequestMethod.GET)
	@ResponseBody
	public Object getAndUpdateAll() {
		try {
			HashMap<String, String> userMap = new HashMap<String, String>();
			
			ArrayList<User> users  = (ArrayList<User>) userRepo.findAll();
			users.forEach(user -> {
				String key = user.getFirstName() + user.getLastName();
				key = StringUtils.deleteWhitespace(key);
				key = StringUtils.lowerCase(key);
				userMap.put(key, user.getEmail());
			});;
			
			List<Job> jobs = jobService.getAll();
			
			jobs.forEach(job -> {

				String jobCF = StringUtils.deleteWhitespace(job.getCargoOfficer());
				jobCF = StringUtils.deleteWhitespace(jobCF);
				jobCF = StringUtils.lowerCase(jobCF);

				String jobCO = StringUtils.deleteWhitespace(job.getCargoOwner());
				jobCO = StringUtils.deleteWhitespace(jobCO);
				jobCO = StringUtils.lowerCase(jobCO);

				if (StringUtils.isNotEmpty(jobCF)) {
					
					System.out.println(jobCF+ ":"+ userMap.get(jobCF));
					

				}

				if (StringUtils.isNotEmpty(jobCO)) {
					System.out.println(jobCO+ ":"+ userMap.get(jobCO));

				}

			});
			
			
			
			
			
		} catch (Exception e) {
			log.error("Unable to get all users,", e);
			return new Exception("Internal Server Error");
		}
		return null;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/updatemode/{mode}", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> updatemode(@PathVariable("jobId") long jobId,
			@PathVariable("mode") int mode, @RequestParam(value = "Remarks") String Remarks) throws Exception {
		try {
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			if(Remarks.equals("null")){
				Remarks="";
			}
			 jobService.updatemode(jobId,mode,Remarks);
		} catch (Exception e) {
			log.error("Unable to update mode for job id " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>("Mode Updated Sucessfully", HttpStatus.OK);
	}
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/job/{jobId}/cleardatefields/{esignDateCleared}/{Screenname}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> cleardatefields(@PathVariable("jobId") long jobId,
			@PathVariable("esignDateCleared") int esignDateCleared, @PathVariable("Screenname") String Screenname) throws Exception {
		Calendar cal = Calendar.getInstance();
		try {
			if(esignDateCleared==1) {
				if(Screenname.equalsIgnoreCase("breq")) {
				 bdnDataRepository.clearDateFields(jobId);
				 Path filePath = Paths.get(fileupload+"\\"+cal.get(Calendar.YEAR)+"\\"+jobId+"\\"+"Bunker DeliveryNote.pdf");
				 fileService.deletedDocument(filePath.toString());
				}else if(Screenname.equalsIgnoreCase("meterticket")) {					
					 bdnDataRepository.clearDateFields(jobId);
					 Path filePath = Paths.get(fileupload+"\\"+cal.get(Calendar.YEAR)+"\\"+jobId+"\\"+"Bunker DeliveryNote.pdf");
					 fileService.deletedDocument(filePath.toString());
					 nOPDataRepository.clearDateFields(jobId);
					 filePath = Paths.get(fileupload+"\\"+cal.get(Calendar.YEAR)+"\\"+jobId+"\\"+"Note of Protest.pdf");
					 fileService.deletedDocument(filePath.toString());
					 mfmReadingRepository.clearDateFields(jobId);
					 filePath = Paths.get(fileupload+"\\"+cal.get(Calendar.YEAR)+"\\"+jobId+"\\"+"MFM Meter Reading.pdf");
					 fileService.deletedDocument(filePath.toString());
					}else {
						return new ResponseEntity<Object>("Unable to clear date fields", HttpStatus.OK);
					}
			}else {
				return new ResponseEntity<Object>("Unable to clear date fields", HttpStatus.OK);
			}
			 
		} catch (Exception e) {
			log.error("Unable to clear date fields " + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>("Date Cleared Sucessfully", HttpStatus.OK);
	}
	
	@RequestMapping(value = Utilities.APP_VERSION + "/uploadBinary/{printName}/{jobId}", method = RequestMethod.POST)
	@ResponseBody
    public String uploadBinaryDataForPrints(@PathVariable("jobId") Long jobId,HttpServletResponse response,
    		HttpServletRequest request,@PathVariable("printName") String printName,@RequestBody String data) throws Exception {
    			
		try {
			if(printName.equals("ebdn")) {
				bdnPartyRepository.updateBinaryData(data, jobId);
				
			}else if(printName.equals("breq")) {
				bunkerRequistionRepository.updateBinaryData(data, jobId);
				;
			}else if(printName.equals("safety")) {
				bunkerSafetyChecklistRepository.updateBinaryData(data, jobId);
			}else if(printName.equals("mfm")) {
				mfmReadingRepository.updateBinaryData(data, jobId);
			
			}else if (printName.equals("seals")) {
				mfmSealsChecklistRepository.updateBinaryData(data, jobId);
			}
			return "Updated Successfully";
	
   }catch(Exception ex) {
	   throw ex;
   }
}

	
	
public String uploadBinaryData(String data, Long jobId,String printName) {		
		try {
			if(printName.equals("ebdn")) {
				bdnPartyRepository.updateBinaryData(data, jobId);
				bdnPartyRepository.flush();
				
			}else if(printName.equals("breq")) {
				bunkerRequistionRepository.updateBinaryData(data, jobId);
				;
			}else if(printName.equals("safety")) {
				bunkerSafetyChecklistRepository.updateBinaryData(data, jobId);
			}else if(printName.equals("mfm")) {
				mfmReadingRepository.updateBinaryData(data, jobId);
			
			}else if (printName.equals("seals")) {
				mfmSealsChecklistRepository.updateBinaryData(data, jobId);
			}
	
   }catch(Exception ex) {
	   //throw ex;
   }
		return "Updated Successfully";
	}

@RequestMapping(value = Utilities.APP_VERSION + "/validationCheck/{jobId}", method = RequestMethod.GET)
@ResponseBody
public Object getValidationCheck (@PathVariable("jobId") Long jobId) {	
	List<Object[]> list=new ArrayList<>(); 
	List<HashMap<String,Object>> mapList = new ArrayList<HashMap<String,Object>>();
	try {
		list =jobRepository.jobValidationChecking(jobId);
		for (Object[] obj : list) {
			HashMap<String,Object> map=new HashMap<String,Object>();
		     map.put("isValidated", obj[0]);
		     map.put("remarks", obj[1]);
		     mapList.add(map);
		}

	}catch(Exception ex) {
   throw ex;
	}
	return mapList;
}
	
}
