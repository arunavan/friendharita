package com.india.bts.dib.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.india.bts.dib.domain.OcrResult;

public interface OcrResultRepository extends PagingAndSortingRepository<OcrResult, Long> {
	
	OcrResult findByJobId(long jobId);
	
}
