package com.india.bts.dib.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "bunker_data_publish_delivery")
@Data
@NoArgsConstructor
public class BunkerDeliveryReportEntity implements Serializable{/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="id")
	private Long id;
	@Column(name="barge_licence_no")
	private String bunkerTankerLicenceNo;
	@Column(name="barge_name")
	private String bunkerTankerName; 
	@Column(name ="bmt_number")
	private String bunkerMeteringTicketNo;
	@Column(name ="fuel_type_code")
	private String fuelTypeCode;
	@Column(name ="start_delivery_meter_totaliser")
	private BigDecimal startDeliveryMeterTotaliser;
	@Column(name ="start_loading_meter_totaliser")
	private BigDecimal startLoadingMeterTotaliser;
	@Column(name ="end_delivery_meter_totaliser")
	private BigDecimal endDeliveryMeterTotaliser;
	@Column(name ="end_loading_meter_totaliser")
	private BigDecimal endLoadingMeterTotaliser;
	@Column(name ="operation_date")
	private String operationDate;
	@Column(name ="totalisersAutoPopulated")
	private String totalisersAutoPopulated;
	@Column(name ="reason_not_auto_populated")
	private String reasonNotAutoPopulated;
	@Column(name ="supplier_name")
	private String bunkerSupplierName;
	@Column(name ="bunker_supplier_uen")
	private String bunkerSupplierUEN;
	@Column(name="bdn_number")
	private String bdnNo;
	@Column(name="vessel_name")
	private String receiveVesselName;
	@Column(name="vessel_imo")
	private String receiveVesselImoNo;
	@Column(name="gross_tonnage")
	private BigDecimal receiveVesselGst;
	@Column(name ="code")
	private String deliveryLocationCode;
	@Column(name ="name")
	private String deliveryLocationName;
	@Column(name ="delivery_type")
	private int deliveryType;
	@Column(name ="supply_type")
	private String supplyType;
	@Column(name ="mfm_supplied_quantity")
	private BigDecimal suppliedQuantityMFM;
	@Column(name ="bdn_supplied_quantity")
	private BigDecimal suppliedQuantityBDN;
	@Column(name ="commence_pumping_time")
	private String commencePumpingTime;
	@Column(name ="complete_pumping_time")
	private String completePumpingTime;
	@Column(name ="alongside_time")
	private String alongsideTime;
	@Column(name ="castoff_time")
	private String castOffTime;
	@Column(name ="duration_of_delivery")
	private String durationOfDelivery;
	@Column(name ="customer_rating")
	private int customerRating;
	@Column(name ="protest_note")
	private String protestNote;
	@Column(name ="bdn_file_binary")
	private String bdnFile;
	

}
