package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.india.bts.dib.domain.SOFData;
import com.india.bts.dib.domain.Sof;

public interface SOFDataRepository extends JpaRepository<Sof, Long> {
	
	Sof findByJobId(long jobId);

	@Modifying
	@Transactional
	@Query(value="UPDATE job_sof SET sof_file_binary= :sof_file_binary WHERE job_id = :jobId ", nativeQuery=true)
	void updateBinaryData(@Param("sof_file_binary") String sof_file_binary,@Param("jobId") Long jobId);
	
}
