/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _________________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.controller;


import static com.india.bts.dib.security.SecurityConstants.HEADER_VESSEL_IMO;
import static com.india.bts.dib.security.SecurityConstants.HEADER_VESSEL_NAME;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.india.bts.dib.domain.BunkerDeliveryReportEntity;
import com.india.bts.dib.dto.BunkerDeliveryNoteToIbmsWithAttachments;
import com.india.bts.dib.dto.BunkerDeliveryReport;
import com.india.bts.dib.dto.BunkerDeliveryReportDTO;
import com.india.bts.dib.dto.Meta;
import com.india.bts.dib.dto.OnBehalfOf;
import com.india.bts.dib.dto.Participants;
import com.india.bts.dib.repository.ApplicationUserRepository;
import com.india.bts.dib.repository.BunkerDeliveryReportEntityRepository;
import com.india.bts.dib.service.RestService;
import com.india.bts.dib.utils.Constants;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class UtilsController {

	@Autowired
	RestService restService;
	@Autowired
	BunkerDeliveryReportEntityRepository bunkerDeliveryReportEntityRepository;

	public UtilsController(ApplicationUserRepository applicationUserRepository) {
	}
	

	@RequestMapping(value = Utilities.APP_VERSION + "/vgst", method = RequestMethod.GET)
	@ResponseBody
	public String getVesselGrossTonnage(HttpServletRequest request) throws IOException {
		log.info("Calling Vessel GST");
		try {
			String vesselIMO = request.getHeader(HEADER_VESSEL_IMO);
			String vesselName = request.getHeader(HEADER_VESSEL_NAME);
			String data = "{\"vessel_imo\":\""+vesselIMO+"\", \"vessel_name\":\""+vesselName+"\"}";
			return restService.getVesselGrossTonnage(data);
		} catch (Exception e) {
			log.error("Unable to get user with token, error: ", e);
			throw new IOException("Error while calling MPA Vessel API");
		}
	}
	
	@RequestMapping(value = Utilities.APP_VERSION + "/getVesselDataAndGST", method = RequestMethod.GET)
	@ResponseBody
	public Object getVesselDataAndGST(HttpServletRequest request) throws Exception {
		log.info("Calling Vessel GST");
		try {
			String vesselIMO = request.getHeader(HEADER_VESSEL_IMO);
			String vesselName = request.getHeader(HEADER_VESSEL_NAME);
			String data = "{\"imoNumber\":\""+vesselIMO+"\", \"vesselName\":\""+vesselName+"\"}";
			return restService.getVesselDataAndGST(data,vesselIMO,vesselName);
		} catch (Exception e) {
			log.error("Unable to get Vessel GST, error: ", e);
			throw e;
			
		}
	}
	@RequestMapping(value = Utilities.APP_VERSION + "/generateToken", method = RequestMethod.GET)
	@ResponseBody
	public Object generateToken(HttpServletRequest request) throws Exception {
		try {
			return restService.generateToken();
		} catch (Exception e) {
			log.error("Unable to get user with token, error: ", e);
			throw e;
			
		}
	}
	
	@RequestMapping(value = Utilities.APP_VERSION + "/runMPAPublisher", method = RequestMethod.GET)
	@ResponseBody
	public String getRunMPAPublisher(HttpServletRequest request) {
		log.info("Calling MPA Publisher API");
		try {
			restService.runMPAPublisher();
			return "MPA Published Successfully";
		} catch (Exception e) {
			log.error("Unable to get MPA Publisher API ", e);
			
		}
		return null;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION + "/runMPAPublisher/{jobId}", method = RequestMethod.GET)
	@ResponseBody
	public String getRunMPAPublisherWithJobId(HttpServletRequest request,@PathVariable("jobId") Long jobId) {
		log.info("Calling MPA Publisher API");
		try {
			String data = "{\"job_id\":"+jobId+"}";
			return restService.runMPAPublisherWithJobId(data);
		} catch (Exception e) {
			log.error("Unable to get MPA Publisher API ", e);
			
		}
		return null;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION + "/blockChainRegistration/{jobId}", method = RequestMethod.GET)
	@ResponseBody
	public String getBlockChainRegistration(@PathVariable("jobId") Long jobId,HttpServletRequest request) {
		log.info("Calling MPA Block chain API");
		try {
			String data = "{\"job_id\":"+jobId+"}";
			return restService.blockChainRegistration(data);
		} catch (Exception e) {
			log.error("Unable to get MPA Block Chain API ", e);
			
		}
		return null;
	}
	@RequestMapping(value = Utilities.APP_VERSION + "/pushToSGTradex/{jobId}", method = RequestMethod.GET)
	@ResponseBody
	public String pushToSGTradex(@PathVariable("jobId") Long jobId) throws Exception {
		log.info("Calling push SGTradex API");
		BunkerDeliveryReportDTO dto = new BunkerDeliveryReportDTO();
		 ObjectMapper mapper = new ObjectMapper();
		try {
			BunkerDeliveryReportEntity data = new BunkerDeliveryReportEntity();
			List<BunkerDeliveryReport> payload = new ArrayList<>();
			List<OnBehalfOf> on_behalf_of_List =new ArrayList<>();
			List<Participants> participants_List =new ArrayList<>();
			HashMap<String,Object> map=new HashMap<String,Object>();
			List<HashMap<String,Object> > attachments =new ArrayList<>();
			BunkerDeliveryReport obj = new BunkerDeliveryReport();
			OnBehalfOf on_behalf_of = new OnBehalfOf();
			Meta meta = new Meta();
			Participants participants = new Participants();
			
			data =bunkerDeliveryReportEntityRepository.findByJobId(jobId);
			BeanUtils.copyProperties(obj, data);
			// attachments object creation
			map.put("filename", "ebdn_file.pdf");
			map.put("file_content", data.getBdnFile());
			attachments.add(map);
			// payload construction
			obj.setAttachments(attachments);
			obj.setVendorUen(Constants.VendorUen);
			obj.setAlongsideTime(Utilities.dateFormat(obj.getAlongsideTime()));
			obj.setCastOffTime(Utilities.dateFormat(obj.getCastOffTime()));
			obj.setProtestNote("N");
			payload.add(obj);
			// on behalf_of Object Creation
			on_behalf_of.setId(Constants.ON_BEHALF_OF);
			on_behalf_of_List.add(on_behalf_of);
			// participants object Creation
			participants.setId(Constants.PARTICIPANT_ID);
			participants.setName(Constants.PARTICIPANT_NAME);
			meta.setData_ref_id("");
			participants.setMeta(meta);
			participants_List.add(participants);
			dto.setParticipants(participants_List);
			dto.setOn_behalf_of(on_behalf_of_List);
			dto.setPayload(payload);
			String json = mapper.writeValueAsString(dto);
			return restService.pushToSGTradex(json,jobId);
		} catch (Exception e) {
			log.error("Unable to push SGTradex API ", e);
			throw e;
			
		}
	}
	
	
	
}
