/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _______________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.india.bts.dib.domain.EmailContent;

public interface EmailContentRepository extends PagingAndSortingRepository<EmailContent, Long>{

	@Query(value="SELECT * from email_content c where c.survey_job_id=?1 ", nativeQuery=true)
	void deleteByJobId(Long jobId);
	
	@Query(value="SELECT * from email_content c where c.survey_job_id=?1 ORDER BY id DESC LIMIT 1;", nativeQuery=true)
	EmailContent getBySurveyJobId(Long jobId);
}
