package com.india.bts.dib.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.india.bts.dib.domain.File;

@Repository
public interface DBFileRepository extends JpaRepository<File, Long>{
	
	List<File> findByJobId(long jobId);
	
	List<File> findByJobIdAndDocumentTypeOrderByIdDesc(long jobId, String documentType);
	
	
	@Query(value ="select* from files where jobId =:jobId order by id desc limit 1",nativeQuery =true)
	File getLatestMeterTicket(@Param("jobId")Long jobId);

}
