package com.india.bts.dib.repository;

import java.time.LocalDateTime;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.india.bts.dib.domain.JobDeliveryAuditlog;

public interface JobDeliveryAuditlogRepo extends JpaRepository<JobDeliveryAuditlog,Long> {

	@Modifying
	@Transactional
	@Query(value="update Job_Delivery_Auditlog set Is_Sync =?3,Pull_Date =?2 where Job_Id =?1",nativeQuery =true)
	void updateAuditLog(Long id, LocalDateTime now, int isSync);

}
