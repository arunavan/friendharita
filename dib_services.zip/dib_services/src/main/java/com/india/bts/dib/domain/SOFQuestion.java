package com.india.bts.dib.domain;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="sof_question") 
public class SOFQuestion implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -11300308776453888L;

	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=true,name="question_text",length=1000)
    private String questionText;

	@OneToMany(mappedBy="sofQuestion",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private List<SOFQuestionOption> sofQuestionOptions;
	
	
	@ManyToOne
	@JsonIgnore
    private SOFData sofData;
								  
}
