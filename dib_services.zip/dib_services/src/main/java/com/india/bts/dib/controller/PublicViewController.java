package com.india.bts.dib.controller;

import java.util.Base64;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.BDNData;
import com.india.bts.dib.domain.Job;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.service.JobServiceImpl;
import com.india.bts.dib.service.RestService;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class PublicViewController {

	@Autowired
	JobServiceImpl jobService;
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	RestService restService;
	@Autowired
	CurrentUserService currentUserService;


	@RequestMapping(value = Utilities.APP_VERSION + "/job/pv/{id}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> get(@PathVariable("id") long id) {
//		Optional<Job> job = null;
		Job job = null;
		try {	
			job = jobService.getById(id);
		} catch (Exception e) {
			log.error("Unable to get job", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
//		return new ResponseEntity<Object>(job.get(), HttpStatus.OK);
		return new ResponseEntity<Object>(job, HttpStatus.OK);

	}


	@RequestMapping(value = Utilities.APP_VERSION + "/job/pv/{jobId}/bdn-data", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getBDNData(@PathVariable("jobId") long jobId) {
		BDNData bdnData = null;
		try {
			Job job = jobService.getById(jobId);
			bdnData = jobService.getBDNData(jobId);
		} catch (Exception e) {
			log.error("Unable to get BDN data for job id:" + jobId, e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(bdnData, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/download/pv/ebdn/{jobId}", method = RequestMethod.GET)
	@ResponseBody
    public ResponseEntity<byte[]> downloadeBDNDocument(@PathVariable("jobId") Long jobId,HttpServletResponse response) {
    	
    	BDNData bdnData = jobService.getBDNData(jobId);
		HttpHeaders httpHeaders = new HttpHeaders();
		byte[] bytes = null;
		if(bdnData != null && StringUtils.isNotBlank(bdnData.getBdnFileBinary())) {
			bytes = Base64.getDecoder().decode(bdnData.getBdnFileBinary());
	        httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF_VALUE); // (3) Content-Type: application/octet-stream
	        httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.inline().build().toString());
	        
	        return ResponseEntity.ok().headers(httpHeaders).body(bytes); // (5) Return Response
		}else {
			return ((BodyBuilder) ResponseEntity.notFound().headers(httpHeaders)).body(bytes);
		}
   }

}
