package com.india.bts.dib.dto;

import java.util.HashMap;
import java.util.List;

import com.india.bts.dib.domain.FilesData;

import lombok.Data;

@Data
public class BunkerLoadingToIbmsWithAttachments {
	
	private Long id;
	private String bunkerTankerLicenceNo;
	private String bunkerTankerName; 
	private String bunkerMeteringTicketNo;
	private String fuelTypeCode;
	private String startDeliveryMeterTotaliser;
	private String startLoadingMeterTotaliser;
	private String endDeliveryMeterTotaliser;
	private String endLoadingMeterTotaliser;
	private String operationDate;
	private String totalisersAutoPopulated;
	private String reasonNotAutoPopulated;
	private String loadNo;
	private String terminalOplCode;
	private String terminalOplName;
	private String loadType;
	private String agreedLoadQuantity;
	private String bmtLoadQuantity;
	private String berthingTime;
	private String loadingTime;
	private String completionTime;
	private String departureTime;
	private String durationAlongsideBerth;
	private List<FilesData> attachments ;

}
