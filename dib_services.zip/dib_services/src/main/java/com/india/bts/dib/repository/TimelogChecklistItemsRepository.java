package com.india.bts.dib.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.india.bts.dib.domain.TimelogChecklistItems;

public interface TimelogChecklistItemsRepository extends JpaRepository<TimelogChecklistItems, Long> {


	@Modifying
	@Transactional
	@Query(value = "delete from timelog_checklist_items where timelogChecklist_id = ?1", nativeQuery = true)
	void deleteAllByTimelogChecklistId(long id);

}
