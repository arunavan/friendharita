/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _______________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.controller;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.EmailContent;
import com.india.bts.dib.repository.EmailContentRepository;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.service.MailContentBuilder;
import com.india.bts.dib.utils.Constants;
import com.india.bts.dib.utils.EmailContentBuilder;
import com.india.bts.dib.utils.ResponseObject;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class EmailController {
	
	@Autowired
	JavaMailSender mailSender;
	@Autowired
	MailContentBuilder mailContentBuilder;
	@Autowired
	CurrentUserService currentUserService;
	@Autowired
	EmailContentRepository emailContentRepository;
	@Autowired
	EmailContentBuilder emailContentBuilder;
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/emailcontent", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> updateEmailContent(@RequestBody EmailContent emailContentDto) {
		EmailContent emailContent = null;
		try {
			emailContent = new EmailContent(emailContentDto);
			Utilities.updateAuditInfo(emailContent, emailContentRepository.findById(emailContentDto.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			if (StringUtils.isBlank(emailContent.getFromEmailId())) {
				emailContent.setFromEmailId(Constants.EMAIL_FROM_EMAIL_ID);
			}
			String emailBody = replaceDateWithDateToken(emailContent.getBody());
			emailContent.setBody(emailBody);
			emailContent = emailContentRepository.save(emailContent);
		} catch (Exception e) {
			log.error("unable to update emailContent with id: " + emailContentDto.getId(), e);
			return new ResponseEntity<Object>(
					new ResponseObject(500, "Internal Server Error, unable to update emailContent with id :"
							+ emailContentDto.getId() + e.getMessage(), null, true),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(
				new ResponseObject(200, "Updated email conent with id : " + emailContent.getId(), emailContent, true),
				HttpStatus.OK);
	}

	public String replaceDateWithDateToken(String body) {
		String updatedEmailBody = body;
		if (StringUtils.isNotBlank(body)) {
			String dt = StringUtils.substringBetween(body, "DD:", "</p>");
			if (StringUtils.isBlank(dt)) {
				dt = StringUtils.substringBetween(body, "Dd:", "</p>");
			}
			log.debug("Extracted date is :" + dt);
			updatedEmailBody = StringUtils.replace(body, dt, "<b> ^^DATE^^</b>");
		}
		return updatedEmailBody;
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/emailcontent/{emailcontentId}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getEmailContentById(@PathVariable("emailcontentId") Long emailContentId) {
		EmailContent emailContent = null;
		try {
			emailContent = emailContentRepository.findById(emailContentId).orElse(null);
		} catch (Exception e) {
			log.error("Uanble to get Email Content with id: " + emailContentId, e);
			return new ResponseEntity<Object>(new ResponseObject(500,
					"Internal Server Error, Email Content with id: " + emailContentId + e.getMessage(), null, true),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(
				new ResponseObject(200, "Email Content with id :" + emailContentId, emailContent, true), HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/emailcontent/by-job/{jobId}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getEmailContentByJobId(@PathVariable("jobId") Long jobId) {
		EmailContent emailContent = null;
		try {
			emailContent = emailContentRepository.getBySurveyJobId(jobId);
		} catch (Exception e) {
			log.error("Uanble to get Email Content with id: " + jobId, e);
			return new ResponseEntity<Object>(new ResponseObject(500,
					"Internal Server Error, Email Content with id: " + jobId + e.getMessage(), null, true),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(
				new ResponseObject(200, "Email Content with id :" + jobId, emailContent, true), HttpStatus.OK);
	}

	
	@RequestMapping(value = Utilities.APP_VERSION+ "/emailcontent/{email_contnent_id}/sendmail", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Object> sendEmailByContentById(@PathVariable("email_contnent_id") Long emailContentId) {
		String result = null;
		try {
			EmailContent emailContent = emailContentRepository.findById(emailContentId).orElse(null);
			if(emailContent != null) {
				emailContent.setBody(StringUtils.replace(emailContent.getBody(), "^^DATE^^", Utilities.getTodaysDate()));
				result = emailContentBuilder.sendEmailWithContent(emailContent);
			}else {
				return new ResponseEntity<Object>(new ResponseObject(404,"Email content not found for id: "+emailContentId+", So unable to send email.", null, true),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		} catch (Exception e) {
			log.error("Internal Server Error while sending email, error: ", e);
			return new ResponseEntity<Object>(
					new ResponseObject(500,
							"Internal Server Error, while sending job details email to surveyor" + e.getMessage(), null, true),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(new ResponseObject(200, "Email Sent", result, true), HttpStatus.OK);
	}
	
	}