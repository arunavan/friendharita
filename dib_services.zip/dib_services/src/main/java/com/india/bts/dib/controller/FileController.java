/*******************************************************************************
 * BTS INDIA COPYRIGHT
 * ___________________
 *   
 * [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 * All Rights Reserved.
 *   
 * NOTICE:  All information contained herein is, and remains
 * the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 * and its suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/

package com.india.bts.dib.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.india.bts.dib.domain.Attachment;
import com.india.bts.dib.domain.BDNData;
import com.india.bts.dib.domain.BunkerRequisitionData;
import com.india.bts.dib.domain.BunkerSafetyChecklistData;
import com.india.bts.dib.domain.CargoLoadingData;
import com.india.bts.dib.domain.File;
import com.india.bts.dib.domain.Job;
import com.india.bts.dib.domain.MFMReadingData;
import com.india.bts.dib.domain.MFMSealsChecklistData;
import com.india.bts.dib.domain.NOPData;
import com.india.bts.dib.domain.Reports;
import com.india.bts.dib.domain.Sof;
import com.india.bts.dib.domain.TimelogData;
import com.india.bts.dib.repository.AttachmentRepository;
import com.india.bts.dib.repository.DBFileRepository;
import com.india.bts.dib.repository.ReportsRepository;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.service.AsynServices;
import com.india.bts.dib.service.DBFileServiceImpl;
import com.india.bts.dib.service.FileStorageService;
import com.india.bts.dib.service.JobServiceImpl;
import com.india.bts.dib.service.RestService;
import com.india.bts.dib.utils.Constants;
import com.india.bts.dib.utils.ResponseObject;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class FileController {

	@Autowired
	DBFileServiceImpl dbFileService;
	@Autowired
	AttachmentRepository attachmentRepository;
	@Autowired
	RestService restService;
	@Autowired
	JobServiceImpl jobService;
	@Autowired
	CurrentUserService currentUserService;
	@Autowired
	DBFileRepository dbFileRepository;
	@Autowired
	AsynServices asynServices;
	@Autowired
	DocumentController documentController;
	@Autowired
	JobController jobController;
	@Autowired
	FileStorageService fileService;
	
	@Autowired
	ReportsRepository reportsRepository;
	
	@RequestMapping(value = Utilities.APP_VERSION+ "/file-upload/{jobId}", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@ResponseBody
	public Object fileUpload(@PathVariable("jobId") Long jobId, @RequestParam("file") MultipartFile[] files, @RequestParam(defaultValue = "false") boolean isOCR, HttpServletResponse res) throws IOException, Exception{
		File document = null;
		try{
			log.info("File with started.");
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			Long maxFileSizeInMB = 10L*1024L* 1024L;
			for (MultipartFile multipartFile : files) {
				if(multipartFile.getSize() < maxFileSizeInMB  && multipartFile.getSize() > 0) {
					String encodedString = Base64.getEncoder().encodeToString(multipartFile.getBytes());
					if(isOCR) {
						document = new File(jobId,multipartFile.getOriginalFilename(),"METER_TICKET", encodedString,multipartFile.getSize(), null); 

					}else {
						document = new File(jobId,multipartFile.getOriginalFilename(),null, encodedString,multipartFile.getSize(), null); 

					}
					document = dbFileService.save(document);
					log.info("File with "+multipartFile.getOriginalFilename()+" uploaded.");

				}else {
					return new Exception("File size is not in limit, allowed file size limit 0 to 10MB ");
				}
			}
			
			if(isOCR)
			{
				document.setOcrContent(restService.getOCRText(document.getContent()));
			}
		}catch (Exception e) {
			log.error("Unable to upload file",e);
			e.printStackTrace();
			return new Exception("Internal Server Error,Unable to upload file, possible error: "+e.getMessage());
		} 
		return document;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION+ "/attachment", method = RequestMethod.POST)
	public Object uploadAttachment(@RequestBody Attachment dto) throws IOException, Exception{
		byte[] bytes = null;
		String targetPath="";
		Resource fileResource=null;
		String contentType = null;
		String strAttachment = "";
		String strDownloadType ="";
		String reportPath ="";
		String subReportPath = "";
		String reqSubreport = "";
		byte[] dataList = null;
		String folderName="";
		try{
			
			Job job = jobService.getById(dto.getJobId());
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			
			if(dto.getWorkflow().equalsIgnoreCase("VESSEL_STAMPS") || dto.getWorkflow().equalsIgnoreCase("SURVEYOR_STAMPS") ) {
				List<Attachment>  documents = attachmentRepository.findByJobIdAndWorkflow(dto.getJobId(), dto.getWorkflow());

				if(documents != null && documents.size() > 0) {
					dto.setId(documents.get(0).getId());
				}
			}
			dto = attachmentRepository.save(dto);
			if(!dto.getWorkflow().equalsIgnoreCase("VESSEL_STAMPS") && !dto.getWorkflow().equalsIgnoreCase("SURVEYOR_STAMPS")) {
				dbFileService.savecontent(dto,null, null);
				asynServices.saveAttachment(dto.getJobId(), 10, 1, dto.getContent(),dto.getFileName() , 10);
				}
			else {
				asynServices.generateBinaryData(dto.getJobId(), "C:\\EBDN\\Templates\\BunkerReq.jrxml","breq",Constants.moduleId_Delivery,Constants.transactionId_Req);
				asynServices.generateBinaryData(dto.getJobId(), "C:\\EBDN\\Templates\\Safety_Checklist.jrxml","safety",Constants.moduleId_Delivery,Constants.transactionId_Safety);
				asynServices.generateBinaryData(dto.getJobId(), "C:\\EBDN\\Templates\\MFMReading.jrxml","mfm",Constants.moduleId_Delivery,Constants.transactionId_mfm);
				asynServices.generateBinaryData(dto.getJobId(), "C:\\EBDN\\Templates\\Seals_Checklist.jrxml","seals",Constants.moduleId_Delivery,Constants.transactionId_Seals);
				//asynServices.generateBinaryData(dto.getJobId(), "C:\\EBDN\\Templates\\NOP.jrxml","nop");
//				String binaryString=documentController.generateBinaryData(dto.getJobId(), "C:\\EBDN\\Templates\\BDNData.jrxml");
//				jobController.uploadBinaryData(binaryString,dto.getJobId(),"ebdn");
//				folderName ="Bunker DeliveryNote.pdf";
//				dataList = Base64.getDecoder().decode(binaryString);
//				ByteArrayOutputStream buffer = new ByteArrayOutputStream();
//				buffer.write(dataList);
//				targetPath =fileService.storeFile(folderName, buffer,dto.getJobId());
//				fileResource=fileService.loadFileAsResource(targetPath);
				}
	
		}catch (Exception e) {
			log.error("Unable to upload file",e);
			return new Exception("Internal Server Error,Unable to upload file, possible error: "+e.getMessage());
		} 
		return dto;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION+ "/attachment/{jobId}", method = RequestMethod.GET)
	public Object getAttachments(@PathVariable("jobId") Long jobId) throws IOException, Exception{
		List<Attachment>  documents = new ArrayList<>();
		try{
			
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			documents = attachmentRepository.findByJobId(jobId);
		} catch (Exception e) {
			log.error("Unable to get documents with id:"+jobId,e);
			return new Exception("Internal Server Error,Unable to get documents with id, possible error: "+e.getMessage());
		}
		return documents;
	}
	@RequestMapping(value = Utilities.APP_VERSION+ "/attachment/fileNames/{jobId}", method = RequestMethod.GET)
	public Object getAttachmentFileNmaes(@PathVariable("jobId") Long jobId) throws IOException, Exception{
		List<Attachment>  documents = new ArrayList<>();
		List<Object[]> list=new ArrayList<>(); 
		List<HashMap<String,Object>> mapList = new ArrayList<HashMap<String,Object>>();
		
		try{
			list = attachmentRepository.getFileNames(jobId);
			for (Object[] obj : list) {
				HashMap<String,Object> map=new HashMap<String,Object>();
			     map.put("id", obj[0]);
			     map.put("fileName", obj[1]);
			     mapList.add(map);
			}
			
		} catch (Exception e) {
			log.error("Unable to get documents names with id:"+jobId,e);
			return new Exception("Internal Server Error,Unable to get documents nameswith id, possible error: "+e.getMessage());
		}
		return mapList;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION+ "/attachment/{workflow}/{jobId}", method = RequestMethod.GET)
	public Object getWorflowAttachments(@PathVariable("workflow") String workflow, @PathVariable("jobId") Long jobId) throws IOException, Exception{
		List<Attachment>  documents = null;
		try{
			documents = attachmentRepository.findByJobIdAndWorkflow(jobId, workflow);
		} catch (Exception e) {
			log.error("Unable to get documents with id:"+jobId,e);
			return new Exception("Internal Server Error,Unable to get documents with id, possible error: "+e.getMessage());
		}
		return documents;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION+ "/attachment/VESSEL_STAMPS/{jobId}", method = RequestMethod.GET)
	public Object getVesselStamps(@PathVariable("jobId") Long jobId) throws IOException, Exception{
		Attachment  document = null;
		try{
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			List<Attachment>  documents = attachmentRepository.findByJobIdAndWorkflow(jobId, "VESSEL_STAMPS");
			if(documents != null && documents.size() > 0) {
				document = documents.get(0);
			}
		} catch (Exception e) {
			log.error("Unable to get documents with id:"+jobId,e);
			return new Exception("Internal Server Error,Unable to get documents with id, possible error: "+e.getMessage());
		}
		return document;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION+ "/attachment/SURVEYOR_STAMPS/{jobId}", method = RequestMethod.GET)
	public Object getSurveyorStamps( @PathVariable("jobId") Long jobId) throws IOException, Exception{
		Attachment  document = null;
		try{
			Job job = jobService.getById(jobId);
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(job.getBargeId())) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			List<Attachment>  documents = attachmentRepository.findByJobIdAndWorkflow(jobId, "SURVEYOR_STAMPS");
			if(documents != null && documents.size() > 0) {
				document = documents.get(0);
			}
		} catch (Exception e) {
			log.error("Unable to get documents with id:"+jobId,e);
			return new Exception("Internal Server Error,Unable to get documents with id, possible error: "+e.getMessage());
		}
		return document;
	}
	
	
	
	@RequestMapping(value = Utilities.APP_VERSION+ "/attachment/{id}", method = RequestMethod.DELETE)
	public void deleteAttachment(@PathVariable("id") Long id) throws IOException, Exception{
		Optional<Attachment> data =null;
		try{
			data = attachmentRepository.findById(id);
			 attachmentRepository.deleteById(id);
			 reportsRepository.deleteByJobIdAndReportName(data.get().getJobId(),data.get().getFileName());
			 
		} catch (Exception e) {
			log.error("Unable to get documents with id:"+id,e);
		}
		
	}
	
	
	@RequestMapping(value = Utilities.APP_VERSION + "/file-upload/{documentType}/{jobId}", method = RequestMethod.GET)
	@ResponseBody
	public Object getDocumentesForDocumentTypeAndJobId(@PathVariable("documentType") String documentType, @PathVariable("jobId") Long jobId) {
		List<File> documents = new ArrayList<>();
		try {
			documents = dbFileService.findByJobIdAndDocumentType(jobId, documentType) ;
			
			for (File file : documents) {
				file.setMeterTicketContent(file.getContent());
			}
		} catch (Exception e) {
			log.error("Unable to get documents with id:"+jobId,e);
			return new Exception("Internal Server Error,Unable to get documents with id, possible error: "+e.getMessage());
		}
		return documents;
	}	
	
	@RequestMapping(value = Utilities.APP_VERSION + "/file-upload/{jobId}", method = RequestMethod.GET)
	@ResponseBody
	public Object getDocumentesForJobId(@PathVariable("jobId") Long jobId) {
		List<File> documents = new ArrayList<>();
		try {
			documents = dbFileService.findByJobId(jobId) ;
		} catch (Exception e) {
			log.error("Unable to get documents with id:"+jobId,e);
			return new Exception("Internal Server Error,Unable to get documents with id, possible error: "+e.getMessage());
		}
		return documents;
	}	
		
	@RequestMapping(value = Utilities.APP_VERSION + "/download/{printName}/{jobId}", method = RequestMethod.GET)
	@ResponseBody
    public ResponseEntity<byte[]> downloadeBDNDocument(@PathVariable("jobId") Long jobId,@PathVariable("printName") String printName,HttpServletResponse response) {
    	HttpHeaders httpHeaders = new HttpHeaders();
		byte[] bytes = null;
		httpHeaders.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE); // (3) Content-Type: application/octet-stream
		if(printName.equals("ebdn")) {
			BDNData bdnData = jobService.getBDNData(jobId);
			//implemented the common attachment table to increase the performance
			//Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
			if(bdnData != null && StringUtils.isNotBlank(bdnData.getBdnFileBinary())) {
				bytes = Base64.getDecoder().decode(bdnData.getBdnFileBinary());
				httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("Bunker Delivery Note").build().toString()); // (4) Content-Disposition: attachment; filename="demo.txt"
			}
		}else if(printName.equals("breq")){
			//BunkerRequisitionData data = jobService.getBunkerRequisition(jobId);	
			Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
			if(data != null && StringUtils.isNotBlank(data.getReportFileBinary())) {
				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
				httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("Bunker Requisition").build().toString()); 
			}	
		}else if(printName.equals("safety")) {
			//BunkerSafetyChecklistData bunkerSafetyChecklistData = jobService.getBunkerSafetyChecklist(jobId);
			Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
			if(data != null && StringUtils.isNotBlank(data.getReportFileBinary())) {
				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
				httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("Bunker Safety Checklist").build().toString()); 
			}	
		}else if(printName.equals("seals")) {
			//MFMSealsChecklistData mfmSealsChecklistData = jobService.getMFMSealsChecklist(jobId);
			Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
			if(data != null && StringUtils.isNotBlank(data.getReportFileBinary())) {
				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
				httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("MFM Seals checklist").build().toString()); 
			}		
		}else if(printName.equals("mfm")) {
			//MFMReadingData mfmData = jobService.getMFMReadingData(jobId);
			Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
			if(data != null && StringUtils.isNotBlank(data.getReportFileBinary())) {
				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
				httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("MFM Meter Reading").build().toString()); 
			}
		}else if(printName.equals("nop")) {
			//NOPData bdnData = jobService.getNOPData(jobId);
			Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
			if(data != null && StringUtils.isNotBlank(data.getReportFileBinary())) {
				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
				httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("Note of Protest").build().toString()); 
			}
		}else if(printName.equals("cargoloading")){
			//CargoLoadingData bdnData = jobService.getCargoLoadingData(jobId);	
			Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
			if(data != null && StringUtils.isNotBlank(data.getReportFileBinary())) {
				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
				httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("CargoLoading").build().toString()); 
			}	
		}else if(printName.equals("timelog")){
			//TimelogData	timelogData = jobService.getTimelogData(jobId);
			Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
			if(data != null && StringUtils.isNotBlank(data.getReportFileBinary())) {
				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
				httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("TimeLog").build().toString()); 
			}	
		}else if(printName.equals("sof")){
			//Sof sofData = jobService.getSOFData(jobId);
			Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
			if(data != null && StringUtils.isNotBlank(data.getReportFileBinary())) {
				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
				httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename("SOF").build().toString()); 
			}	
		}else if(printName.equals("meterticket")) {
			File file=dbFileRepository.getLatestMeterTicket(jobId);
			if(file!= null && StringUtils.isNotBlank(file.getContent())) {
				bytes = Base64.getDecoder().decode(file.getContent());
				httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(file.getFileName()).build().toString());
			}	
		}else {
			Optional<Attachment> dto=attachmentRepository.findById(Long.parseLong(printName));
			if(dto!= null && StringUtils.isNotBlank(dto.get().getContent())) {
			if(FilenameUtils.getExtension(dto.get().getFileName()).equals("pdf")) {
				bytes = Base64.getDecoder().decode(dto.get().getContent().substring(28));
			}else if(FilenameUtils.getExtension(dto.get().getFileName()).equals("jfif")||FilenameUtils.getExtension(dto.get().getFileName()).equals("jpeg")
					||FilenameUtils.getExtension(dto.get().getFileName()).equals("jpg")) {
			bytes = Base64.getDecoder().decode(dto.get().getContent().substring(23));
			}
			httpHeaders.set(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment().filename(dto.get().getFileName()).build().toString()); 
			}
		}
	       return ResponseEntity.ok().headers(httpHeaders).body(bytes); // (5) Return Response
		
   }
    
    
	
//	@RequestMapping(value=Utilities.version+"/file-upload/{fileId}", method = RequestMethod.DELETE)
//	@ResponseBody
//	public Object delete(@PathVariable("fileId") Long fileId) {
//		try{
//			documentRepository.deleteFileById(fileId);
//		}catch (Exception e) {
//			log.error("Unable to delete file with id: "+fileId,e);
//			return new Exception("Internal Server Error, Unable to delete file with id: "+fileId,e);
//		}
//		return new ResponseObject(200, "Deleted file with id: "+fileId ,null, true);
//	}
//	
}
 