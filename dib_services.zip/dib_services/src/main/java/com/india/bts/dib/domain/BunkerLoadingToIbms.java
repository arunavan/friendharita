package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "mpa_published_loading_jobs")
@Data
@NoArgsConstructor
public class BunkerLoadingToIbms implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="id")
	private Long id;
	@Column(name="barge_licence_no")
	private String bunkerTankerLicenceNo;
	@Column(name="barge_name")
	private String bunkerTankerName; 
	@Column(name ="bmt_number")
	private String bunkerMeteringTicketNo;
	@Column(name ="fuel_type_code")
	private String fuelTypeCode;
	@Column(name ="start_delivery_meter_totaliser")
	private String startDeliveryMeterTotaliser;
	@Column(name ="start_loading_meter_totaliser")
	private String startLoadingMeterTotaliser;
	@Column(name ="end_delivery_meter_totaliser")
	private String endDeliveryMeterTotaliser;
	@Column(name ="end_loading_meter_totaliser")
	private String endLoadingMeterTotaliser;
	@Column(name ="operation_date")
	private String operationDate;
	@Column(name ="totalisersAutoPopulated")
	private String totalisersAutoPopulated;
	@Column(name ="reason_not_auto_populated")
	private String reasonNotAutoPopulated;
	@Column(name ="loadno")
	private String loadNo;
	@Column(name ="code")
	private String terminalOplCode;
	@Column(name ="name")
	private String terminalOplName;
	@Column(name ="loadtype")
	private String loadType;
	@Column(name ="agreedloadquantity")
	private String agreedLoadQuantity;
	@Column(name ="mfm_quantity")
	private String bmtLoadQuantity;
	@Column(name ="berthingtime")
	private String berthingTime;
	@Column(name ="commence_pumping_time")
	private String loadingTime;
	@Column(name ="complete_pumping_time")
	private String completionTime;
	@Column(name="departuretime")
	private String departureTime;
	@Column(name="durationalongsideberth")
	private String durationAlongsideBerth;
//	@Column(name="mfm_file_binary")
//	private String mfmFile;
	
	

}
