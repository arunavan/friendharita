package com.india.bts.dib.service;

import java.util.List;
import java.util.Optional;

import com.india.bts.dib.domain.CargoLoadingData;

public interface CargoLoadingDataService {
	
	public abstract CargoLoadingData create(CargoLoadingData data);
	public abstract CargoLoadingData update(CargoLoadingData data); 
	public abstract CargoLoadingData findByJobId(long id);
	public abstract List<CargoLoadingData> getAll();
	

}
