package com.india.bts.dib.repository;


import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.india.bts.dib.domain.InterfaceDeliveryJob;
import com.india.bts.dib.domain.Job;

public interface InterfaceDeliveryRepository extends JpaRepository<InterfaceDeliveryJob,Long>{
	
	@Modifying
	@Transactional
	@Query(value = "call St_INSERT_Interface_JOB (?1)",nativeQuery=true)
	void jobDataInsertIntoMainTable(Long jobId);

}
