/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _________________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfiguration {
 	@Bean
    public Docket swaggerSpringMvcPlugin() {
		ParameterBuilder paramBuilder = new ParameterBuilder();
        paramBuilder.name("Authorization").modelRef(new ModelRef("string")).parameterType("header").required(false).build();
        List<springfox.documentation.service.Parameter> params = new ArrayList<springfox.documentation.service.Parameter>();
        params.add(paramBuilder.build());
        return new Docket(DocumentationType.SWAGGER_2).groupName("ALL")
            .useDefaultResponseMessages(false)
            .apiInfo(apiInfo())
            .select()
            .apis(RequestHandlerSelectors.basePackage("com.india.bts.dib.controller"))
            .build().globalOperationParameters(params);
    
    }
	
	@Bean
	public Docket signinAPI() {
		ParameterBuilder userNameParamBuilder = new ParameterBuilder();
		userNameParamBuilder.name("email").modelRef(new ModelRef("string")).parameterType("header").required(true).build();
		
		ParameterBuilder pwdNameParamBuilder = new ParameterBuilder();
		pwdNameParamBuilder.name("password").modelRef(new ModelRef("string")).parameterType("header").required(true)
				.build();

		List<springfox.documentation.service.Parameter> params = new ArrayList<springfox.documentation.service.Parameter>();

		params.add(userNameParamBuilder.build());
		params.add(pwdNameParamBuilder.build());

		return new Docket(DocumentationType.SWAGGER_2).groupName("SignIN").apiInfo(signInApiInfo()).select()
				.paths(PathSelectors.ant("/api/v1/sign-in")).build().globalOperationParameters(params);
	}



	@Bean
	public Docket signupAPI() {
		return new Docket(DocumentationType.SWAGGER_2).groupName("SignUP").apiInfo(signUpApiInfo()).select()
				.paths(PathSelectors.ant("/api/v1/sign-up")).build().globalOperationParameters(null);
	}
	
 
	private ApiInfo signUpApiInfo() {
		return new ApiInfoBuilder().title("Digital Bunkering Sign in API")
				.description("Digital Bunkering Sign in API for UI Integration").license("Apache License Version 1.0")
				.licenseUrl("").version("V 1.0").build();
	}
	
	private ApiInfo signInApiInfo() {
		return new ApiInfoBuilder().title("Digital Bunkering Sign-UP API")
				.description("Digital Bunkering Sign-UP API for UI Integration").license("Apache License Version 1.0")
				.licenseUrl("").version("V 1.0").build();
	}

	//TODO: Check the proper version of Apache License for closed source and update the right version and URL of license info.
	private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
            .title("Digital Bunkering API")
            .description("Digital Bunkering APIs")
            .license("Apache License Version 2.0")
            .licenseUrl("")
            .version("2.0")
            .build();
    }
}
