/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _________________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.india.bts.dib.domain.User;
import com.india.bts.dib.repository.ApplicationUserRepository;
import com.india.bts.dib.utils.Constants;



@Service
public class CurrentUserService {

	private static final Logger logger = LoggerFactory.getLogger(CurrentUserService.class);

	@Autowired
	private ApplicationUserRepository applicationUserRepository;

	public User getCurrentUser() throws Exception {
		try {
			
			String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
			User user = applicationUserRepository.findByEmail(email);
			System.out.println("Authenticated user ="+ user);
			return user;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Invalid or expired Authentication Token");
		}
	}

	public String getCurrentUserName() throws Exception {
//		Return method changed user name instead of User, To save the user object in every table. 
//		and if the user data needed in any place code, we can fetch by using of user name.
		try {
			
			String email = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
			User user = applicationUserRepository.findByEmail(email);
			System.out.println("Authenticated user ="+ user);
			return user.getEmail(); 
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Invalid or expired Authentication Token");
		}
	}
	
//	public User getCurrentUserForTestCase() throws Exception {
//		String email = Constants.DEVELOPER_NAME_FOR_TOKEN;
//		logger.info("email: "+email);
//		User user = applicationUserRepository.findByEmail(email);
//		logger.info("Authenticated user ="+ user);
//		try {
//			
//			if(user == null) {
//				throw new Exception("Developer record is not found, create and try again");
//			}
//			return user;
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new Exception("Invalid or expired Authentication Token");
//		}
//	}

	public String getCurrentUserForTestCase() throws Exception {
		String email = Constants.DEVELOPER_NAME_FOR_TOKEN;
		logger.info("email: "+email);
		User user = applicationUserRepository.findByEmail(email);
		logger.info("Authenticated user ="+ user);
		try {
			
			if(user == null) {
				throw new Exception("Developer record is not found, create and try again");
			}
			return user.getEmail();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Invalid or expired Authentication Token");
		}
	}
	
}
