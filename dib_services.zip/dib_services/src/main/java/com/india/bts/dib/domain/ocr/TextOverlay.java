package com.india.bts.dib.domain.ocr;

import java.util.List;

import lombok.Data;
@Data
public class TextOverlay {

public List<Line> Lines = null;
public Boolean HasOverlay;
public String Message;

}