package com.india.bts.dib.controller;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.InterfaceDeliveryJob;
import com.india.bts.dib.domain.Job;
import com.india.bts.dib.repository.InterfaceDeliveryRepository;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class IbmsToEbdnIntegrationController {
	
	@Autowired
	InterfaceDeliveryRepository interfaceDeliveryRepository;
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/push/delivery", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> createSalesOrder(@RequestBody InterfaceDeliveryJob data) {
		try {
			LocalDateTime ldt = LocalDateTime.now();
			data.setCreatedDate(ldt);
			interfaceDeliveryRepository.save(data);
			interfaceDeliveryRepository.jobDataInsertIntoMainTable(data.getId());

		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>("Successfully Pushed data to Source system", HttpStatus.OK);
	}
	
	

}
