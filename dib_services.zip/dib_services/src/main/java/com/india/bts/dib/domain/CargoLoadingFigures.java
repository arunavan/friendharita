package com.india.bts.dib.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

//@Data
//@Entity(name="cargo_loading_figures") 
public class CargoLoadingFigures implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -11300308776453527L;

	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=true,name="loaded_qty",length=500)
    private BigDecimal loadedQty;
	
	@Column(nullable=true,name="kilo_liters",length=500)
    private BigDecimal kiloLiters;
	
	@Column(nullable=true,name="us_barrels",length=500)
    private BigDecimal usBarrels; 
	
	@Column(nullable=true,name="long_tons",length=500)
    private BigDecimal longTons;
	
	@Column(nullable=true,name="mfm_qty",length=500)
    private BigDecimal mfmAQty;
	
	@Column(nullable=true,name="barge_sounding_qty",length=500)
    private BigDecimal bargeSoundingQty;
	
	@Column(nullable=true,name="viscosity",length=500)
    private BigDecimal viscosity;
	
	@Column(nullable=true,name="coq_density",length=500)
    private BigDecimal coqDensity;
	
	@Column(nullable=true,name="water_content",length=500)
    private BigDecimal waterContent;
	
	@Column(nullable=true,name="flash_point",length=500)
    private BigDecimal flashPoint;
	
	@Column(nullable=true,name="sulphur_content ",length=500)
    private BigDecimal sulphurContent;
	
	@Column(nullable=true,name="hydrogen_sulfide ",length=500)
    private BigDecimal hydrogenSulfide;
	
	@Column(nullable=true,name="total_acid_humber ",length=500)
    private BigDecimal totalAcidNumber;
	@Column(nullable=true,name="pour_point ",length=500)
    private BigDecimal pourPoint;
	@Column(nullable=true,name="calculate_cetane_index ",length=500)
    private BigDecimal calculateCetaneIndex;
	
	@Column(nullable=true,name="micro_carbon_residue ",length=500)
    private BigDecimal microCarbonResidue;
	@Column(nullable=true,name="ash ",length=500)
    private BigDecimal ash;
	
	@Column(nullable=true,name="Appearance ",length=500)
    private BigDecimal appearance;
	@Column(nullable=true,name="oxidation_stability ",length=500)
    private BigDecimal oxidationStability;
	@Column(nullable=true,name="lubricity ",length=500)
    private BigDecimal lubricity;
	@Column(nullable=true,name="remarks ",length=500)
    private String remarks;
	
	
//	@ManyToOne
//	@JsonIgnore
//    private CargoLoadingData cargoLoadingData;

}
