package com.india.bts.dib.domain;

import lombok.Data;

@Data
public class EsignTimestamp {
	
	private Long jobId;
	//bunker-requistion
	private String workflowType; 
	
	private String coPreSignDateTime;
	private String coPostSignDateTime;
	private String cePreSignDateTime;
	private String cePostSignDateTime;
	private String surPreSignDateTime;
	private String surPostSignDateTime;
	

}
