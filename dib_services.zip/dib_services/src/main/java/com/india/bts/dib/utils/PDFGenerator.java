package com.india.bts.dib.utils;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;

import org.apache.commons.io.FileUtils;

class PDFGenerator {
  public static void main(String[] args) throws IOException {
    File file = new File("./bdn.pdf");

//    PARTIAL AND INVALID PDF BINARY, FOR TESTING PURPOSE USE A  VALID AND SMALL PDF BINARY CONTENT.
    String str = "JVBERi0xLjMKJbrfrOAKMyAwIG9iago8PC9UeXBlIC";
    System.out.println("Reading binary data, wait...");
//    String b64 = FileUtils.readFileToString(new File("/tmp/bin-data-3.txt"));
    try ( FileOutputStream fos = new FileOutputStream(file); ) {
      byte[] decoder = Base64.getDecoder().decode(str);
      System.out.println("Saving file, wait...");
      fos.write(decoder);
      System.out.println("PDF File Ready!!");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}