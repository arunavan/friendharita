package com.india.bts.dib.domain;

import java.io.Serializable;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.io.Files;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@NoArgsConstructor 
@Entity(name = "files")
public class File implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="jobId")
	private Long jobId;
	
	@Column(name="file_name")
	private String fileName;
	
	@Column(nullable=true,name="extension",unique=false, length=100)
	private String extension;

	@Lob
	@Column(name="content")
	private String content;
	
	
	private String meterTicketContent;
	
	
	@Column(name="size")
	private Long size;

	@Column(name="remarks")
	private String remarks;

	@Column(name="document_type")
	private String documentType;
	
	@Transient
	private Map<String, String> ocrContent;

	public File(Long jobId, String fileName, String doucmentType, String content, Long size, String remarks) {
		this.jobId = jobId;
		this.fileName = fileName;
		this.extension = Files.getFileExtension(fileName);
		this.content = content;
		this.size = size;
		this.remarks = remarks;
		this.documentType = doucmentType;
	}

}
