package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity (name = "bunker_transfer_data") 
public class BunkerTransferData implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20)
	private long jobId;
	@Column(nullable=true, name = "refference_number")
	private String refferenceNumber;
	@Column(nullable=true, name = "date_of_transfer")
	private String dateOfTransfer;
	@Column(nullable=true, name = "location_of_transfer")
	private String locationOfTransfer;
	@Column(nullable=true, name = "supplying_bunker_tanker")
	private String supplyingBunkerTanker;
	@Column(nullable=true, name = "receiving_bunker_tanker")
	private String receivingBunkerTanker;
	@Column(nullable=true, name = "transfer_commenced")
	private String transferCommenced;
	@Column(nullable=true, name = "transfer_completed")
	private String transferCompleted;
	@Column(nullable=true, name = "barge_arrived_location_datetime")
	private String bargearrivedLocationDateTime;
	@Column(nullable=true, name = "barge_left_location_datetime")
	private String bargeleftLocationDateTime;
	@Column(nullable=true, name = "product")
	private String product;
	@Column(nullable=true,name="remarks",columnDefinition = "TEXT")
	private String remarks;
	@Column(nullable=true, name = "supply_mfm_fig")
	private String supplyMfmFig;
	@Column(nullable=true, name = "supply_physical_fig")
	private String supplyPhysicalFig;
	@Column(nullable=true, name = "supply_total_rob")
	private String supplyTotalROB;
	@Column(nullable=true, name = "receive_mfm_fig")
	private String receiveMfmFig;
	@Column(nullable=true, name = "receive_physical_fig")
	private String receivePhysicalFig;
	@Column(nullable=true, name = "receive_total_rob")
	private String receiveTotalROB;
	
	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	
	@Column(nullable=true, name = "co_pre_sign_datetime", length=200)
	private String coPreSignDateTime;

	@Column(nullable=true, name = "sur_pre_sign_datetime", length=200)
	private String surPreSignDateTime;


}
