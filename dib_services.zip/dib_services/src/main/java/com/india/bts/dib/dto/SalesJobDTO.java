package com.india.bts.dib.dto;

import java.io.Serializable;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.india.bts.dib.domain.JOBTYPE;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SalesJobDTO implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3940785763807606365L;

	@ApiModelProperty(notes = "specify the jobtype", required = true, example = "loading, delivery, transfer")
	@Enumerated(EnumType.STRING)
    private JOBTYPE jobType;
	
	private SalesOrderDTO salesOrder;
	
	@ApiModelProperty(notes = "specify the client name", required = true, example = "Bts")
	private String client = "Bts";
	
}
