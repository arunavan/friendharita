package com.india.bts.dib.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class LoginResponseDTO {
	
	private Long ID;
	private String email;
	private String displayName;
	private String token;
	private String refreshToken;
	private long expiresIn;
	private String role;
	private boolean requiredToResetPassword;
	private Long bargeId;
	private String bargeName;
	private String bargeLicNo;
}
