package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name = "transfer_order")
public class TransferOrder implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -849554587240835764L;
	@ApiModelProperty(notes = "The database generated ID", required = false)
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;

	@ApiModelProperty(notes = "From Barge", required = true)
	@Column(nullable = true, name = "from_barge", length = 500)
	private String fromBarge;

	@ApiModelProperty(notes = "To Barge", required = true)
	@Column(nullable = true, name = "to_barge", length = 500)
	private String toBarge;

	@ApiModelProperty(notes = "formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name = "transfer_date_time", columnDefinition = "DATETIME", nullable = false)
	LocalDateTime transferDateTime;

	
//	@JsonManagedReference
//	@OneToMany(mappedBy = "job", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	private List<Nomination> nominations;
//
//	@OneToOne(mappedBy = "transferOrder")
//	@JsonIgnore
//	@MapsId
//	private Job job;


}
