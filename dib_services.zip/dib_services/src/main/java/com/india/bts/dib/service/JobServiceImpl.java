package com.india.bts.dib.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang.ObjectUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.india.bts.dib.domain.BDNData;
import com.india.bts.dib.domain.BDNParty;
import com.india.bts.dib.domain.Barge;
import com.india.bts.dib.domain.BunkerRequisitionData;
import com.india.bts.dib.domain.BunkerSafetyChecklistData;
import com.india.bts.dib.domain.BunkerSafetyChecklistItems;
import com.india.bts.dib.domain.BunkerTransferData;
import com.india.bts.dib.domain.CargoLoadingData;
import com.india.bts.dib.domain.DiscrepancyData;
import com.india.bts.dib.domain.ESignaturesData;
import com.india.bts.dib.domain.GradeItems;
import com.india.bts.dib.domain.JOBTYPE;
import com.india.bts.dib.domain.Job;
import com.india.bts.dib.domain.JobDeliveryAuditlog;
import com.india.bts.dib.domain.Location;
import com.india.bts.dib.domain.MFMReadingData;
import com.india.bts.dib.domain.MFMSealsChecklistData;
import com.india.bts.dib.domain.MFMSealsChecklistItems;
import com.india.bts.dib.domain.MeterTotaliserLog;
import com.india.bts.dib.domain.NOPData;
import com.india.bts.dib.domain.Nomination;
import com.india.bts.dib.domain.OcrResult;
import com.india.bts.dib.domain.Sof;
import com.india.bts.dib.domain.StatusType;
import com.india.bts.dib.domain.TaskType;
import com.india.bts.dib.domain.TimelogChecklistItems;
import com.india.bts.dib.domain.TimelogData;
import com.india.bts.dib.domain.User;
import com.india.bts.dib.repository.BDNDataRepository;
import com.india.bts.dib.repository.BDNPartyRepository;
import com.india.bts.dib.repository.BargeRepository;
import com.india.bts.dib.repository.BunkerRequistionRepository;
import com.india.bts.dib.repository.BunkerSafetyChecklistItemsRepository;
import com.india.bts.dib.repository.BunkerSafetyChecklistRepository;
import com.india.bts.dib.repository.BunkerTransferDataRepository;
import com.india.bts.dib.repository.CargoLoadingDataRepository;
import com.india.bts.dib.repository.DiscrepancyRepository;
import com.india.bts.dib.repository.ESignatureRepository;
import com.india.bts.dib.repository.GradeItemsRepository;
import com.india.bts.dib.repository.JobDeliveryAuditlogRepo;
import com.india.bts.dib.repository.JobRepository;
import com.india.bts.dib.repository.LocationRepository;
import com.india.bts.dib.repository.MFMReadingDataRepository;
import com.india.bts.dib.repository.MFMSealsChecklistItemsRepository;
import com.india.bts.dib.repository.MFMSealsChecklistRepository;
import com.india.bts.dib.repository.MeterTotaliserLogRepository;
import com.india.bts.dib.repository.NOPDataRepository;
import com.india.bts.dib.repository.NominationRepository;
import com.india.bts.dib.repository.OcrResultRepository;
import com.india.bts.dib.repository.SOFDataRepository;
import com.india.bts.dib.repository.SOFQuestionOptionRepository;
import com.india.bts.dib.repository.SOFQuestionRepository;
import com.india.bts.dib.repository.TimelogChecklistItemsRepository;
import com.india.bts.dib.repository.TimelogChecklistRepository;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.utils.EmailContentBuilder;
import com.india.bts.dib.utils.ResponseObject;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class JobServiceImpl implements JobService {

	@Autowired
	CurrentUserService currentUserService;

	@Autowired
	JobRepository jobRepository;

	@Autowired
	BargeRepository bargeRepository;

	@Autowired
	BDNPartyRepository bdnPartyRepository;

	@Autowired
	LocationRepository locationRepository;

	@Autowired
	BunkerRequistionRepository bunkerRequistionRepository;

	@Autowired
	BunkerSafetyChecklistRepository bunkerSafetyChecklistRepository;

	@Autowired
	BunkerSafetyChecklistItemsRepository bunkerSafetyChecklistItemsRepository;

	@Autowired
	GradeItemsRepository gradeItemsRepository;

	@Autowired
	ESignatureRepository eSignDataRepository;

	@Autowired
	MFMSealsChecklistRepository mfmSealsChecklistRepository;
	
	@Autowired
	NOPDataRepository nOPDataRepository;

	@Autowired
	MFMSealsChecklistItemsRepository mfmSealsChecklistItemsRepository;

	@Autowired
	TimelogChecklistRepository timelogChecklistRepository;

	@Autowired
	TimelogChecklistItemsRepository timelogChecklistItemsRepository;

	@Autowired
	NominationRepository nominationRepo;

	@Autowired
	MFMReadingDataRepository mfmReadingRepository;

	@Autowired
	SOFDataRepository sofDataRepository;
	@Autowired
	SOFQuestionRepository sofQuestionRepository;
	@Autowired
	SOFQuestionOptionRepository sofQuestionOptionRepository;

	@Autowired
	BDNDataRepository bdnDataRepository;
	@Autowired
	NOPDataRepository nopDataRepository;
	@Autowired
	DiscrepancyRepository discrepancyRepository;
	@Autowired
	BunkerTransferDataRepository bunkerTransferDataRepository;
	@Autowired
	CargoLoadingDataRepository cargoLoadingDataRepository;
	@Autowired
	MeterTotaliserLogRepository meterTotaliserLogRepository;
	@Autowired
	OcrResultRepository ocrResultRepository;
	@Autowired
	private ApplicationContext applicationContext;
	
	@Autowired
	JobDeliveryAuditlogRepo jobDeliveryAuditlogRepo;

	public Job createJob(Job job) {

		try {

			List<Nomination> nominations = job.getNominations();

			job.setCreatedDate(DateTime.now());
			job.setUpdatedDate(DateTime.now());
			job.setStatus(StatusType.CREATED);

			Utilities.updateAuditInfo(job, null, currentUserService.getCurrentUserName());

			job = jobRepository.save(job);

			for (Nomination nomination : nominations) {
				nomination.setJob(job);
			}
			nominationRepo.saveAll(nominations);
			// insert the record into audit log 
			JobDeliveryAuditlog log = new JobDeliveryAuditlog();
			log.setIsSync(0);
			log.setJobId(job.getId());
			log.setPullDate(LocalDateTime.now());
			jobDeliveryAuditlogRepo.save(log);
			
		} catch (Exception e) {
			log.error("unable to create new job, error:", e);
		}
		return job;
	}

	@Override
	public Job updateJob(Job job) {
		List<Nomination> nominations = null;

		try {
			nominationRepo.deleteByJobId(job.getId());

			job.setUpdatedDate(DateTime.now());
			if (job.getJobType().compareTo(JOBTYPE.loading) == 0 && job.getNominations() != null) {
				nominations = job.getNominations();
			} else if (job.getJobType().compareTo(JOBTYPE.delivery) == 0 && job.getNominations() != null) {
				nominations = job.getNominations();
			} else if (job.getJobType().compareTo(JOBTYPE.transfer_out) == 0 && job.getNominations() != null) {
				nominations = job.getNominations();
			} else if (job.getJobType().compareTo(JOBTYPE.transfer_in) == 0 && job.getNominations() != null) {
				nominations = job.getNominations();

			}

//			DISABLED SETTING CREATED TO CURRENT TIMESTAMP IN CASE OF UPDATING THE JOB.
//			job.setCreatedDate(DateTime.now());
			job.setUpdatedDate(DateTime.now());

			Utilities.updateAuditInfo(job, jobRepository.findById(job.getId()).orElse(null),
					currentUserService.getCurrentUserName());

			job = jobRepository.save(job);
			for (Nomination nomination : nominations) {
				nomination.setJob(job);
			}
			nominationRepo.saveAll(nominations);
		} catch (Exception e) {
			log.error("Unable to update job", e);
		}
		return job;
	}

	@Override
	public Job updateOnlyJob(Job job) {
		try {
			Utilities.updateAuditInfo(job, jobRepository.findById(job.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			job = jobRepository.save(job);
		} catch (Exception e) {
			log.error("Unable to update just job details", e);
		}

		return job;
	}

	@Override
	public List<Job> getAll() {
		return jobRepository.findAll();
	}

	@Override
	public List<Job> getAllByJobType(JOBTYPE jobType) {
		List<Job> jobs = new ArrayList<Job>();

		try {
			User currentUser = currentUserService.getCurrentUser();
			String currentUserRole = currentUser.getRoles().iterator().next().getRole();

			if (currentUserRole.equals("ADMIN")) {

				if (jobType.equals(JOBTYPE.transfer)) {
					jobs = jobRepository.findForTransferJobs();
				} else {
					jobs = jobRepository.findByJobType(jobType);
				}

			} else if(currentUserRole.equals("CARGO OFFICER")){
				if (jobType.equals(JOBTYPE.transfer)) {
					jobs = jobRepository.findForTransferJobsAndBargeId(currentUser.getBargeId());
				} else {
					jobs = jobRepository.findByJobTypeAndBargeId(jobType, currentUser.getBargeId());
				}

			} else if(currentUserRole.equalsIgnoreCase("CHIEF ENGINEER")){
				if (jobType.equals(JOBTYPE.transfer)) {
					jobs = jobRepository.getDataForTransfer(currentUser.getEmail());
				} else {
					jobs = jobRepository.getData(jobType.toString(),currentUser.getEmail());
				}

		    }else if(currentUserRole.equalsIgnoreCase("SURVEYOR")){
				if (jobType.equals(JOBTYPE.transfer)) {
					jobs = jobRepository.getTransferJobsSurveyor(currentUser.getEmail());
				} else {
				    jobs = jobRepository.getSurveyorData(jobType.toString(),currentUser.getEmail());
				}
			}
		} catch (Exception e) {
			log.error("Unable to getjobs from getAllByJobType", e);
		}

		return jobs;
	}

//	@Override
//	public  Optional<Job> getById(long id) {
//		return jobRepository.findById(id);
//	}

	@Override
	public Job getById(long jobId) {
		try {
			Optional<Job> job = jobRepository.findById(jobId);
// 			List<Nomination> nominations = nominationRepo.findByJobId(jobId);
// 			if(job.get().getTransferOrder() != null) {
// 				job.get().getTransferOrder().setNominations(nominations);
// 			}else if(job.get().getSalesOrder() != null) {
// 				job.get().getSalesOrder().setNominations(nominations);
// 			}else if(job.get().getPurchaseOrder() != null) {
// 				job.get().getPurchaseOrder().setNominations(nominations);
// 			}
			if (job.isPresent())
				return job.get();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Job getOrderById(long jobId) {
		Optional<Job> job = jobRepository.findById(jobId);

		return job.get();
	}

	@Override
	public void delete(long jobId) {
		jobRepository.deleteById(jobId);

	}

	@Override
	public BunkerRequisitionData createBunkerRequisition(BunkerRequisitionData bunkerRequisitionData) throws Exception {

		try {
			Utilities.updateAuditInfo(bunkerRequisitionData, null, currentUserService.getCurrentUserName());
			bunkerRequisitionData = bunkerRequistionRepository.save(bunkerRequisitionData);
			jobRepository.updateCEAndCOAndSurveyor(bunkerRequisitionData.getSurveyor(),bunkerRequisitionData.getChiefEngineer(),
					bunkerRequisitionData.getCargoOfficer(), bunkerRequisitionData.getJobId());			

		} catch (Exception e) {
			log.error("Unable to createBunkerRequisition", e);
			throw e;
		}
		return bunkerRequisitionData;
	}

	@Override
	public BunkerRequisitionData updateBunkerRequisition(BunkerRequisitionData bunkerRequisitionData) throws Exception {
		try {
			Utilities.updateAuditInfo(bunkerRequisitionData,
					bunkerRequistionRepository.findById(bunkerRequisitionData.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			bunkerRequisitionData = bunkerRequistionRepository.save(bunkerRequisitionData);
			jobRepository.updateCEAndCOAndSurveyor(bunkerRequisitionData.getSurveyor(),bunkerRequisitionData.getChiefEngineer(),
					bunkerRequisitionData.getCargoOfficer(),bunkerRequisitionData.getJobId());
		} catch (Exception e) {
			log.error("Error while upating bunker requistion data in database", e);
			throw e;
		}
		return bunkerRequisitionData;
	}

	@Override
	public BunkerRequisitionData getBunkerRequisition(long jobId) {
		return bunkerRequistionRepository.findByJobId(jobId);
	}

	@Override
	public BunkerSafetyChecklistData createBunkerSafetyChecklist(BunkerSafetyChecklistData bunkerSafetyChecklistData) {

		try {

			Utilities.updateAuditInfo(bunkerSafetyChecklistData, null, currentUserService.getCurrentUserName());
			bunkerSafetyChecklistData = bunkerSafetyChecklistRepository.save(bunkerSafetyChecklistData);
			jobRepository.updateCEAndCOAndSurveyor(bunkerSafetyChecklistData.getSurveyor(),bunkerSafetyChecklistData.getChiefEngineer(),
					bunkerSafetyChecklistData.getCargoOfficer(),bunkerSafetyChecklistData.getJobId());
		} catch (Exception e) {
			log.error("Unable to createBunkerSafetyChecklist", e);
		}

		Set<BunkerSafetyChecklistItems> checklistItems = bunkerSafetyChecklistData.getChecklistItems();
		for (BunkerSafetyChecklistItems checklistItem : checklistItems) {
			checklistItem.setBunkerSafetyChecklist(bunkerSafetyChecklistData);
			checklistItem = bunkerSafetyChecklistItemsRepository.save(checklistItem);

			Set<GradeItems> grageItems = checklistItem.getGradeItems();

			for (GradeItems gradeItem : grageItems) {
				gradeItem.setBunkerSafetyChecklistItems(checklistItem);
				gradeItemsRepository.save(gradeItem);
			}
		}
		return bunkerSafetyChecklistData;
	}

	@Override
	public BunkerSafetyChecklistData updateBunkerSafetyChecklist(BunkerSafetyChecklistData bunkerSafetyChecklistData) {
		try {
			bunkerSafetyChecklistItemsRepository.deleteByBunkerSafetyChecklistId(bunkerSafetyChecklistData.getId());

			Utilities.updateAuditInfo(bunkerSafetyChecklistData,
					bunkerSafetyChecklistRepository.findById(bunkerSafetyChecklistData.getId()).orElse(null),
					currentUserService.getCurrentUserName());

			bunkerSafetyChecklistData = bunkerSafetyChecklistRepository.save(bunkerSafetyChecklistData);
			jobRepository.updateCEAndCOAndSurveyor(bunkerSafetyChecklistData.getSurveyor(),bunkerSafetyChecklistData.getChiefEngineer(),
					bunkerSafetyChecklistData.getCargoOfficer(),bunkerSafetyChecklistData.getJobId());

			Set<BunkerSafetyChecklistItems> checklistItems = bunkerSafetyChecklistData.getChecklistItems();
			for (BunkerSafetyChecklistItems checklistItem : checklistItems) {
				checklistItem.setBunkerSafetyChecklist(bunkerSafetyChecklistData);
				checklistItem = bunkerSafetyChecklistItemsRepository.save(checklistItem);

				if(checklistItem.getGradeItems() != null && checklistItem.getGradeItems().size() > 0) {
					for (GradeItems gradeItem : checklistItem.getGradeItems()) {
						gradeItem.setBunkerSafetyChecklistItems(checklistItem);
						gradeItem.setJobId(bunkerSafetyChecklistData.getJobId());
						gradeItemsRepository.save(gradeItem);
					}
				}
			}

		} catch (Exception e) {
			log.error("Error while updating bunker safety checklist data to database", e);
		}
		return bunkerSafetyChecklistData;
	}

	@Override
	public BunkerSafetyChecklistData getBunkerSafetyChecklist(long jobId) {
		BunkerSafetyChecklistData bunkerSafetyChecklistData = bunkerSafetyChecklistRepository.findByJobId(jobId);
		if(bunkerSafetyChecklistData != null) {
			for (BunkerSafetyChecklistItems checkItem : bunkerSafetyChecklistData.getChecklistItems()) {
				Set<GradeItems>  gradeItems = gradeItemsRepository.findByBunkerSafetyChecklistItemsId(checkItem.getId());
				if(! org.springframework.util.ObjectUtils.isEmpty(gradeItems)) {
					checkItem.setGradeItems(gradeItems);
				}
			}
		}
		
		
		return bunkerSafetyChecklistData;
	}

	@Override
	public MFMSealsChecklistData createMFMSealsChecklist(MFMSealsChecklistData mFMSealsChecklistData) {
		try {
			Utilities.updateAuditInfo(mFMSealsChecklistData, null, currentUserService.getCurrentUserName());
			mFMSealsChecklistData = mfmSealsChecklistRepository.save(mFMSealsChecklistData);
			jobRepository.updateCEAndCOAndSurveyor(mFMSealsChecklistData.getSurveyorNameAfterOperation(),mFMSealsChecklistData.getChiefEngineerNameAfterOperation(),
					mFMSealsChecklistData.getCargoOfficerNameAfterOperation(),mFMSealsChecklistData.getJobId());

			List<MFMSealsChecklistItems> checklistItems = mFMSealsChecklistData.getChecklistItems();
			for (MFMSealsChecklistItems checklistItem : checklistItems) {
				checklistItem.setMfmSealsChecklist(mFMSealsChecklistData);
			}
			mfmSealsChecklistItemsRepository.saveAll(checklistItems);
		} catch (Exception e) {
			log.error("Unable to createMFMSealsChecklist", e);
		}

		return mFMSealsChecklistData;
	}

	@Override
	public MFMSealsChecklistData updateMFMSealsChecklist(MFMSealsChecklistData mFMSealsChecklistData) {
		try {
			log.info("Deleting mFMSealsChecklistData:" + mFMSealsChecklistData.getId());
			// mfmSealsChecklistItemsRepository.deleteByMfmSealsChecklist(mFMSealsChecklistData);
			mfmSealsChecklistItemsRepository.deleteALLMfmSealsChecklist(mFMSealsChecklistData.getId());

			Utilities.updateAuditInfo(mFMSealsChecklistData,
					mfmSealsChecklistRepository.findById(mFMSealsChecklistData.getId()).orElse(null),
					currentUserService.getCurrentUserName());

			mFMSealsChecklistData = mfmSealsChecklistRepository.save(mFMSealsChecklistData);
			jobRepository.updateCEAndCOAndSurveyor(mFMSealsChecklistData.getSurveyorNameAfterOperation(),mFMSealsChecklistData.getChiefEngineerNameAfterOperation(),
					mFMSealsChecklistData.getCargoOfficerNameAfterOperation(),mFMSealsChecklistData.getJobId());


			List<MFMSealsChecklistItems> checklistItems = mFMSealsChecklistData.getChecklistItems();
			for (MFMSealsChecklistItems checklistItem : checklistItems) {
				checklistItem.setMfmSealsChecklist(mFMSealsChecklistData);
			}
			mfmSealsChecklistItemsRepository.saveAll(checklistItems);

		} catch (Exception e) {
			log.error("Error while updating mfm seals checklist data to database", e);
		}
		return mFMSealsChecklistData;
	}

	@Override
	public MFMSealsChecklistData getMFMSealsChecklist(long jobId) {
		MFMSealsChecklistData mFMSealsChecklistData = mfmSealsChecklistRepository.findByJobId(jobId);

		// Compare by first name and then last name
		Comparator<MFMSealsChecklistItems> compareCategoryAndTag = Comparator
				.comparing(MFMSealsChecklistItems::getSealCategory).thenComparing(MFMSealsChecklistItems::getTagNumber);
		if (mFMSealsChecklistData != null && mFMSealsChecklistData.getChecklistItems() != null) {
			List<MFMSealsChecklistItems> sortedChecklistItems = mFMSealsChecklistData.getChecklistItems().stream()
					.sorted(compareCategoryAndTag).collect(Collectors.toList());

			mFMSealsChecklistData.setChecklistItems(sortedChecklistItems);
		}

		return mFMSealsChecklistData;
	}

	@Override
	public TimelogData createTimeLogData(TimelogData timelogData) {
		try {

			Utilities.updateAuditInfo(timelogData, null, currentUserService.getCurrentUserName());
			timelogData = timelogChecklistRepository.save(timelogData);
			jobRepository.updateCEAndCOAndSurveyor(timelogData.getSurveyor(),timelogData.getTerminalOrVesselRepresentative(),timelogData.getCargoOfficer(),timelogData.getJobId());

			List<TimelogChecklistItems> checklistItems = timelogData.getTimeLogItems();
			for (TimelogChecklistItems checklistItem : checklistItems) {
				checklistItem.setTimelogChecklist(timelogData);
			}
			timelogChecklistItemsRepository.saveAll(checklistItems);
			

		} catch (Exception e) {
			log.error("Unable to createTimeLogData", e);
		}

		return timelogData;
	}

	@Override
	public TimelogData updateTimelogData(TimelogData timelogData) {
		try {
			timelogChecklistItemsRepository.deleteAllByTimelogChecklistId(timelogData.getId());
			Utilities.updateAuditInfo(timelogData,
					timelogChecklistRepository.findById(timelogData.getId()).orElse(null),
					currentUserService.getCurrentUserName());

			timelogData = timelogChecklistRepository.save(timelogData);
			jobRepository.updateCEAndCOAndSurveyor(timelogData.getSurveyor(),timelogData.getTerminalOrVesselRepresentative(),timelogData.getCargoOfficer(),timelogData.getJobId());
			List<TimelogChecklistItems> checklistItems = timelogData.getTimeLogItems();
			for (TimelogChecklistItems checklistItem : checklistItems) {
				checklistItem.setTimelogChecklist(timelogData);
			}
			timelogChecklistItemsRepository.saveAll(checklistItems);
		} catch (Exception e) {
			log.error("Error while updating timelog checklist data to database", e);
		}
		return timelogData;
	}

	@Override
	public TimelogData getTimelogData(long jobId) {
		TimelogData timelogData = timelogChecklistRepository.findByJobId(jobId);
		return timelogData;
	}

	@Override
	public MFMReadingData createMFMReadingData(MFMReadingData mfmReadingData) {
		try {
			Utilities.updateAuditInfo(mfmReadingData, null, currentUserService.getCurrentUserName());
			mfmReadingData = mfmReadingRepository.save(mfmReadingData);
			jobRepository.updateCEAndCOAndSurveyor(mfmReadingData.getSurveyorNameAfterOperation(),mfmReadingData.getChiefEngineerNameAfterOperation(),
					mfmReadingData.getCargoOfficerNameAfterOperation(),mfmReadingData.getJobId());

			

		} catch (Exception e) {
			log.error("Unable to createMFMReadingData", e);
		}

		return mfmReadingData;
	}

	@Override
	public MFMReadingData updateMFMReadingData(MFMReadingData mfmReadingData) {
		MeterTotaliserLog metrLog = null;

		try {
			Utilities.updateAuditInfo(mfmReadingData,
					mfmReadingRepository.findById(mfmReadingData.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			mfmReadingData = mfmReadingRepository.save(mfmReadingData);
			jobRepository.updateCEAndCOAndSurveyor(mfmReadingData.getSurveyorNameAfterOperation(),mfmReadingData.getChiefEngineerNameAfterOperation(),
					mfmReadingData.getCargoOfficerNameAfterOperation(),mfmReadingData.getJobId());


		} catch (Exception e) {
			log.error("Error while updating MFM reading data to database", e);
		}
		return mfmReadingData;
	}

	@Override
	public MFMReadingData getMFMReadingData(long jobId) {
		MFMReadingData mfmReadingData = mfmReadingRepository.findByJobId(jobId);
		return mfmReadingData;
	}

//	SOF DATA
	@Override
	public Sof createSOFData(Sof sofData) {

		try {
			Utilities.updateAuditInfo(sofData, null, currentUserService.getCurrentUserName());
			sofData = sofDataRepository.save(sofData);
			jobRepository.updateCEAndCOAndSurveyor(sofData.getSurveyor(),sofData.getChiefEngineer(),sofData.getCargoOfficer(),sofData.getJobId());
		} catch (Exception e) {
			log.error("Unable to createMFMSealsChecklist", e);
		}

		return sofData;
	}

	@Override
	public Sof updateSOFData(Sof sofData) {
		try {

			Utilities.updateAuditInfo(sofData, sofDataRepository.findById(sofData.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			sofData = sofDataRepository.save(sofData);
			jobRepository.updateCEAndCOAndSurveyor(sofData.getSurveyor(),sofData.getChiefEngineer(),sofData.getCargoOfficer(),sofData.getJobId());

		} catch (Exception e) {
			log.error("Error while updating SOF Data to database", e);
		}
		return sofData;
	}

	@Override
	public Sof getSOFData(long jobId) {
		Sof sofData = sofDataRepository.findByJobId(jobId);
		return sofData;
	}

	// BDN DATA
	@Override
	public BDNData createBDNData(BDNData bdnData) {
		try {
			Utilities.updateAuditInfo(bdnData, null, currentUserService.getCurrentUserName());
			// Temperature is getting from Bunker requisition 
			// This temperature is updated into Bdn table
			// The main purpose of updating temperature in BDN is to increase the performance of getting View(bunker_data_publish_delivery) 
			// no need to join the table BunkerRequisitionData to get temperature
			String temperature =bunkerRequistionRepository.getTemperatureByJobId(bdnData.getJobId());
			bdnData.setTemperature(temperature);
			bdnData = bdnDataRepository.save(bdnData);
			jobRepository.updateCEAndCOAndSurveyor(bdnData.getSurveyor(),bdnData.getChiefEngineer(),bdnData.getCargoOfficer(),bdnData.getJobId());

		} catch (Exception e) {
			log.error("Unable to createBDNData", e);
		}
		return bdnData;
	}

	@Override
	public BDNData updateBDNData(BDNData bdnData) {
		try {

			Utilities.updateAuditInfo(bdnData, bdnDataRepository.findById(bdnData.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			// Temperature is getting from Bunker requisition 
			// This temperature is updated into Bdn table
			// The main purpose of updating temperature in BDN is to increase the performance of getting View(bunker_data_publish_delivery) 
			// no need to join the table BunkerRequisitionData to get temperature
			//bdnData = bdnDataRepository.save(bdnData);
			String temperature =bunkerRequistionRepository.getTemperatureByJobId(bdnData.getJobId());
			bdnData.setTemperature(temperature);
			bdnData = bdnDataRepository.save(bdnData);
			jobRepository.updateCEAndCOAndSurveyor(bdnData.getSurveyor(),bdnData.getChiefEngineer(),bdnData.getCargoOfficer(),bdnData.getJobId());
		} catch (Exception e) {
			log.error("Unable to updateBDNData", e);
		}

		return bdnData;
	}

	@Override
	public BDNData getBDNData(long jobId) {
		BDNData bdnData = bdnDataRepository.findByJobId(jobId);
		return bdnData;
	}

	// NOP DATA
	@Override
	public NOPData createNOPData(NOPData bdnData) {
		try {
			Utilities.updateAuditInfo(bdnData, null, currentUserService.getCurrentUserName());

			bdnData = nopDataRepository.save(bdnData);
			jobRepository.updateCEAndCOAndSurveyor(bdnData.getSurveyor(),bdnData.getChiefEngineer(),bdnData.getCargoOfficer(),bdnData.getJobId());
		} catch (Exception e) {
			log.error("Unable to createNOPData", e);
		}
		return bdnData;
	}

	@Override
	public NOPData updateNOPData(NOPData bdnData) {
		try {
			Utilities.updateAuditInfo(bdnData, nopDataRepository.findById(bdnData.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			bdnData = nopDataRepository.save(bdnData);

		} catch (Exception e) {
			log.error("Unable to updateNOPData", e);
		}
		return bdnData;
	}

	@Override
	public NOPData getNOPData(long jobId) {
		NOPData bdnData = nopDataRepository.findByJobId(jobId);
		return bdnData;
	}

	// DISCREPENCY DATA
	@Override
	public DiscrepancyData createDiscrepancyData(DiscrepancyData bdnData) {
		try {
			Utilities.updateAuditInfo(bdnData, null, currentUserService.getCurrentUserName());

			bdnData = discrepancyRepository.save(bdnData);
		} catch (Exception e) {
			log.error("Unable to createNOPData", e);
		}
		return bdnData;
	}

	@Override
	public DiscrepancyData updateDiscrepancyData(DiscrepancyData bdnData) {
		try {
			Utilities.updateAuditInfo(bdnData, discrepancyRepository.findById(bdnData.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			bdnData = discrepancyRepository.save(bdnData);

		} catch (Exception e) {
			log.error("Unable to updateNOPData", e);
		}
		return bdnData;
	}

	@Override
	public DiscrepancyData getDiscrepancyData(long jobId) {
		DiscrepancyData bdnData = discrepancyRepository.findByJobId(jobId);
		return bdnData;
	}

//	ESign DATA
	@Override
	public ESignaturesData createESignData(ESignaturesData eSignData) {
		try {
			Utilities.updateAuditInfo(eSignData, null, currentUserService.getCurrentUserName());
			eSignData = eSignDataRepository.save(eSignData);

		} catch (Exception e) {
			log.error("Unable to createESignData", e);
		}

		return eSignData;
	}

	@Override
	public ESignaturesData updateESignData(ESignaturesData eSignData) {
		try {
			Utilities.updateAuditInfo(eSignData, eSignDataRepository.findById(eSignData.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			eSignData = eSignDataRepository.save(eSignData);

		} catch (Exception e) {
			log.error("Error while updating ESign Data to database", e);
		}
		return eSignData;
	}

	@Override
	public ESignaturesData getESignData(long jobId) {
		ESignaturesData eSignData = eSignDataRepository.findByJobId(jobId);
		return eSignData;
	}

	@Override
	public Job updateJobStatus(String status, Long jobId) {
		MeterTotaliserLog metrLog = null;
		Optional<Job> job = null;
		try {
			job = jobRepository.findById(jobId);
			Utilities.updateAuditInfo(job, jobRepository.findById(job.get().getId()).orElse(null),
					currentUserService.getCurrentUserName());

			jobRepository.updateStatus(status, job.get().getUpdatedDate(), job.get().getUpdatedUser(), jobId);

			MFMReadingData mfmData = mfmReadingRepository.findByJobId(jobId);
			BDNData bdnData = bdnDataRepository.findByJobId(jobId);
			if (status.equalsIgnoreCase("COMPLETED")) {
				metrLog = meterTotaliserLogRepository.findByJobId(jobId);

				if (metrLog == null) {
					metrLog = new MeterTotaliserLog();
				}

				if (mfmData != null && job != null) {
					log.debug("***** seems are required data is available ");
					metrLog.setJobId(mfmData.getJobId());
					metrLog.setJobType(job.get().getJobType());
					metrLog.setCargoOfficerName(
							job.get().getCargoOfficer() != null ? job.get().getCargoOfficer() : "Admin");
					metrLog.setTerminal(job.get().getLocation() != null ? job.get().getLocation() : "N/A");
					metrLog.setBmtNo(mfmData.getBmtNumber() != null ? mfmData.getBmtNumber() : "N/A");
					metrLog.setBargeId(job.get().getBargeId());
					metrLog.setBdnNo(mfmData.getBdnNumber() != null ? mfmData.getBdnNumber() : "N/A");

					metrLog.setDeliveryStartReading(mfmData.getDeliveryTotaliserReadingA());
					metrLog.setDeliveryEndReading(mfmData.getDeliveryTotaliserReadingB());
					metrLog.setLoadingStartReading(mfmData.getLoadingTotaliserReadingX());
					metrLog.setLoadingEndReading(mfmData.getLoadingTotaliserReadingY());
					metrLog.setMeterQty(mfmData.getQuantitySupplied());
					if (bdnData != null) {
						metrLog.setLogDateTime(bdnData.getDate() != null ? bdnData.getDate() : LocalDate.now());
					} else {
						metrLog.setLogDateTime(LocalDate.now());
					}

					String productInfo = getProduct(job);
					metrLog.setProduct(productInfo != null ? productInfo : "N/A");
					meterTotaliserLogRepository.save(metrLog);
				} else {
					log.warn("***** seems are required data to complete the job is misssing ");
				}

			}

		} catch (Exception e) {
			log.error("Error while updating job details:" + e.getMessage(), e);

		}

		return job.get();

	}

	private String getProduct(Optional<Job> job) {
		StringBuilder product = new StringBuilder();

		if (job.get() != null) {
			job.get().getNominations().forEach(nomination -> {
				if (product.length() > 0) {
					product.append(", " + nomination.getGrade() + "/" + nomination.getQuantity());
				} else {
					product.append(nomination.getGrade() + "/" + nomination.getQuantity());
				}
			});
		}
		return product.toString();
	}

	@Override
	public BunkerTransferData createBunkerTransferData(BunkerTransferData bdnData) {
		try {
			Utilities.updateAuditInfo(bdnData, null, currentUserService.getCurrentUserName());
			bdnData = bunkerTransferDataRepository.save(bdnData);
		} catch (Exception e) {
			log.error("Unable to createBunkerTransferData", e);
		}
		return bdnData;
	}

	@Override
	public BunkerTransferData updateBunkerTransferData(BunkerTransferData bdnData) {
		try {

			Utilities.updateAuditInfo(bdnData, bunkerTransferDataRepository.findById(bdnData.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			bdnData = bunkerTransferDataRepository.save(bdnData);
		} catch (Exception e) {
			log.error("Unable to updateBunkerTransferData", e);
		}
		return bdnData;
	}

	@Override
	public BunkerTransferData getBunkerTransferData(long jobId) {
		BunkerTransferData bdnData = bunkerTransferDataRepository.findByJobId(jobId);
		return bdnData;
	}

	@Override
	public CargoLoadingData createCargoLoadingData(CargoLoadingData bdnData) {
		try {
			Utilities.updateAuditInfo(bdnData, null, currentUserService.getCurrentUserName());
			bdnData = cargoLoadingDataRepository.save(bdnData);
		} catch (Exception e) {
			log.error("Unable to createCargoLoadingData", e);
		}
		return bdnData;
	}

	@Override
	public CargoLoadingData updateCargoLoadingData(CargoLoadingData bdnData) {

		try {

			Utilities.updateAuditInfo(bdnData, cargoLoadingDataRepository.findById(bdnData.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			bdnData = cargoLoadingDataRepository.save(bdnData);
		} catch (Exception e) {
			log.error("Unable to updateCargoLoadingData", e);
		}
		return bdnData;
	}

	@Override
	public CargoLoadingData getCargoLoadingData(long jobId) {
		CargoLoadingData bdnData = cargoLoadingDataRepository.findByJobId(jobId);
		return bdnData;
	}

	@Override
	public OcrResult createOcrResult(OcrResult ocrResult) {
		OcrResult result = null;
		try {
			Utilities.updateAuditInfo(ocrResult, null, currentUserService.getCurrentUserName());
			
			ocrResult.setStartTime((ocrResult.getStartTime().length()>16) ? ocrResult.getStartTime() : ocrResult.getStartTime()+":00");
			//ocrResult.setStartTime(ocrResult.getStartTime().substring(0, ocrResult.getStartTime().length()-2)+"00");
			ocrResult.setEndTime((ocrResult.getEndTime().length()>16) ? ocrResult.getEndTime() : ocrResult.getEndTime()+":00");
			//ocrResult.setEndTime(ocrResult.getEndTime().substring(0, ocrResult.getEndTime().length()-2)+"00");
			result = ocrResultRepository.save(ocrResult);
			MFMReadingData mfmReadingData = mfmReadingRepository.findByJobId(ocrResult.getJobId());
			if(mfmReadingData != null) {
				mfmReadingRepository.updatePumpingStartEndTimesWithoutDelivered(ocrResult.getStartTime(),ocrResult.getEndTime(),ocrResult.getBtn(),
						ocrResult.getTotalizerDeliveryOperationStart(),ocrResult.getTotalizerDeliveryOperationEnd(),
						ocrResult.getTotalizerLoadingOperationStart(),ocrResult.getTotalizerLoadingOperationEnd(),ocrResult.getJobId());
			}

		} catch (Exception e) {
			log.error("Unable to createMFMSealsChecklist", e);
		}

		return result;
	}

	@Override
	public OcrResult updateOcrResult(OcrResult ocrResult) throws Exception {
		OcrResult result = null;
		try {
			Utilities.updateAuditInfo(ocrResult, ocrResultRepository.findById(ocrResult.getId()).orElse(null),
					currentUserService.getCurrentUserName());
			
			ocrResult.setStartTime((ocrResult.getStartTime().length()>16) ? ocrResult.getStartTime() : ocrResult.getStartTime()+":00");
			//ocrResult.setStartTime(ocrResult.getStartTime().substring(0, ocrResult.getStartTime().length()-2)+"00");
			ocrResult.setEndTime((ocrResult.getEndTime().length()>16) ? ocrResult.getEndTime() : ocrResult.getEndTime()+":00");
			//ocrResult.setEndTime(ocrResult.getEndTime().substring(0, ocrResult.getEndTime().length()-2)+"00");
			result = ocrResultRepository.save(ocrResult);
			MFMReadingData mfmReadingData = mfmReadingRepository.findByJobId(ocrResult.getJobId());
			BDNData bdnData = bdnDataRepository.findByJobId(ocrResult.getJobId());
			NOPData nOPData=nOPDataRepository.findByJobId(ocrResult.getJobId());
//			Float deliveryQty=(Float.parseFloat(ocrResult.getTotalizerDeliveryOperationEnd())-Float.parseFloat(ocrResult.getTotalizerDeliveryOperationStart()))-
//					(Float.parseFloat(ocrResult.getTotalizerLoadingOperationEnd())-Float.parseFloat(ocrResult.getTotalizerLoadingOperationStart()));		
//			System.out.println(Float.toString(deliveryQty));
			if(mfmReadingData != null) {
				mfmReadingRepository.updatePumpingStartEndTimes(ocrResult.getStartTime(),ocrResult.getEndTime(),ocrResult.getBtn(),
						ocrResult.getTotalizerDeliveryOperationStart(),ocrResult.getTotalizerDeliveryOperationEnd(),
						ocrResult.getTotalizerLoadingOperationStart(),ocrResult.getTotalizerLoadingOperationEnd(),ocrResult.getDelivered(),ocrResult.getJobId());
			}
			if(bdnData != null) {
				bdnDataRepository.updatePumpingStartEndTimes(ocrResult.getStartTime(),ocrResult.getEndTime(),ocrResult.getDelivered(),ocrResult.getBtn(),ocrResult.getJobId());
			}
			if(nOPData!=null) {
				nOPDataRepository.updatePumpingStartEndTimes(ocrResult.getStartTime(),ocrResult.getEndTime(),ocrResult.getDelivered(),ocrResult.getJobId());
			}
			
		} catch (Exception e) {
			throw e;
		}

		return result;
	}

	@Override
	public OcrResult getOcrResult(long id) {
		OcrResult result = ocrResultRepository.findByJobId(id);
		return result;
	}

	@Override
	public Job findByStemNo(String stemNo) {
		return jobRepository.findByStemNo(stemNo);
	}

	public Job findByStemNoAndbargeNameAndproductName(String stemNo,String bargeName,String productName) {
		return jobRepository.findByStemNoAndBargeNameAndproductName(stemNo,bargeName,productName);
	}
	@Override
	public Job findByPurchaseOrderNo(String purchaseOrderNo) {
		return jobRepository.findByPurchaseOrderNo(purchaseOrderNo);
	}
	
	public Job findByPurchaseOrderNoAndBargeNameAndproductName(String purchaseOrderNo,String bargeName,String productName ) {
		return jobRepository.findByPurchaseOrderNoAndBargeNameAndproductName(purchaseOrderNo,bargeName,productName);
	}

	@Override
	public Job findByTransferOrderNo(String transferOrderNo) {
		return jobRepository.findByTransferOrderNo(transferOrderNo);
	}

	@Override
	public Job findByTransferOrderNoAndJobType(String transferOrderNo, JOBTYPE jobType) {
		return jobRepository.findByTransferOrderNoAndJobType(transferOrderNo, jobType);
	}

	@Override
	public Job findAndUpdateBargeData(Job job) throws RuntimeException {
		if (!job.getClient().equals("ui") && job.getBargeId() == null) {
			Barge barge = bargeRepository.findByName(job.getBargeName());
			if (barge == null) {
				throw new RuntimeException("Barge: \'" + job.getBargeName() + "\' does not match with our records!!");
			} else {
				job.setBargeId(barge.getId());
				job.setBargeName(barge.getName());
				job.setBargeLicenceNo(barge.getSbNumber());
				job.setBargePumpingRate(barge.getPumpingRate());
			}
		}
		return job;
	}

	@Override
	public Job findAndUpdateBdnParty(Job job) throws RuntimeException {
		if (!job.getClient().equals("ui") && job.getBdnPartyId() == null) {
			BDNParty party = bdnPartyRepository.findByCompanyName(job.getBdnPartyName());
			if (party == null) {
				throw new RuntimeException(
						"Bdnparty: \'" + job.getBdnPartyName() + "\' does not match with our records!!");
			} else {
				job.setBdnPartyId(party.getId());
				job.setBdnPartyName(party.getCompanyName());
			}
		}
		return job;
	}

	public Job findAndUpdateLocation(Job job) {
		if (!job.getClient().equals("ui") && job.getLocation() != null) {
			Location location = locationRepository.findByName(job.getLocation());
			if (location == null) {
				log.warn("Location: \'" + job.getLocation() + "\' does not match with our records!!");
			} else {
				job.setLocation(location.getDisplayName());
			}
		}
		return job;
	}

	public void createThreadToSendEmail(Job job, TaskType taskType) {
		EmailContentBuilder emailContentBuilder = new EmailContentBuilder(job, taskType);
		Thread emailNotifcationThread = new Thread(emailContentBuilder);
		applicationContext.getAutowireCapableBeanFactory().autowireBean(emailContentBuilder);
		emailNotifcationThread.start();
	}
 
	public void updatemode(long jobId, int mode, String remarks) {
		// TODO Auto-generated method stub
		try {
			User currentUser = currentUserService.getCurrentUser();
			String currentUserRole = currentUser.getRoles().iterator().next().getRole();
			if(currentUserRole.equals("CARGO OFFICER")){
				jobRepository.updatemode(jobId,mode,remarks);
			}
		} catch (Exception e) {
			log.error("Unable to update mode", e);
		}
			
		}
		
		
	

}
