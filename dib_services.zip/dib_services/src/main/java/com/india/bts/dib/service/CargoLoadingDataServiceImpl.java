package com.india.bts.dib.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.india.bts.dib.domain.CargoLoadingData;
import com.india.bts.dib.repository.CargoLoadingDataRepository;

@Service
public class CargoLoadingDataServiceImpl implements CargoLoadingDataService {
	
	
	@Autowired
	CargoLoadingDataRepository cargoDataRepo;
	

	@Override
	public CargoLoadingData create(CargoLoadingData data) {
		data = cargoDataRepo.save(data);
		return data;
	}

	@Override
	public CargoLoadingData update(CargoLoadingData data) {	
		data = cargoDataRepo.save(data);
		return data;
	}

	@Override
	public CargoLoadingData findByJobId(long id) {
		CargoLoadingData data = cargoDataRepo.findByJobId(id);
		return data;
	}

	@Override
	public List<CargoLoadingData> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
