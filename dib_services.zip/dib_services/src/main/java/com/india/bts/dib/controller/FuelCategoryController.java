package com.india.bts.dib.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.FuelCategory;
import com.india.bts.dib.domain.Grade;
import com.india.bts.dib.repository.FuelCategoryRepository;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;
@RestController
@Slf4j
public class FuelCategoryController {
	@Autowired
	FuelCategoryRepository fuelCategoryRepository;
	@RequestMapping(value = Utilities.APP_VERSION + "/fuelcategory/all", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAll() {
		List<FuelCategory> pages = null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN", "CARGO OFFICER" })) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);	
			pages = fuelCategoryRepository.findAll();
//		}	
		} catch (Exception e) {
			log.error("Unable to get all fuelinfo, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(pages, HttpStatus.OK);
	}

}
