package com.india.bts.dib.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

@Service
public class MailContentBuilder {
 
    private TemplateEngine templateEngine;
 
    @Autowired
    public MailContentBuilder(TemplateEngine templateEngine) {
        this.templateEngine = templateEngine;        
    }
 
    public String build(String templateName, Map<String,String> tokens) {
        Context context = new Context();
         for(String key : tokens.keySet())
        {
        	context.setVariable(key, tokens.get(key));
        }
         return templateEngine.process(templateName, context);
    }
 
}