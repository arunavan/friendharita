package com.india.bts.dib.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.india.bts.dib.domain.BunkerDeliveryNoteToIbms;


public interface BunkerDeliveryNoteToIBMSRepository extends JpaRepository<BunkerDeliveryNoteToIbms, Long>{
	
	@Query(value =" select * from mpa_published_delivery_jobs where stem_no =:stem_no",nativeQuery=true)
	List<BunkerDeliveryNoteToIbms> findByStemNo(@Param("stem_no") String stem_no);

}
