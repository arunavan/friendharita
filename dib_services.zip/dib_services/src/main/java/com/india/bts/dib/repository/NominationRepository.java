package com.india.bts.dib.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import com.india.bts.dib.domain.Nomination;

public interface NominationRepository extends JpaRepository<Nomination, Long> {
	
	
	@Transactional
	@Modifying
	void deleteByJobId(Long id);
	
	List<Nomination> findByJobId(Long id);


}
