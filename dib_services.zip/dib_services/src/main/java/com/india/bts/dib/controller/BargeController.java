package com.india.bts.dib.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.Comparator;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.Barge;
import com.india.bts.dib.domain.BargeMfmSealChecklist;
import com.india.bts.dib.domain.MFMSealChecklist;
import com.india.bts.dib.dto.BargeMfmSealChecklistDTO;
import com.india.bts.dib.repository.BargeMfmSealChecklistRepository;
import com.india.bts.dib.repository.BargeRepository;
import com.india.bts.dib.repository.MFMSealChecklistRepository;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.utils.ResponseObject;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class BargeController {

	@Autowired
	BargeRepository bargeRepo;
	@Autowired
	BargeMfmSealChecklistRepository checklistRepo;
	@Autowired
	CurrentUserService currentUserService;

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/barge", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> add(@RequestBody Barge barge) {
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			if (barge.isItDefault()) {
				bargeRepo.setAllUnDefault();
			}
			barge = bargeRepo.save(barge);

		} catch (Exception e) {
			log.error("Unable to add barge", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(barge, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/barge", method = RequestMethod.PATCH, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> modify(@RequestBody Barge barge) {
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			if (barge.isItDefault()) {
				bargeRepo.setAllUnDefault();
			}
			barge = bargeRepo.save(barge);
		} catch (Exception e) {
			log.error("Unable to add barge", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(barge, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/barge", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> update(@RequestBody Barge barge) {
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			if (barge.isItDefault()) {
				bargeRepo.setAllUnDefault();
			}
			barge = bargeRepo.save(barge);
		} catch (Exception e) {
			log.error("Unable to add barge", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(barge, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/barge/{id}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> get(@PathVariable("id") long id) {
		Optional<Barge> barge = null;
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			barge = bargeRepo.findById(id);
		} catch (Exception e) {
			log.error("Unable to get barge", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(barge.get(), HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/barge/all", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAll() {
		List<Barge> pages = null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN", "CARGO OFFICER" })) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);	
//			}
			pages = bargeRepo.findAll();
		} catch (Exception e) {
			log.error("Unable to get all barge, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(pages, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/barge/{id}", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Object> delete(@PathVariable("id") long id) {
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			bargeRepo.deleteById(id);
		} catch (Exception e) {
			log.error("Unable to delete barge, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>("Deleted grade with id:" + id, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/barge-seals", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> addSeals(@RequestBody BargeMfmSealChecklistDTO dto) {
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN", "CARGO OFFICER"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}

			if (dto != null && dto.getSealsChecklist().size() > 0) {
				log.info("records to delete bargeid: " + dto.getBargeId());
				long bargeId = dto.getSealsChecklist().get(0).getBargeId();
				LocalDate verificationDate = dto.getSealsChecklist().get(0).getVerificationReportDate();
				checklistRepo.deleteByBargeIdAndVerificationReportDate(
						dto.getBargeId() == null ? bargeId : dto.getBargeId(), verificationDate);
				checklistRepo.saveAll(dto.getSealsChecklist());
			}

		} catch (Exception e) {
			log.error("Unable to add barge", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(dto.getSealsChecklist(), HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/barge-seals/{bargeId}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getByBargeID(@PathVariable("bargeId") long bargeId) {
		List<BargeMfmSealChecklist> sortedSealsList = new ArrayList<BargeMfmSealChecklist>();
		try {
			List<BargeMfmSealChecklist> sealsChecklist = checklistRepo
					.findByBargeIdOrderByVerificationReportDateDesc(bargeId);
			if (sealsChecklist != null && sealsChecklist.size() > 0) {
				List<BargeMfmSealChecklist> resultAfterDateFilter = new ArrayList<BargeMfmSealChecklist>();

				LocalDate filterDate = sealsChecklist.get(0).getVerificationReportDate();
				for (BargeMfmSealChecklist seal : sealsChecklist) {
					if (seal.getVerificationReportDate() != null
							&& seal.getVerificationReportDate().equals(filterDate)) {
						resultAfterDateFilter.add(seal);
					}
				}

				// Compare by first name and then last name
				Comparator<BargeMfmSealChecklist> compareCategoryAndTag = Comparator
						.comparing(BargeMfmSealChecklist::getSealCategory)
						.thenComparing(BargeMfmSealChecklist::getTagNumber);

				sortedSealsList = resultAfterDateFilter.stream().sorted(compareCategoryAndTag)
						.collect(Collectors.toList());

			}

		} catch (Exception e) {
			log.error("Unable to get barge", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(sortedSealsList, HttpStatus.OK);
	}
	
	@RequestMapping(value = Utilities.APP_VERSION + "/barge-seals/AllBargeInfo", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAllBarge() {
		List<BargeMfmSealChecklist> sealsChecklist=null;
		try {
			 sealsChecklist = checklistRepo.findAll();
					} catch (Exception e) {
			log.error("Unable to get barge", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(sealsChecklist, HttpStatus.OK);
	}


	@RequestMapping(value = Utilities.APP_VERSION + "/barge-seals/date/{date}/{bargeId}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getByBargeID(@PathVariable("date") LocalDate date,
			@PathVariable("bargeId") Long bargeId) {
		List<BargeMfmSealChecklist> sealsChecklist = null;
		try {
			
			sealsChecklist = checklistRepo.findByVerificationReportDateAndBargeId(date, bargeId);
		} catch (Exception e) {
			log.error("Unable to get barge", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(sealsChecklist, HttpStatus.OK);
	}

}
