package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.india.bts.dib.domain.BunkerDeliveryReportEntity;

public interface BunkerDeliveryReportEntityRepository extends JpaRepository<BunkerDeliveryReportEntity,Long>{
	
	
	@Query(value="select * from bunker_data_publish_delivery where id =:id",nativeQuery=true)
	BunkerDeliveryReportEntity findByJobId(@Param("id") Long id);
	

}
