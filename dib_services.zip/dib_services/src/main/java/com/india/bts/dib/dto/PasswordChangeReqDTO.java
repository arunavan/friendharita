package com.india.bts.dib.dto;

import lombok.Data;

@Data
public class PasswordChangeReqDTO {
	
	private String email;
	private String password;
	private boolean status;
	

}
