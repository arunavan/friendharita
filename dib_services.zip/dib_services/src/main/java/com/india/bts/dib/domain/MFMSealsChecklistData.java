package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="mfm_seals_checklist_data") 
public class MFMSealsChecklistData implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6360097131484204213L;
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20)
	private long jobId;
	@Column(nullable=false, name = "bunker_sb_number", length=200)
	private String bargeLicenceNo;
	@Column(nullable=false, name = "location_name", length=200)
	private String location;
	@Column(nullable=false, name = "bunker_tanker_name", length=200)
	private String barge;
	@Column(nullable=false, name = "seal_verfication_report_number", length=200)
	private String sealVerificationNumber;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd", required = false, example = "2022-05-25")
    @JsonFormat(pattern="yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd") 
    @Column(name = "mfm_seals_checklist_date", columnDefinition="DATE", nullable = true)
    LocalDate mfmSealsChecklistDate;
	
	@OneToMany(mappedBy="mfmSealsChecklist",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private List<MFMSealsChecklistItems> checklistItems;
	
	@Column(nullable=true, name = "co_pre_sign_datetime", length=200)
	private String coPreSignDateTime;
	@Column(nullable=true, name = "co_post_sign_datetime", length=200)
	private String coPostSignDateTime;
	@Column(nullable=true, name = "ce_pre_sign_datetime", length=200)
	private String cePreSignDateTime;
	@Column(nullable=true, name = "ce_post_sign_datetime", length=200)
	private String cePostSignDateTime;
	@Column(nullable=true, name = "sur_pre_sign_datetime", length=200)
	private String surPreSignDateTime;
	@Column(nullable=true, name = "sur_post_sign_datetime", length=200)
	private String surPostSignDateTime;


	@CreatedDate
	@Column(nullable = true,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = true ,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	
	@Column(nullable=true, name = "cargoofficernamebeforeoperation", length=250)
	private String cargoOfficerNameBeforeOperation;
	@Column(nullable=true, name = "chiefengineernamebeforeoperation", length=250)
	private String chiefEngineerNameBeforeOperation;
	@Column(nullable=true, name = "surveyornamebeforeoperation", length=250)
	private String surveyorNameBeforeOperation;
	
	@Column(nullable=true, name = "cargoofficernameafteroperation", length=250)
	private String cargoOfficerNameAfterOperation;
	@Column(nullable=true, name = "chiefengineernameafteroperation", length=250)
	private String chiefEngineerNameAfterOperation;
	@Column(nullable=true, name = "surveyornameafteroperation", length=250)
	private String surveyorNameAfterOperation;
	@Lob
	@Column(nullable=true,name="seal_file_binary")
	private String sealFileBinary;
	@Lob
	@Column(nullable=true,name="Pre_CO_Sign")
	private String preCOSign;
	@Lob
	@Column(nullable=true,name="Pre_CE_Sign")
	private String preCESign;
	@Lob
	@Column(nullable=true,name="Pre_SV_Sign")
	private String preSVSign;
	@Lob
	@Column(nullable=true,name="Post_SV_Sign")
	private String postSVSign;
	@Lob
	@Column(nullable=true,name="Post_CO_Sign")
	private String postCOSign;
	@Lob
	@Column(nullable=true,name="Post_CE_Sign")
	private String postCESign;
}
