package com.india.bts.dib.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.BunkerDeliveryNoteToIbms;
import com.india.bts.dib.domain.BunkerLoadingToIbms;
import com.india.bts.dib.domain.File;
import com.india.bts.dib.domain.FilesData;
import com.india.bts.dib.domain.JobDeliveryAuditlog;
import com.india.bts.dib.domain.MFMReadingData;
import com.india.bts.dib.domain.Reports;
import com.india.bts.dib.dto.BunkerDeliveryNoteToIbmsWithAttachments;
import com.india.bts.dib.dto.BunkerLoadingToIbmsWithAttachments;
import com.india.bts.dib.repository.BunkerDeliveryNoteToIBMSRepository;
import com.india.bts.dib.repository.BunkerLoadingToIbmsRepository;
import com.india.bts.dib.repository.DBFileRepository;
import com.india.bts.dib.repository.JobDeliveryAuditlogRepo;
import com.india.bts.dib.repository.ReportsRepository;
import com.india.bts.dib.service.JobServiceImpl;
import com.india.bts.dib.utils.Utilities;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class EbdnToIbmsIntegrationController {
	
	@Autowired
	BunkerDeliveryNoteToIBMSRepository bunkerDeliveryNoteToIBMSRepository;
	@Autowired
	DBFileRepository dbFileRepository;
	@Autowired
	BunkerLoadingToIbmsRepository bunkerLoadingToIbmsRepository;
	
	@Autowired
	ReportsRepository reportsRepository;
	
	@Autowired
	JobDeliveryAuditlogRepo jobDeliveryAuditlogRepo;
	
//	@Autowired
//	JobServiceImpl jobService;
	
	@RequestMapping(value = Utilities.APP_VERSION + "/data/pull/bunker_delivery_notes", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAllDeliveryJobs() {
		List<BunkerDeliveryNoteToIbms> list = null;
		List<BunkerDeliveryNoteToIbmsWithAttachments> deliveryList = new ArrayList<>();
		//String[] documents = {"bdnFile","mfmFile","meterTicket"};
		try {
			list = bunkerDeliveryNoteToIBMSRepository.findAll();
			for(BunkerDeliveryNoteToIbms obj :list) {
				BunkerDeliveryNoteToIbmsWithAttachments data = new BunkerDeliveryNoteToIbmsWithAttachments();
				File MFMTicket = new File();
				HashMap<String,Object> map=new HashMap<String,Object>();
				List<Reports> reportsList =new ArrayList<>();
				List<FilesData> filesList =new ArrayList<>();
				MFMTicket = dbFileRepository.getLatestMeterTicket(obj.getId());
				reportsList =reportsRepository.findByJobId(obj.getId());
				//MFMReadingData mfmData = jobService.getMFMReadingData(obj.getId());
				BeanUtils.copyProperties(data, obj);
				
				
//				for(String doc :documents) {
//					FilesData attachments = new FilesData();
//					if(doc.equals("bdnFile")) {
//						attachments.setFileName(doc);
//						attachments.setFileContent(obj.getBdnFile());
//					}else if(doc.equals("mfmFile")) {
//						attachments.setFileName(doc);
//						attachments.setFileContent(obj.getMfmFile());
//					}else if(doc.equals("meterTicket")) {
//						attachments.setFileName(doc);
//						attachments.setFileContent(MFMTicket.getContent());
//					}
//					attachmentsList.add(attachments);
//				}
			
//			    map.put("bdnFile", obj.getBdnFile());
//			    map.put("mfmFile", obj.getMfmFile());
//			    map.put("meterTicket", MFMTicket.getContent());
				
			// reports list take from reports_job table 	
				for(Reports repolist :reportsList) {
					FilesData report = new FilesData();
					report.setFileName(repolist.getReportName());
					report.setFileContent(repolist.getReportFileBinary());
					filesList.add(report);
					
				}
			// meter ticket from attachments table
				if(MFMTicket != null) {
					FilesData meterTicket = new FilesData();
					meterTicket.setFileName("meterTicket");
					meterTicket.setFileContent(MFMTicket.getContent());
					filesList.add(meterTicket);
				}
			    data.setAttachments(filesList);
			    deliveryList.add(data);
			    }
			for(BunkerDeliveryNoteToIbmsWithAttachments pojo :deliveryList) {
				jobDeliveryAuditlogRepo.updateAuditLog(pojo.getId(),LocalDateTime.now(),1);
			}

			} catch (Exception e) {
			log.error("Unable to get all published bunker delivery notes, ", e);
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(deliveryList, HttpStatus.OK);
	}
	@RequestMapping(value = Utilities.APP_VERSION + "/data/pull/bunker_delivery_notes/{job_no}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAllDeliveryJobsByStemNo(@PathVariable("job_no") String job_no) {
		List<BunkerDeliveryNoteToIbms> list = null;
		List<BunkerDeliveryNoteToIbmsWithAttachments> deliveryList = new ArrayList<>();
		//String[] documents = {"bdnFile","mfmFile","meterTicket"};
		try {
			list = bunkerDeliveryNoteToIBMSRepository.findByStemNo(job_no);
			for(BunkerDeliveryNoteToIbms obj :list) {
				BunkerDeliveryNoteToIbmsWithAttachments data = new BunkerDeliveryNoteToIbmsWithAttachments();
				File MFMTicket = new File();
				HashMap<String,Object> map=new HashMap<String,Object>();
				List<Reports> reportsList =new ArrayList<>();
				List<FilesData> filesList =new ArrayList<>();
				MFMTicket = dbFileRepository.getLatestMeterTicket(obj.getId());
				reportsList =reportsRepository.findByJobId(obj.getId());
				//MFMReadingData mfmData = jobService.getMFMReadingData(obj.getId());
				BeanUtils.copyProperties(data, obj);
				
				
//				for(String doc :documents) {
//					FilesData attachments = new FilesData();
//					if(doc.equals("bdnFile")) {
//						attachments.setFileName(doc);
//						attachments.setFileContent(obj.getBdnFile());
//					}else if(doc.equals("mfmFile")) {
//						attachments.setFileName(doc);
//						attachments.setFileContent(obj.getMfmFile());
//					}else if(doc.equals("meterTicket")) {
//						attachments.setFileName(doc);
//						attachments.setFileContent(MFMTicket.getContent());
//					}
//					attachmentsList.add(attachments);
//				}
			
//			    map.put("bdnFile", obj.getBdnFile());
//			    map.put("mfmFile", obj.getMfmFile());
//			    map.put("meterTicket", MFMTicket.getContent());
				
			// reports list take from reports_job table 	
				for(Reports repolist :reportsList) {
					FilesData report = new FilesData();
					report.setFileName(repolist.getReportName());
					report.setFileContent(repolist.getReportFileBinary());
					filesList.add(report);
					
				}
			// meter ticket from attachments table
				if(MFMTicket != null) {
					FilesData meterTicket = new FilesData();
					meterTicket.setFileName("meterTicket");
					meterTicket.setFileContent(MFMTicket.getContent());
					filesList.add(meterTicket);
				}
			    data.setAttachments(filesList);
			    deliveryList.add(data);
			    }
			for(BunkerDeliveryNoteToIbmsWithAttachments pojo :deliveryList) {
				jobDeliveryAuditlogRepo.updateAuditLog(pojo.getId(),LocalDateTime.now(),1);
			}

			} catch (Exception e) {
			log.error("Unable to get bunker delivery notes for job no, ", e);
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(deliveryList, HttpStatus.OK);
	}
	@RequestMapping(value = Utilities.APP_VERSION + "/data/pull/bunker_loading_jobs", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAllLoadingJobs() {
		List<BunkerLoadingToIbms> list = null;
		List<BunkerLoadingToIbmsWithAttachments> loadingList = new ArrayList<>();
		try {
			list = bunkerLoadingToIbmsRepository.findAll();

			for(BunkerLoadingToIbms obj :list) {
				BunkerLoadingToIbmsWithAttachments data = new BunkerLoadingToIbmsWithAttachments();
				File MFMTicket = new File();
				//HashMap<String,Object> map=new HashMap<String,Object>();
				List<FilesData> filesList =new ArrayList<>();
				//List<HashMap<String,Object>> mapList=new ArrayList<>();
				List<Reports> reportsList =new ArrayList<>();
				MFMTicket = dbFileRepository.getLatestMeterTicket(obj.getId());
				reportsList =reportsRepository.findByJobId(obj.getId());
				//MFMReadingData mfmData = jobService.getMFMReadingData(obj.getId());
				BeanUtils.copyProperties(data, obj);
				// reports list take from reports_job table 	
				for(Reports repolist :reportsList) {
					FilesData report = new FilesData();
					report.setFileName(repolist.getReportName());
					report.setFileContent(repolist.getReportFileBinary());
					filesList.add(report);
					
				}
				// meter ticket from attachments table
				if(MFMTicket != null) {
					FilesData meterTicket = new FilesData();
					meterTicket.setFileName("meterTicket");
					meterTicket.setFileContent(MFMTicket.getContent());
					filesList.add(meterTicket);
				}
//			    map.put("mfmFile", obj.getMfmFile());
//			    map.put("meterTicket", MFMTicket.getContent());
//			    mapList.add(map);
			    data.setAttachments(filesList);
			    loadingList.add(data);
			    }

			} catch (Exception e) {
			log.error("Unable to get all published bunker_loading_jobs, ", e);
			return new ResponseEntity<Object>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(loadingList, HttpStatus.OK);
	}
	
	
}
