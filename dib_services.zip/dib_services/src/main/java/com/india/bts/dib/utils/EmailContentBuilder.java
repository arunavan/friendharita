///*******************************************************************************
// * BTS INDIA COPYRIGHT
// * ___________________
// *   
// * [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
// * All Rights Reserved.
// *   
// * NOTICE:  All information contained herein is, and remains
// * the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
// * if any.  The intellectual and technical concepts contained
// * herein are proprietary to BTS IT Solutions India Pvt. Ltd.
// * and its suppliers and are protected by trade secret or copyright law.
// * Dissemination of this information or reproduction of this material
// * is strictly forbidden unless prior written permission is obtained
// * from BTS IT Solutions India Pvt. Ltd.
// ******************************************************************************/
//
package com.india.bts.dib.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.mail.internet.MimeMessage;
import javax.mail.search.DateTerm;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.india.bts.dib.domain.EmailContent;
import com.india.bts.dib.domain.EmailNotificationLog;
import com.india.bts.dib.domain.JOBTYPE;
import com.india.bts.dib.domain.Job;
import com.india.bts.dib.domain.TaskType;
import com.india.bts.dib.domain.User;
import com.india.bts.dib.domain.UserRole;
import com.india.bts.dib.repository.EmailContentRepository;
import com.india.bts.dib.repository.EmailNotificationLogRepository;
import com.india.bts.dib.repository.JobRepository;
import com.india.bts.dib.repository.UserRepository;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.service.MailContentBuilder;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Component
public class EmailContentBuilder implements  Runnable {

	@Autowired
	EmailContentRepository emailContentRepository;
	@Autowired
	CurrentUserService currentUserService;
	@Autowired
	MailContentBuilder mailContentBuilder;
	@Autowired
	UserRepository userRepository;
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	EmailNotificationLogRepository emailNotificationLogRepository;
	@Autowired
	JavaMailSender mailSender;
	@Autowired
	JobRepository jobRepo;
	
	
	@Value("${spring.datasource.url}")
	private String datasource;
	@Value("${admin.email}")
	private String adminEmail;
	@Value("${admin.name}")
	private String adminName;
	@Value("${developer.email}")
	private String developerEmail;
	@Value("${developer.name}")
	private String developerName;

	private Job job;
	private TaskType taskType;

	public EmailContentBuilder(Job job, TaskType taskType){
        this.job  = job;
        this.taskType = taskType;
    }

	public EmailContentBuilder(){
    }
	
	@Override
	public void run(){
		
		String emailResponse = null;
		User user = null;
		try {
			switch (taskType) {
			case SEND_EMAIL_FOR_VESSEL_LOGIN:
				if( job == null || StringUtils.isBlank(job.getVesselEmail()))
				{
					//DON'T SEND EMAIL NOTIFICATION BECAUSE THE VESSEL EMAIL IS NOT AVAILABLE.
					log.warn("Vessel email is blank or not available so, not sending email.");
					return;
				}
				else
				{
//					TODO: CHECK IF USER ACCOUNT EXISTS WITH VESSEL EMAIL
//					IF YES:  THEN RESET THE PWD TO RANDOM PWD
//					IF NO: CREATE NEW USER WITH VESSEL EMAIL AND RANDOM PWD
					user = createUserIfNotExists(taskType);
					File resource1 =null;
					EmailContent emailContent = buildEmailContentForUserLogin(job, user);
					File resource = new ClassPathResource(
						      "documents/User Manuals/Chief Engineer.pdf").getFile();
					
					if(job.getFuelCategoryId()!=null && job.getFuelCategoryId()==1 ) {
						  resource1 = new ClassPathResource(
								      "documents/User Manuals/MGO.pdf").getFile();
						}else if(job.getFuelCategoryId()!=null && job.getFuelCategoryId()==2) {
							resource1 = new ClassPathResource(
								      "documents/User Manuals/MFO.pdf").getFile();
						}else if(job.getFuelCategoryId()!=null &&job.getFuelCategoryId()==3) {
							resource1 = new ClassPathResource(
								      "documents/User Manuals/BIO FUEL.pdf").getFile();
					}else {
						resource1 =null;
					}
					if(resource1!=null) {
					emailResponse = sendEmail(emailContent,resource,resource1);
					}else {
						emailResponse = sendEmail(emailContent,resource);
					}
					if(StringUtils.containsIgnoreCase(emailResponse, "EMAIL SENT.")) 
					{
						jobRepo.incrementVeselEmailSendCount(job.getId());
						log.info("Email sent to Vessel CE along with login details and incremented the email send count");
					}
					else 
					{
						throw new Exception("Unable to send email to Vessel C/E, error details: "+emailResponse);
					}
					
				}
				break;

			case SEND_EMAIL_FOR_SURVEYOR_LOGIN:
				if( job == null || StringUtils.isBlank(job.getSurveyorEmail()))
				{
					//DON'T SEND EMAIL NOTIFICATION BECAUSE THE VESSEL EMAIL IS NOT AVAILABLE.
					log.warn("Surveyor email is blank or not available so, not sending email.");
					return;
				}
				else
				{
					user= userRepository.findByEmail(job.getSurveyorEmail());
					user = createUserIfNotExists(taskType);

					EmailContent emailContent = buildEmailContentForUserLogin(job, user);
					File resource = new ClassPathResource(
						      "documents/User Manuals/Surveyor.pdf").getFile();
					emailResponse = sendEmail(emailContent,resource);
					if(StringUtils.containsIgnoreCase(emailResponse, "EMAIL SENT.")) 
					{
						jobRepo.incrementSurveyorEmailSendCount(job.getId());
						log.info("Email sent to Surveyor along with login details and incremented the email send count");

					}
					else 
					{
						throw new Exception("Unable to send email to Surveyor, error details: "+emailResponse);
					}
					
				}
				break;

			default:
				break;
			}
			
		} catch (Exception e) {
			log.error("Unable to build Email Content, error details:  "+e.getMessage());
			e.printStackTrace();
			emailNotificationLogRepository.save(new EmailNotificationLog(user.getFirstName(),job.getVesselEmail(),"Unable to built Email Content (or) send email to Vessel C/E or Surveyor for task type:"+taskType.toString()+", possible error:  "+e.getMessage(),job.getId(),null));
		}
	}

	private String sendEmail(EmailContent emailContent,File resource) throws Exception {
		String emailResponse;
		emailContent.setJobId(job.getId());
		emailContent.setCreatedDate(DateTime.now());
		emailContent = emailContentRepository.save(emailContent);
		emailResponse = sendEmailWithContent(emailContent,resource);
		return emailResponse;
	}
	private String sendEmail(EmailContent emailContent,File resource,File resource1) throws Exception {
		String emailResponse;
		emailContent.setJobId(job.getId());
		emailContent.setCreatedDate(DateTime.now());
		emailContent = emailContentRepository.save(emailContent);
		emailResponse = sendEmailWithContent(emailContent,resource,resource1);
		return emailResponse;
	}

	private User createUserIfNotExists(TaskType taskType) {

		User user = null;
		String userEmail = null;
		String requiredUserRole = null;
		String existingUserRole = null;
		if(taskType == taskType.SEND_EMAIL_FOR_VESSEL_LOGIN)
		{
			user= userRepository.findByEmail(job.getVesselEmail()); 
			userEmail = job.getVesselEmail();
			requiredUserRole = "CHIEF ENGINEER";
		}
		else if(taskType == taskType.SEND_EMAIL_FOR_SURVEYOR_LOGIN)
		{
			user= userRepository.findByEmail(job.getSurveyorEmail()); 
			userEmail = job.getSurveyorEmail();
			requiredUserRole = "SURVEYOR";
		}
		
		String strongPassword = Utilities.generateStrongPassword(10);
		String simplePassword="";

		if(user!=null)
		{
			user.setPassword(bCryptPasswordEncoder.encode(strongPassword));
			// to simply the password 28/9/2023
//			if(job.getJobType().equals(JOBTYPE.delivery)) {
//				simplePassword=user.getFirstName().substring(0,1)+user.getFirstName().substring((user.getFirstName().length())-1)+"@"+job.getVesselIMO().substring(0,5);
//			}else if(job.getJobType().equals(JOBTYPE.loading)) {
//				simplePassword=user.getFirstName().substring(0,1)+user.getFirstName().substring((user.getFirstName().length())-1)+"@"+job.getPurchaseOrderNo().replaceAll("[^0-9]","");
//			}else {
//				simplePassword=user.getFirstName().substring(0,1)+user.getFirstName().substring((user.getFirstName().length())-1)+"@"+job.getTransferOrderNo().replaceAll("[^0-9]","");
//			}
//			user.setPassword(bCryptPasswordEncoder.encode(simplePassword));
			log.warn("User with email "+userEmail+" already exists in the system so not creating a new user but resetting the pwd to a strong password for this job");
			if(!StringUtils.equalsIgnoreCase(user.getRole(),  requiredUserRole))
			{
				log.error("Error: User with email "+userEmail+" already exists with role "+user.getRole()+" but the required role to use the system consistently is "+requiredUserRole+" but anyhow sending email to the user to use the system but this may lead to inconsistent state of using the system.");
			}

		}
		else
		{
			user = new User();
			user.setPassword(strongPassword);
			user.setRequiredToResetPassword(false);
			user.setCreatedDate(DateTime.now());
			user.setUpdatedDate(DateTime.now());
			user.setBargeId(job.getBargeId());
			Set<UserRole> roles = new HashSet<UserRole>();
			UserRole role = null;
			if(taskType == taskType.SEND_EMAIL_FOR_VESSEL_LOGIN)
			{
				user.setEmail(job.getVesselEmail());
				user.setFirstName("Chief");
				user.setLastName("Engineer");
				user.setRole("CHIEF ENGINEER");
				role = new UserRole(4L, "CHIEF ENGINEER");
				
			}
			else//AS OF NOW, THE ONLY OTHER USER ROLE WHO CAN LOGIN FOR THE SAME JOB IS SUREVYOR SO SETTING THIS AS DEFAULT CASE.
			{
				user.setEmail(job.getSurveyorEmail());
				user.setFirstName("Surveyor");
				user.setLastName("");
				user.setRole("SURVEYOR");
				role = new UserRole(5L, "SURVEYOR");
			}
			roles.add(role);
			user.setRoles(roles);
			user.setPassword(bCryptPasswordEncoder.encode(strongPassword));
//			if(job.getJobType().equals(JOBTYPE.delivery)) {
//				simplePassword=user.getFirstName().substring(0,1)+user.getFirstName().substring((user.getFirstName().length())-1)+"@"+job.getVesselIMO().substring(0,5);
//			}else if(job.getJobType().equals(JOBTYPE.loading)) {
//				simplePassword=user.getFirstName().substring(0,1)+user.getFirstName().substring((user.getFirstName().length())-1)+"@"+job.getPurchaseOrderNo().replaceAll("[^0-9]","");
//			}else {
//				simplePassword=user.getFirstName().substring(0,1)+user.getFirstName().substring((user.getFirstName().length())-1)+"@"+job.getTransferOrderNo().replaceAll("[^0-9]","");
//			}
//			user.setPassword(bCryptPasswordEncoder.encode(simplePassword));
			log.info("User with email "+userEmail+" doesn't exist in the system so, creating a new user with role "+requiredUserRole);
					
		}
		user = userRepository.save(user);
		user.setPlainPassword(strongPassword);
		//user.setPlainPassword(simplePassword);
		return user;
	}
	

	public EmailContent buildEmailContentForUserLogin(Job job, User user) throws Exception {
		String toName = user.getFirstName()+" "+user.getLastName();
		String subject = "Your login details for Digital Bunkering @ Sea App.";
		String toEmailId = user.getEmail();
		
		
		String template = null;
		if(StringUtils.equalsIgnoreCase(user.getRole(), "CHIEF ENGINEER"))
		{
			template = Constants.VESSEL_CE_LOGIN_EMAIL_TEMPLATE;
		}
		else if(StringUtils.equalsIgnoreCase(user.getRole(), "SURVEYOR"))
		{
			template = Constants.SURVEYOR_LOGIN_EMAIL_TEMPLATE;
		}

		Map<String, String> tokens = new HashMap<>(); 
		tokens.put("RECEIVER_NAME",toName);
		if(Constants.Environment.equals("QA")) {
			tokens.put("APP_URL", Constants.APP_URL_QA);
		}else if(Constants.Environment.equals("PROD")) {
			tokens.put("APP_URL", Constants.APP_URL_PROD);
		}else {
			tokens.put("APP_URL", Constants.APP_URL);
		}
		tokens.put("USER_NAME", user.getEmail());
		tokens.put("PASSWORD", user.getPlainPassword());
		tokens.put("BDN_PARTY_NAME", job.getBdnPartyName());
		String emailBody = mailContentBuilder.build(template, tokens);

		EmailContent emailContent = new EmailContent();
		emailContent.setToEmailId(toEmailId);
		emailContent.setFromEmailId(Constants.EMAIL_FROM_EMAIL_ID);
		if(org.apache.commons.lang.StringUtils.isNotBlank(Constants.CC_EMAIL_ID))
		{
			emailContent.setCcEmailId(Constants.CC_EMAIL_ID); 
		}
		if(org.apache.commons.lang.StringUtils.isNotBlank(Constants.BCC_EMAIL_ID))
		{
			emailContent.setBccEmailId(Constants.BCC_EMAIL_ID); 
		}

		emailContent.setSubject(subject);
		emailContent.setBody(emailBody);
		return emailContent;
	}
	
	public boolean isLocalMode()
	{
		//CONSIDERING BOTH LOCAL HOST AND TEST DB AS LOCAL MODE SO THAT EMAILS ARE NOT SENT UNNECESSARILY TO THE ADMIN EMAIL ON TEST AND LOCAL ENV.
		//IF NEEDED, THE TEST DB CAN BE REMOVED FROM THE BELOW LIST SO THAT EMAILS ARE SENT ON TEST ENV.
		return false;
//		return StringUtils.containsIgnoreCase(datasource, "LOCALHOST");
				
	}
	
	public String sendEmailWithContent(EmailContent emailContent,File resource) throws Exception {
		try {
			if(isLocalMode())
			{
				log.warn("Running in Local mode so, skipping email notfications to Surveyor and Admin");
				return null;
			}
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);
			String[] toEmailIds = cleanup(emailContent.getToEmailId());
			if (toEmailIds == null || toEmailIds.length == 0 || StringUtils.isBlank(toEmailIds[0])) {
				log.error("To email id not found for email content with id:" + emailContent.getId()
						+ ", so not sending email.");
				throw new InvalidEmailException("To email id not found for email content with id:" + emailContent.getId()
						+ ", so not sending email.");
			}
			if (toEmailIds != null && toEmailIds.length > 0) {
				for (String emailId : toEmailIds) {
					if (!Utilities.isValidEmailAddress(emailId)) {
						log.error("To email id not found for email content with id:" + emailContent.getId()
								+ ", so not sending email.");
						throw new InvalidEmailException("To email id not found for email content with id:" + emailContent.getId()
								+ ", so not sending email.");
					}
				}
			}
			String[] ccEmailIds = cleanup(emailContent.getCcEmailId());
			String[] bccEmailIds = cleanup(emailContent.getBccEmailId());
			String frmEmailId = emailContent.getFromEmailId();
			if (StringUtils.isBlank(frmEmailId)) {
				frmEmailId = Constants.EMAIL_FROM_EMAIL_ID;
			}
			messageHelper.setTo(toEmailIds);
			if (ccEmailIds != null && ccEmailIds.length > 0) {
				messageHelper.setCc(ccEmailIds);
			}
			if (bccEmailIds != null && bccEmailIds.length > 0) {
				messageHelper.setBcc(bccEmailIds);
			}

			message.setFrom(frmEmailId);
			messageHelper.setSubject(emailContent.getSubject());
			messageHelper.setText(emailContent.getBody(), true);
//			File resource = new ClassPathResource(
//				      "documents/User Manuals/Chief Engineer.pdf").getFile();
			//FileSystemResource file = new FileSystemResource("D:/BOLISETTI SRIVIDYA CV.PDF");
			messageHelper.addAttachment("User Manual", resource);
			mailSender.send(message);
			log.debug("Sent email with attachments");
			//mailSender.send(message);
			return "Email sent.";
		} catch (Exception e) {
			if (StringUtils.containsIgnoreCase(e.getMessage(), "email id not found")) {
				throw e;
			}
			log.error("Unable to send eMail because of no internet."+e);
//			throw new Exception("Unable to send email");
			return e.getMessage();
		}
	}
	public String sendEmailWithContent(EmailContent emailContent,File resource,File resource1) throws Exception {
		try {
			if(isLocalMode())
			{
				log.warn("Running in Local mode so, skipping email notfications to Surveyor and Admin");
				return null;
			}
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);
			String[] toEmailIds = cleanup(emailContent.getToEmailId());
			if (toEmailIds == null || toEmailIds.length == 0 || StringUtils.isBlank(toEmailIds[0])) {
				log.error("To email id not found for email content with id:" + emailContent.getId()
						+ ", so not sending email.");
				throw new InvalidEmailException("To email id not found for email content with id:" + emailContent.getId()
						+ ", so not sending email.");
			}
			if (toEmailIds != null && toEmailIds.length > 0) {
				for (String emailId : toEmailIds) {
					if (!Utilities.isValidEmailAddress(emailId)) {
						log.error("To email id not found for email content with id:" + emailContent.getId()
								+ ", so not sending email.");
						throw new InvalidEmailException("To email id not found for email content with id:" + emailContent.getId()
								+ ", so not sending email.");
					}
				}
			}
			String[] ccEmailIds = cleanup(emailContent.getCcEmailId());
			String[] bccEmailIds = cleanup(emailContent.getBccEmailId());
			String frmEmailId = emailContent.getFromEmailId();
			if (StringUtils.isBlank(frmEmailId)) {
				frmEmailId = Constants.EMAIL_FROM_EMAIL_ID;
			}
			messageHelper.setTo(toEmailIds);
			if (ccEmailIds != null && ccEmailIds.length > 0) {
				messageHelper.setCc(ccEmailIds);
			}
			if (bccEmailIds != null && bccEmailIds.length > 0) {
				messageHelper.setBcc(bccEmailIds);
			}

			message.setFrom(frmEmailId);
			messageHelper.setSubject(emailContent.getSubject());
			messageHelper.setText(emailContent.getBody(), true);
//			File resource = new ClassPathResource(
//				      "documents/User Manuals/Chief Engineer.pdf").getFile();
			//FileSystemResource file = new FileSystemResource("D:/BOLISETTI SRIVIDYA CV.PDF");
			messageHelper.addAttachment("User Manual", resource);
			messageHelper.addAttachment("MSDS", resource1);
			mailSender.send(message);
			log.debug("Sent email with attachments");
			//mailSender.send(message);
			return "Email sent.";
		} catch (Exception e) {
			if (StringUtils.containsIgnoreCase(e.getMessage(), "email id not found")) {
				throw e;
			}
			log.error("Unable to send eMail because of no internet."+e);
//			throw new Exception("Unable to send email");
			return e.getMessage();
		}
	}

	public String sendEmailWithContent(EmailContent emailContent) throws Exception {
		try {
			if(isLocalMode())
			{
				log.warn("Running in Local mode so, skipping email notfications to Surveyor and Admin");
				return null;
			}
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true);
			String[] toEmailIds = cleanup(emailContent.getToEmailId());
			if (toEmailIds == null || toEmailIds.length == 0 || StringUtils.isBlank(toEmailIds[0])) {
				log.error("To email id not found for email content with id:" + emailContent.getId()
						+ ", so not sending email.");
				throw new InvalidEmailException("To email id not found for email content with id:" + emailContent.getId()
						+ ", so not sending email.");
			}
			if (toEmailIds != null && toEmailIds.length > 0) {
				for (String emailId : toEmailIds) {
					if (!Utilities.isValidEmailAddress(emailId)) {
						log.error("To email id not found for email content with id:" + emailContent.getId()
								+ ", so not sending email.");
						throw new InvalidEmailException("To email id not found for email content with id:" + emailContent.getId()
								+ ", so not sending email.");
					}
				}
			}
			String[] ccEmailIds = cleanup(emailContent.getCcEmailId());
			String[] bccEmailIds = cleanup(emailContent.getBccEmailId());
			String frmEmailId = emailContent.getFromEmailId();
			if (StringUtils.isBlank(frmEmailId)) {
				frmEmailId = Constants.EMAIL_FROM_EMAIL_ID;
			}
			messageHelper.setTo(toEmailIds);
			if (ccEmailIds != null && ccEmailIds.length > 0) {
				messageHelper.setCc(ccEmailIds);
			}
			if (bccEmailIds != null && bccEmailIds.length > 0) {
				messageHelper.setBcc(bccEmailIds);
			}

			message.setFrom(frmEmailId);
			messageHelper.setSubject(emailContent.getSubject());
			messageHelper.setText(emailContent.getBody(), true);
			mailSender.send(message);
			log.debug("Sent email with attachments");
			mailSender.send(message);
			return "Email sent.";
		} catch (Exception e) {
			if (StringUtils.containsIgnoreCase(e.getMessage(), "email id not found")) {
				throw e;
			}
			log.error("Unable to send eMail because of no internet."+e);
//			throw new Exception("Unable to send email");
			return e.getMessage();
		}
	}

	
	private String[] cleanup(String emailIds) {
		if (StringUtils.isNotBlank(emailIds)) {
			String[] tokens = emailIds.split(",");
			List<String> emails = new ArrayList<>();
			for (String email : tokens) {
				if (StringUtils.contains(email, "@") && StringUtils.contains(email, ".")) {
					emails.add(email);
				} else {
					log.error("Invalid email:" + email);
				}
			}
			if (emails.size() > 0) {
				log.debug("Cleaned up emails:" + emails);
				String[] emailIdsArray = new String[emails.size()];
				emailIdsArray = emails.toArray(emailIdsArray);
				return emailIdsArray;
			}
		}
		return null;
	}
}


