package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.india.bts.dib.domain.MFMReadingData;

public interface MFMReadingDataRepository extends JpaRepository<MFMReadingData, Long> {
	
	MFMReadingData findByJobId(long jobId);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE mfm_reading_data SET mfm_file_binary=:mfm_file_binary WHERE job_id = :jobId ", nativeQuery=true)
	void updateBinaryData(@Param("mfm_file_binary") String mfm_file_binary,@Param("jobId") Long jobId);

	@Modifying
	@Transactional
	@Query(value ="UPDATE mfm_reading_data SET commenced_pumping_start =:commenced_pumping_start,commenced_pumping_stop =:commenced_pumping_stop ,delivery_totaliser_reading_a=:delivery_totaliser_reading_a ,"
			+ "delivery_totaliser_reading_b=:delivery_totaliser_reading_b,loading_totaliser_reading_x=:loading_totaliser_reading_x,"
			+ "loading_totaliser_reading_y=:loading_totaliser_reading_y,bmt_number=:bmt_number,quantity_supplied=:quantity_supplied WHERE job_id = :jobId ", nativeQuery=true)
	void updatePumpingStartEndTimes(@Param("commenced_pumping_start") String commenced_pumping_start,@Param("commenced_pumping_stop") String commenced_pumping_stop,@Param("bmt_number") String bmt_number,
			@Param("delivery_totaliser_reading_a")  String delivery_totaliser_reading_a,@Param("delivery_totaliser_reading_b") String delivery_totaliser_reading_b, @Param("loading_totaliser_reading_x") String loading_totaliser_reading_x,
			@Param("loading_totaliser_reading_y") String loading_totaliser_reading_y,@Param("quantity_supplied") String quantity_supplied, @Param("jobId") Long jobId);
	
	@Modifying
	@Transactional
	@Query(value ="UPDATE mfm_reading_data SET commenced_pumping_start =:commenced_pumping_start,commenced_pumping_stop =:commenced_pumping_stop ,delivery_totaliser_reading_a=:delivery_totaliser_reading_a ,"
			+ "delivery_totaliser_reading_b=:delivery_totaliser_reading_b,loading_totaliser_reading_x=:loading_totaliser_reading_x,"
			+ "loading_totaliser_reading_y=:loading_totaliser_reading_y,bmt_number=:bmt_number WHERE job_id = :jobId ", nativeQuery=true)
	void updatePumpingStartEndTimesWithoutDelivered(@Param("commenced_pumping_start") String commenced_pumping_start,@Param("commenced_pumping_stop") String commenced_pumping_stop,@Param("bmt_number") String bmt_number,
			@Param("delivery_totaliser_reading_a")  String delivery_totaliser_reading_a,@Param("delivery_totaliser_reading_b") String delivery_totaliser_reading_b, @Param("loading_totaliser_reading_x") String loading_totaliser_reading_x,
			@Param("loading_totaliser_reading_y") String loading_totaliser_reading_y,@Param("jobId") Long jobId);

	//updating signatures to null if any changes made in meterticket
	@Modifying
	@Transactional
	@Query(value ="UPDATE mfm_reading_data SET ce_post_sign_datetime= null,co_post_sign_datetime= null,sur_post_sign_datetime=null,mfm_file_binary=null, "
			+ "Post_CO_Sign=null,Post_CE_Sign=null,Post_SV_Sign=null WHERE job_id = :jobId ", nativeQuery=true)
	void clearDateFields(@Param("jobId") Long jobId);

//	@Modifying
//	@Transactional
//	@Query(value ="UPDATE mfm_reading_data SET commenced_pumping_start =:commenced_pumping_start,commenced_pumping_stop =:commenced_pumping_stop WHERE job_id = :jobId ", nativeQuery=true)
//	void updatePumpingStartEndTimes(@Param("commenced_pumping_start") String commenced_pumping_start, @Param("commenced_pumping_stop") String commenced_pumping_stop,@Param("jobId") Long jobId);
}
