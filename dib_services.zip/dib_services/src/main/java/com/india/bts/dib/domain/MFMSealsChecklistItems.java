package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="mfm_seals_checklist_items") 
public class MFMSealsChecklistItems implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -11300308776453777L;

	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=true,name="seal_category",length=500)
    private String sealCategory;
	
	@Column(nullable=true,name="seal_location",length=500)
    private String sealLocation;

	@Column(nullable=true,name="seal_number",length=200)
    private String sealNumber;
	
	@Column(nullable=true,name="tag_number",length=500)
    private String tagNumber;
	
	@Column(nullable=true,name="intact_before")
    private String intactBefore;
	
	@Column(nullable=true,name="intact_after")
    private String intactAfter;
	
	@Column(nullable=true,name="remarks ", columnDefinition = "TEXT")
    private String remarks;
	
	@Column(nullable = true, name = "is_default", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean itDefault;
	
	
	@ManyToOne
	@JsonIgnore
    private MFMSealsChecklistData mfmSealsChecklist;
								  
}
