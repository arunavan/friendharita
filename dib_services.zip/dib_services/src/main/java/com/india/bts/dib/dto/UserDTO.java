/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _________________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.dto;

import java.util.Set;

import com.india.bts.dib.domain.UserRole;

import lombok.Data;

@Data
public class UserDTO {
	
	private Long id;
	
	private String firstName;

	private String lastName;
	
	private String phoneNumber;
		
	private String email;
	
	private String password;
	
	private Set<UserRole> roles;
	
	private String license;
	
	private Long bargeId;
	
	private boolean accountEnabled;
	private boolean accountExpired;
	private boolean requiredToResetPassword;
	private boolean accountLocked;
	
	
	public UserDTO() {}

	public UserDTO(Long id, String firstName, String lastName, String phoneNumber, String email,
			String password, Set<UserRole> roles, boolean accountEnabled, boolean accountExpired,
			boolean accountLocked,Long bargeId,String port,String license)
	 {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.password = password;
		this.roles = roles;
		this.accountEnabled = accountEnabled;
		this.accountExpired = accountExpired;
		this.accountLocked = accountLocked;
		this.bargeId = bargeId;
		this.license = license;
	}
	
}
