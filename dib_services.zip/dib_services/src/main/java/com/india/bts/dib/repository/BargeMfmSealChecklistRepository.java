package com.india.bts.dib.repository;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import com.india.bts.dib.domain.BargeMfmSealChecklist;

@Repository
public interface BargeMfmSealChecklistRepository extends JpaRepository<BargeMfmSealChecklist, Long> {
	
	@Transactional
	@Modifying
	void deleteByBargeId(Long bargeId);
	
	@Transactional
	@Modifying
	void deleteByBargeIdAndVerificationReportDate(Long bargeId, LocalDate verificationReportDate);
	
	List<BargeMfmSealChecklist>  findByBargeId(Long bargeId);
	List<BargeMfmSealChecklist>  findByBargeIdOrderByVerificationReportDateDesc(Long bargeId);
	
	List<BargeMfmSealChecklist>  findByBargeIdOrderBySealCategoryDescTagNumberDescVerificationReportDateDesc(Long bargeId);
	
	List<BargeMfmSealChecklist>  findByVerificationReportDateAndBargeId(LocalDate date, Long bargeId);


}
