package com.india.bts.dib.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.india.bts.dib.domain.BunkerSafetyChecklistItems;

public interface BunkerSafetyChecklistItemsRepository extends JpaRepository<BunkerSafetyChecklistItems, Long> {

	@Modifying
	@Transactional
	void deleteByBunkerSafetyChecklistId(long id);

//	  @Query(value="SELECT * FROM bunker_safety_checklist_items WHERE IN ?1", nativeQuery=true)
//	  List<BunkerSafetyChecklistItems> findByBunkerSafetyChecklistDataId(long id);

//	  List<BunkerSafetyChecklistItems> findByBunkerSafetyChecklistId(long id);

}
