/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _________________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.utils;

import java.io.File;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.formula.functions.T;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.util.ReflectionUtils;

import com.india.bts.dib.domain.User;
import com.india.bts.dib.domain.UserRole;

public class Utilities {

	public final static String APP_VERSION = "/api/v1/";
	public final static String APP_VERSION2 = "/api/v2/";

	public final static String API_PATH_SAFETY_CHECKLIST = "safety-checklist";
	public final static String API_PATH_SEAL_CHECKLIST = "seal-checklist";
	
	public final static String API_PATH_BDN_PARTY = "bdn-party";

	public static DateTimeFormatter formatter = DateTimeFormat.forPattern("dd MMM yyyy");
	public static DateTimeFormatter datAsPath= DateTimeFormat.forPattern("yyyy/MM/dd");
    private static final Logger LOGGER = LoggerFactory.getLogger(Utilities.class);
    
	public static String getTodaysDate()
	{
		Date dt = new Date();
		return formatter.print(dt.getTime());
	}
	
	public static String testDate()
	{
		DateTimeFormatter formatter = DateTimeFormat.forPattern("EEEE d MMMM hh:mm a");
		Date dt = new Date();
		return formatter.print(dt.getTime());
			
	}
	
	public static String generateEncryptedPwd(String pwd)
	{
		if(StringUtils.isNotBlank(pwd))
		{
			pwd = new BCryptPasswordEncoder().encode(pwd);
		}
		return pwd;
	}


	public static String removeCharsAndSpaces(String number)
	{
		String cleanNumber = number;
		if(StringUtils.isNotBlank(number))
		{
			cleanNumber = number.replaceAll("[^0-9.]", "");
		}
		return cleanNumber;
		
	}
	
	public static void main(String[] args) throws Exception {
//	System.out.println("test");
//	String type = seperateValuesFromKey("jobId:13^^type:BARGE-SOUNDING-MEASUREMENTS-CLOSING-READINGS^^bargeGrade:RMG-380 (2005)","bargeGrade");
//	System.out.println("Encrypted PWD: "+generateEncryptedPwd("Chandan@123"));
		String str= "110adsf. 344 This#string%contains^special*characters& st147 7489";   
		str = str.replaceAll("[^0-9.]", "");
		System.out.println("Pure number"+str);
	}
	
	public static Date nominationDateFormat(String dateString) throws ParseException {
		if(! (dateString == null)) {
		    Date date=new SimpleDateFormat("ddMMMyyyy").parse(dateString);  
		    return date;			
		}
		return null;
	}

	public static String refineStringForPdfContent(String text) {
		text= StringUtils.replace(text, "<b>", "");
		text= StringUtils.replace(text, "</b>", "");
		text= StringUtils.replace(text, "'", "");
		text= StringUtils.replace(text, "\"", "");
		text = text.toUpperCase();
		return text;
	}

	public static void cleanupFilesFromStorage(File file) {
		if(file!=null && file.exists())
		{
			file.delete();
		}
		
	}
	
	public static String cleanupFileName(String fileName)
	{
		if(StringUtils.isNotBlank(fileName))
		{
			fileName = StringUtils.replaceChars(fileName, " ", "_");
			fileName = StringUtils.replaceChars(fileName, "'", "_");
			fileName = StringUtils.replaceChars(fileName, "\"", "_");
		}
		return fileName;
	}
	
	public static Map<String,T> getAsMap(List<T> list)
	{
		Map<String,T> map = new HashMap<String, T>();
		for(Object obj: list)
		{
			map.put(obj.toString(), (T)obj);
		}
		return map;
	}




	public static boolean isValidEmailAddress(String email) {
		   boolean result = true;
		   try {
		      InternetAddress emailAddr = new InternetAddress(email);
		      emailAddr.validate();
		   } catch (AddressException ex) {
		      result = false;
		   }
		   return result;
		}


	@SuppressWarnings("unchecked")
	public static void updateAuditInfo(Object newObject, Object existingObject, String userName) throws Exception {
		try {
			@SuppressWarnings("rawtypes")
			Class cls = newObject.getClass();
			if(
					ReflectionUtils.findMethod(cls, "setCreatedDate", DateTime.class)==null
					||
					ReflectionUtils.findMethod(cls, "setCreatedUser", String.class)==null
					||
					ReflectionUtils.findMethod(cls, "setUpdatedDate", DateTime.class)==null
					||
					ReflectionUtils.findMethod(cls, "setUpdatedUser", String.class)==null
			
			  )
			{
				LOGGER.warn("Audit info methods are missing in class:"+cls.getCanonicalName()+" so, skipping the process of adding audit info. Please check methods: setCreatedDate, setCreatedUser, setUpdatedDate, setUpdatedUser in that class");
				return;
			}

			Method setCreatedDate = cls.getDeclaredMethod("setCreatedDate", DateTime.class);
			Method getCreatedDate = cls.getDeclaredMethod("getCreatedDate");
			Method setCreatedUser = cls.getDeclaredMethod("setCreatedUser", String.class);
			Method getCreatedUser = cls.getDeclaredMethod("getCreatedUser");
			Method setUpdatedDate = cls.getDeclaredMethod("setUpdatedDate", DateTime.class);
			Method setUpdatedUser = cls.getDeclaredMethod("setUpdatedUser", String.class);
			Method getId = cls.getDeclaredMethod("getId");
			
			Long idValue = (Long)getId.invoke(newObject); 

			if(idValue==null || idValue==0)//So its a new object, createdDate and createdUser will be null so update them as well
			{
				setCreatedDate.invoke(newObject, DateTime.now());
				setCreatedUser.invoke(newObject, userName);
				
			}
			else if(existingObject!=null)
			{
				DateTime createdDate = (DateTime) getCreatedDate.invoke(existingObject);
				String createdUser = (String) getCreatedUser.invoke(existingObject);
				setCreatedDate.invoke(newObject, createdDate);
				setCreatedUser.invoke(newObject, createdUser);
			}
			setUpdatedDate.invoke(newObject, DateTime.now());
			setUpdatedUser.invoke(newObject, userName);
		} catch (Exception e) {
			LOGGER.error("Failed to update audit info:", e);
			throw e;
		}
	}
	
	public static String getjobIdFromId(String id) throws Exception {
		if(StringUtils.isBlank(id) || !StringUtils.contains(id, "-"))
		{
			throw new Exception("Unable to get jobId from id as id["+id+"] is empty or doesn't contain the delimiter -");
		}
		return StringUtils.substringBefore(id, "-");
	}
	
	public static String getGradeFromId(String id) throws Exception {
		if(StringUtils.isBlank(id) || !StringUtils.contains(id, "-"))
		{
			throw new Exception("Unable to get Grade from id as id["+id+"] is empty or doesn't contain the delimiter -");
		}
		return StringUtils.substringAfter(id, "-");
	}
	
	//ID format: jobId-grade of invoice 
		public static String buildId(String jobId,String grade) throws Exception {
			if(StringUtils.isBlank(jobId) || grade == null)
			{
				throw new Exception("Invalid jobId["+jobId+"] or grade["+grade+"] to build ID");
			}else {
				return jobId+"-"+grade;
			}
		}
		
		public static String seperateValuesFromKey(String key,String term) throws Exception {
			Map<String, String> valueMap  = new HashMap<String, String>();
			if(StringUtils.isBlank(key)) {
				throw new Exception("No key found to process the job detailes");
			}else {
				List<String> listOfValues = new ArrayList<String>(Arrays.asList(key.split("\\^\\^")));
				for(String value: listOfValues) {
					valueMap.put(StringUtils.substringBefore(value, ":"), StringUtils.substringAfter(value, ":"));
				}
				return valueMap.get(term);
			}
		}

		public static String formatStringAsNumberedLinesInHTML(String clientSpecificInstructions) {
			if(StringUtils.isNotBlank(clientSpecificInstructions))
			{
				StringBuffer sb = new StringBuffer("<ol>");
				for (String line : clientSpecificInstructions.split("\n"))
				{
					if(StringUtils.isNotBlank(line))
					{
						sb.append("<li>").append(line).append("</li>");
					}
				}
				sb.append("</ol>");
				clientSpecificInstructions = sb.toString();
			}
			return clientSpecificInstructions;
		}
		
		public static String generateStrongPassword(int length) {
			String capitalCaseLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
			String lowerCaseLetters = "abcdefghijklmnopqrstuvwxyz";
			String specialCharacters = "#";
			String numbers = "1234567890";
			String combinedChars = capitalCaseLetters + lowerCaseLetters + specialCharacters + numbers;
			Random random = new Random();
			char[] password = new char[length];

			password[0] = lowerCaseLetters.charAt(random.nextInt(lowerCaseLetters.length()));
			password[1] = capitalCaseLetters.charAt(random.nextInt(capitalCaseLetters.length()));
			password[2] = specialCharacters.charAt(random.nextInt(specialCharacters.length()));
			password[3] = numbers.charAt(random.nextInt(numbers.length()));

			for (int i = 4; i < length; i++) {
				password[i] = combinedChars.charAt(random.nextInt(combinedChars.length()));
			}
			return new String(password);
		}
		
	
	public static Long getTimeStampOfSignature(String value)
	{
		long timeStamp = 0L;
		if(value!=null && StringUtils.containsIgnoreCase(value, "timestamp"))
		{
			String timestampToken = StringUtils.split(value,"^^")[0];
			String timestampStr = StringUtils.split(timestampToken, ":")[1];
			if(timestampStr!=null && StringUtils.isNumeric(timestampStr))
			{
				timeStamp = Long.valueOf(timestampStr);
			}
			
		}
		return timeStamp;
	}
	
	public static boolean checkAuthorization(User user, String[] permitedRoles) {
		for (UserRole role : user.getRoles()) {
			if(Arrays.asList(permitedRoles).contains(role.getRole()) ) {
				return true;
			}
		}
		return false;
	}
	
	public static String dateFormat(String date) throws ParseException {
		String outputText ="";
		try {
			DateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			//DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			if(date == null || date.isEmpty()) {
				LocalDateTime ldt = LocalDateTime.now();
				date =ldt.toString();
			}
			DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			Date dateFormat = inputFormat.parse(date);
			outputText = outputFormat.format(dateFormat);
		}catch(Exception ex) {
			throw ex;
		}
		return outputText;
		
	}
	
}	   

