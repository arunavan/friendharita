package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.india.bts.dib.domain.BunkerLoadingToIbms;

public interface BunkerLoadingToIbmsRepository extends JpaRepository<BunkerLoadingToIbms,Long>{

}
