package com.india.bts.dib.dto;

import java.util.List;

import com.india.bts.dib.domain.BargeMfmSealChecklist;

import lombok.Data;


@Data
public class BargeMfmSealChecklistDTO {
	
	private List<BargeMfmSealChecklist> sealsChecklist;
	
	private Long bargeId;


}
