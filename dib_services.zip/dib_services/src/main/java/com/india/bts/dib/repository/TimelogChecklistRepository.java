package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.india.bts.dib.domain.TimelogData;

public interface TimelogChecklistRepository extends JpaRepository<TimelogData, Long> {
	
	TimelogData findByJobId(long jobId);
	

	@Modifying
	@Transactional
	@Query(value="UPDATE timelog_data SET timelog_file_binary= :timelog_file_binary WHERE job_id = :jobId ", nativeQuery=true)
	void updateBinaryData(@Param("timelog_file_binary") String timelog_file_binary,@Param("jobId") Long jobId);
}
