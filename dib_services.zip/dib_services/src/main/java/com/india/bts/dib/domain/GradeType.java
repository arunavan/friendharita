package com.india.bts.dib.domain;

public enum GradeType {
	
	NOMINATED_GRADE,
	SUPPLYING_GRADE,
	RECEIVING_GRADE

}
