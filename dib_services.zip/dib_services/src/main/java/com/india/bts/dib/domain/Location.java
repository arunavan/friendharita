/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _______________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@NoArgsConstructor 
@Entity(name="location")
public class Location implements Serializable {


	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name="code", length=50)
	@NotBlank
	private String code;
	
	@Column(nullable=false, name="name", unique=true, length=500)
	@NotBlank
	private String name;

	@Column(name="latitude", nullable = true)
	private String latitude;

	@Column(name="longitude", nullable = true)
	private String longitude;
	
	
	private String displayName ;
	
	public String getDisplayName() {
		return this.code+"-"+this.name;
	}
	
	
	
	
	
	
	
}
