/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _________________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.security;


import static com.india.bts.dib.security.SecurityConstants.HEADER_STRING;
import static com.india.bts.dib.security.SecurityConstants.SECRET;
import static com.india.bts.dib.security.SecurityConstants.TOKEN_PREFIX;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.india.bts.dib.domain.ErrorResponse;
import com.india.bts.dib.utils.Constants;

import io.jsonwebtoken.Jwts;

public class JWTAuthorizationFilter extends BasicAuthenticationFilter {


    public JWTAuthorizationFilter(AuthenticationManager authManager) {
        super(authManager);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req,
                                    HttpServletResponse res,
                                    FilterChain chain) throws IOException, ServletException {
    	
        String header = req.getHeader(HEADER_STRING);

        if (header == null || !header.startsWith(TOKEN_PREFIX)) {
            	chain.doFilter(req, res);
        	return;
        }

        UsernamePasswordAuthenticationToken authentication = getAuthentication(req);
        
        SecurityContextHolder.getContext().setAuthentication(authentication);
        try {
        	chain.doFilter(req, res);
        }catch(Exception e) {
        	 ErrorResponse errorResponse = new ErrorResponse();
             errorResponse.setCode(200);
             Throwable cause = e.getCause();
             errorResponse.setMessage(cause.getMessage());
             byte[] responseToSend = restResponseBytes(errorResponse);
             ((HttpServletResponse) res).setHeader("Content-Type", "application/json");
             res.getOutputStream().write(responseToSend);
             return;
        }
    }

    private byte[] restResponseBytes(ErrorResponse eErrorResponse) throws IOException {
    	String serialized = new ObjectMapper().writeValueAsString(eErrorResponse);
        return serialized.getBytes();
    }
    private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
        String token = request.getHeader(HEADER_STRING);
        if (token != null) {
            // parse the token.
            String user = Jwts.parser()
                    .setSigningKey(SECRET.getBytes())
                    .parseClaimsJws(token.replace(TOKEN_PREFIX, ""))
                    .getBody()
                    .getSubject();
            /*If Developer request with developer Token in Headers
             * To validate user in requested static token we are injecting user as bts_developer@bts.com (DEVELOPER ACCOUNT).
			*/
            if(token.equals(Constants.DEVELOPER_TOKEN)) {
            	user = Constants.DEVELOPER_NAME_FOR_TOKEN;
            }
            if (user != null) {
                return new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>());
            }
            return null;
        }
        return null;
    }
}
