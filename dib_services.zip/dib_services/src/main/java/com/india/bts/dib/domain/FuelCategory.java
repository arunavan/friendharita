package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Entity (name = "fuel_category") 
@Data
public class FuelCategory implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Fuel_CategoryId")
	private Long fuelCategoryId;
	
	@Column(name="Fuel_CategoryCode")
	private String fuelCategoryCode;
	
	@Column(name="Fuel_CategoryName")
	private String fuelCategoryName;
	
	@Column(name="Created_By")
	private String createdBy;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
	@Column(name="Created_Date")
	private LocalDateTime createdDate;
	
}
