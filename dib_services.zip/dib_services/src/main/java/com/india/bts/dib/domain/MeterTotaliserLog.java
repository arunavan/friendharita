package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data 
@NoArgsConstructor 
@Entity(name="meter_totaliser_logs")
public class MeterTotaliserLog implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1656171573374594648L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name="barge_id", length=50)
	private Long bargeId;

	
	@Column(nullable=false, name="job_id", length=50)
	private Long jobId;
	
	@ApiModelProperty(notes = "specify the jobtype", required = true, example = "Loading, Delivery, ShipToShip")
	@Column(nullable=false,name="job_type",length=50)
	@Enumerated(EnumType.STRING)
    private JOBTYPE jobType;
	

	@ApiModelProperty(notes ="formate:yyyy-MM-dd", required = true, example = "2022-05-25")
    @JsonFormat(pattern="yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd") 
	@Column(name="log_date_time", columnDefinition = "DATE")
	LocalDate logDateTime;
	
	@Column(nullable=false, name="product", length=50)
	private String product;
	
	@Column(nullable=false, name="terminal", length=50)
	private String terminal;
	
	@Column(nullable=false, name="bmt_no", length=50)
	private String bmtNo;
	
	@Column(nullable=false, name="bdn_no", length=50)
	private String bdnNo;
	
	@Column(nullable=true, name="loading_start_reading", length=50)
	private String loadingStartReading;
	
	@Column(nullable=true, name="loading_end_reading", length=50)
	private String loadingEndReading;
	
	@Column(nullable=true, name="delivery_start_reading", length=50)
	private String deliveryStartReading;
	
	@Column(nullable=true, name="delivery_end_reading", length=50)
	private String deliveryEndReading;
	
	@Column(nullable=true, name="meter_qty", length=50)
	private String meterQty;
	
	@Column(nullable=true, name="tank_sequence", length=50)
	private String tankSequence;
	
	@Column(nullable=false, name="cargo_officer_name", length=50)
	private String cargoOfficerName;
	
	@Column(nullable=true, name="remarks", length=2500)
	private String remarks;
	
	@Column(nullable=true, name="backflow", length=2500)
	private String backFlow;
}
