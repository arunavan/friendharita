package com.india.bts.dib.domain;

public enum TaskType {
	
	SEND_EMAIL_FOR_VESSEL_LOGIN,
	SEND_EMAIL_FOR_SURVEYOR_LOGIN,
}

