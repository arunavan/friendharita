package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="purchase_order") 
public class PurchaseOrder implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5560551267188712809L;
	
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Long id;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(nullable = true, name = "nomination_date_time", columnDefinition="DATETIME")
    LocalDateTime nominationDateTime;
	
	@ApiModelProperty(notes = "Purchase order number", required = true )
	@Column(nullable=true,name="purchase_order_no",length=500)
    private String purchaseOrderNumber;


	@Column(nullable=true,name="nomination_no",length=500)
    private String nominationNumber;
	
	@Column(nullable=true,name="barge_name",length=500)
    private String bargeName;
	@Column(nullable=true,name="barge_licence_no",length=500)
    private String bargeLicenceNo;
	@Column(nullable=true,name="barge_pumping_rae",length=500)
    private String bargePumpingRate;
	
	
	@Column(nullable=true,name="terminal_berth_anchorage",length=500)
    private String terminalOrBerthOrAnchorage;
	
	@Column(nullable=true,name="cargo_owner",length=500)
    private String cargoOwner;
	
//	@JsonManagedReference
//	@OneToMany(mappedBy="job",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
//	private List<Nomination> nominations;
	
	
//	@JsonIgnore
//	@OneToOne(mappedBy = "purchaseOrder")
//	@MapsId
//    private Job job;

}
