/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _______________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.utils;

import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;

public class Constants {
	
	public static final String VERSION = "/api/v1";

	public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	
	public static final String DEVELOPER_NAME_FOR_TOKEN = "bts_developer@bts.com";
	
	public static final String DEVELOPER_TOKEN = "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZXN0QGlicW1zLmNvbSIsImV4cCI6MTYxMjcwNDQ4Mn0.vYoU8kz3l2itui3FJ1KDjyw95D5nMfAeuMtXOudRJrI5k5VXY7JWeKOZhDL7XrRpeJ7Tq7_mcPpSYHB_rwR6Ew";

	public static final Gson GSON = new Gson();

	public static final String EMAIL_FROM_EMAIL_ID = "support@btsol.biz";

//	public static final String CC_EMAIL_ID = "khgoh@btsol.biz,sree@btsol.biz";
//	
//	public static final String BCC_EMAIL_ID = "bhaskar.vivin@gmail.com";
	
	public static final String CC_EMAIL_ID = "";
	
	public static final String BCC_EMAIL_ID = "";
	
	public static final String VESSEL_CE_LOGIN_EMAIL_TEMPLATE = "VESSEL_CE_LOGIN_EMAIL_TEMPLATE";

	public static final String SURVEYOR_LOGIN_EMAIL_TEMPLATE = "SURVEYOR_LOGIN_EMAIL_TEMPLATE";
	
	public static final String CONTIGENCY_EMAIL_TEMPLATE = "CONTIGENCY_EMAIL_TEMPLATE";
	
	public static final String SURVEY_JOB_STATUS_UPDATE_TEMPLATE = "SURVEY_JOB_STATUS_UPDATE";
	
	public static final String ADMIN_EMAIL_NOTIFY_FOR_CORRECTION = "ADMIN_EMAIL_NOTIFY_FOR_CORRECTION";
	
	public static final String DEVELOPER_EMAIL_TEMPLATE = "DEVELOPER_EMAIL_TEMPLATE";
	
	public static final String APP_URL="https://dib-demo.web.app/";
	public static final String APP_URL_QA="https://qa-ebdn.web.app/";
	//public static final String APP_URL_PROD ="https://ebdn.digitalbunkering.app/";
	public static final String APP_URL_PROD ="https://gid.digitalbunkering.app/";

	public static final String IN_CHARGE = "IN_CHARGE";
	
	public static final String GRADES_DETAILS_HOLDER_STRING = "<tr><td style=\"border: 1px solid #4472c5;padding: 10px\">@GRADE@</td><td style=\"border: 1px solid #4472c5;padding: 10px\">@QUANTITY@</td><td style=\"border: 1px solid #4472c5;padding: 10px\">@UOM@</td><td style=\\\\\\\"border: 1px solid #4472c5;padding: 10px\\\\\\\">@SUPPLIER-NAME@</td><td style=\\\"border: 1px solid #4472c5;padding: 10px\\\">@SUPPLIER-PHONE@</td><td style=\\\"border: 1px solid #4472c5;padding: 10px\\\">@SUPPLIER-EMAIL@</td></tr>";

	public static final String NO_EMAIL_ID_MSG = "EMAIL ID NOT AVAILABLE, PLEASE ADD EMAIL ID";
	
	public static final String N_A = "N/A";

	public static final String CUSTOMER = "Customer";
	
	public static String Environment = "";
	public static final List<String> ROLES = Arrays.asList("ADMIN","SURVEYOR","WORKING_SURVEYOR");
	
////	OCR  FREE Version Keys
//	public static final String OCR_API_URL= "https://api.ocr.space/parse/image";
//	public static final String OCR_API_KEY = "K86036871988957";

//	OCR  Paid Version Keys
	public static final String OCR_API_URL= "http://apipro3.ocr.space/parse/image";
	public static final String OCR_API_KEY = "GPR8HV5ULMVEX";
	//public static final String OCR_API_KEY = "PR85KYFW9NNX";
	public static final String OCR_IS_OVERLAY_REQUIRED="true";
	public static final String OCR_ENGINE="2";
	
	public static final String MPA_PUBLISHER_URL= "http://localhost:51782/mpa-publisher/run";
	public static final String MPA_PUBLISHER_URL_NEW= "http://localhost:51782/mpa-publisher-new/run";
	public static final String MPA_BLOCKCHAIN_URL= "http://localhost:51782/blockchain_registration/run";
	public static final String JSON_ATTACHMENT= "http://localhost:51782/json/attachment";
	public static final String MPA_VESSEL_GST_URL= "http://localhost:51782/vessel/gst";
	public static final String MPA_VESSEL_DATA= "https://api-msw-stg.mpa.gov.sg/digitalbunker/v1.0/receivingvessel/search";
	public static final String MPA_VESSEL_TOKEN= "https://api-msw-stg.mpa.gov.sg/token";
	public static final String TEST_API= "http://localhost:8080/api/v1/getJobDat";
	public static final String SGTradex_URL ="https://bts.pitstop.uat.sgtradex.io/api/v1/data/push/";
	public static final String SGTradex_TOKEN ="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImNhYjZlMTJhLWU0M2QtNDA0OC1iMWQwLWI0NDJiOTVkZjA1YiIsImF1ZCI6IiIsImlzcyI6IiIsInN1YiI6IiIsImlhdCI6MTY5MTM5NTY5MCwianRpIjoiMjBjZTEwNTgtNjQ4MS00NjA5LThkZTYtNmI0ZjUyMzcyN2U1IiwiZXhwIjoxNjkxMzk2NTkwfQ.sbJ9zNe8WTIGOs1E_XPKoQB_Y37Qcon_yyGTAUtFS4w";
	public static final String BDN_DELIVERY_NOTE_TO_SGTradex ="bunker_delivery_report";
	public static final String VendorUen ="200411078D";
	public static final String ON_BEHALF_OF ="848a81a3-7d00-4390-b604-a2ca6251ecc8";
	public static final String PARTICIPANT_ID="1817878d-c468-411b-8fe1-698eca7170dd";
	public static final String PARTICIPANT_NAME ="MARITIME AND PORT AUTHORITY OF SINGAPORE";
	
	//Transaction Id's for ALL forms
	public static final int transactionId_Req=1;
	public static final int transactionId_Safety=2;
	public static final int transactionId_Seals=3;
	public static final int transactionId_mfm=4;
	public static final int transactionId_meterTicket=5;
	public static final int transactionId_bdn=6;
	public static final int transactionId_nop=7;
	public static final int transactionId_timelog=8;
	public static final int transactionId_sof=9;
	
	// Module Id's for ALL Jobs
	public static final int moduleId_Delivery=1;
	public static final int moduleId_Loading=2;
	public static final int moduleId_Transfer_in=3;
	public static final int moduleId_Transfer_out=4;

	public static final String SHIPPING_INSTRUCTIONS = "	Send one sample to LAB for testing: (for ports outside of LA/LGB and Oak)<br>\r\n" + 
			"	Courier: FedEx<br>\r\n" + 
			"	Bill to Account #: 1325-0095-9<br>\r\n" + 
			"	Service Type: FedEx2Day- When shipping withing the US<br>\r\n" + 
			"	Fedex international Economy- When shipping from OUTSIDE the US<br>\r\n" + 
			"	Send to:      Los Angeles Bunker Surveyors, Inc.<br>\r\n" + 
			"	214 N. Marine Ave.<br>\r\n" + 
			"	Wilmington, CA 90744<br>\r\n" + 
			"	<b>*** Note:</b> Please note the above shipping instruction is the ONLY authorized shipping option using the account number. If any other shipping option must be used, it must be made with LAB's authorization. Any extra cost incurred due to an unauthorized shipment on LAB's account will either be forwarded to Sender's company or deducted from Survey Fee. ***<br>\r\n" + 
			"";
	
}
