package com.india.bts.dib.domain.ocr;

import lombok.Data;
@Data
public class ParsedResult {

public TextOverlay TextOverlay;
public String TextOrientation;
public Integer FileParseExitCode;
public String ParsedText;
public String ErrorMessage;
public String ErrorDetails;

}
