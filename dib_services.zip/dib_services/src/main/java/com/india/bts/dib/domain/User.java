/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _________________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.india.bts.dib.dto.UserDTO;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "user")
@Data
@NoArgsConstructor
public class User implements Serializable {

	private static final long serialVersionUID = -3176829993451842829L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull
	@Size(min = 2, max = 255, message = "Firstname is not empty (or) Wrong format")
	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "phone_number")
	private String phoneNumber;

	@NotNull
	@Size(min = 3, max = 250, message = "Email is not empty (or) Wrong format")
	@Column(name = "email", unique = true)
	private String email;

	@NotNull
	@Size(min = 6, max = 255, message = "Password should have minimun 8 characters")
	@Column(name = "password", length = 1024)
	private String password;

	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
	@JoinTable(name = "user_role", joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"))
	private Set<UserRole> roles = new HashSet<>();
	
	@Column(nullable = true, name = "barge_id")
	private Long bargeId;

	@CreatedDate
	@Column(nullable = false, name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false, name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;

	@Column(nullable = true, name = "updatedUser", length = 500)
	private String updatedUser;

	@Column(nullable = false, name = "account_enabled", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean accountEnabled;

	@Column(nullable = false, name = "account_expired", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean accountExpired;

	@Column(nullable = false, name = "account_locked", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean accountLocked;

	@Column(nullable = false, name = "required_reset_password", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean requiredToResetPassword;

	private String role;
	
	@Transient
	@JsonIgnore
	private String plainPassword;

	public User(Long id) {
		this.id = id;
	}

	public User(String string, int i) {

	}

	public User(UserDTO dto, User currentUser) {

		this.id = dto.getId();
		this.accountEnabled = dto.isAccountEnabled();
		this.accountExpired = dto.isAccountExpired();
		this.accountLocked = dto.isAccountLocked();
		this.createdDate = DateTime.now();
		this.email = dto.getEmail();
		this.firstName = dto.getFirstName();
		this.lastName = dto.getLastName();
		this.password = dto.getPassword();
		this.phoneNumber = dto.getPhoneNumber();
		this.bargeId = dto.getBargeId();
		this.roles = dto.getRoles();
		this.updatedDate = DateTime.now();
		this.requiredToResetPassword = dto.isRequiredToResetPassword();
	}

	public String getCreatedDateTime() {
		if (createdDate == null)
			return null;
		else
			return createdDate.toString("yyyy-MM-dd HH:mm:ss");
	}

	public String getUpdatedDateTime() {
		if (updatedDate == null)
			return null;
		else
			return updatedDate.toString("yyyy-MM-dd HH:mm:ss");
	}

	public String getRole() {
		if (this.roles != null && this.roles.size() > 0) {
			this.role = this.roles.iterator().next().getRole();
		}

		return this.role;
	}
	
	
}
