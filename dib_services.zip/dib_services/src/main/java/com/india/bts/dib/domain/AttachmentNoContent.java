package com.india.bts.dib.domain;

public interface AttachmentNoContent {
	
	Long getId();
	Long getJobId();
	String getJobType();
	String getWorkflow();
	String getFileName();

}
