package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.india.bts.dib.domain.MFMSealsChecklistData;

public interface MFMSealsChecklistRepository extends JpaRepository<MFMSealsChecklistData, Long> {
	
	MFMSealsChecklistData findByJobId(long jobId);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE mfm_seals_checklist_data SET seal_file_binary=:seal_file_binary WHERE job_id = :jobId ", nativeQuery=true)
	void updateBinaryData(@Param("seal_file_binary") String seal_file_binary,@Param("jobId") Long jobId);
}
