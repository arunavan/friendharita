package com.india.bts.dib.domain;

import lombok.Data;

@Data
public class FilesData {
	private String fileName;
	private String fileContent;

}
