package com.india.bts.dib.dto;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class PurchaseOrderDTO {

	@ApiModelProperty(notes = "formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	LocalDateTime nominationDateTime;

	@ApiModelProperty(notes = "Purchase order number", required = true)
	private String purchaseOrderNo;
	private String nominationNo;

	private Long bargeId;
	private String bargeName;
	private String bargeLicenceNo;
	private String bargePumpingRate;

	@ApiModelProperty(notes = "Bunkering operation type", required = true)
	private String operationType;

	private String terminal;
	private String cargoOwner;

	private Long bdnPartyId;
	private String bdnPartyName;

	private String surveyor;
	private String surveyorEmail;

	private List<NominationDTO> nominations;
	
	private int is_Updated;
	private String sourceType;
	
}
