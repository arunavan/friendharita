	package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="mfm_reading_data") 
public class MFMReadingData implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6360097131484204214L;
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(nullable=false, name = "job_id", length=20)
	private long jobId;
	@Column(nullable=true, name = "bunker_sb_number", length=200)
	private String bunkerSBNumber;
	@Column(nullable=true, name = "bunker_tanker_name", length=200)
	private String bunkerTankerName;
	@Column(nullable=true, name = "vessel_name", length=200)
	private String vesselName;
	@Column(nullable=true, name = "meter_serial_number", length=200)
	private String meterSerialNumber;
	@Column(nullable=true, name = "bdn_number", length=200)
	private String bdnNumber;
	@Column(nullable=true, name = "bmt_number", length=200)
	private String bmtNumber;
	@Column(nullable=true, name = "delivery_totaliser_reading_a", length=20)
	private String deliveryTotaliserReadingA;
	@Column(nullable=true, name = "loading_totaliser_reading_x", length=20)
	private String loadingTotaliserReadingX;
	@Column(nullable=true, name = "delivery_totaliser_reading_b", length=20)
	private String deliveryTotaliserReadingB;
	@Column(nullable=true, name = "loading_totaliser_reading_y", length=20)
	private String loadingTotaliserReadingY;
	@Column(nullable=true, name = "quantity_supplied", length=50)
	private String quantitySupplied;
	
	@Column(nullable=true, name = "sampling_container_seal_number", length=50)
	private String samplingContainerSealNumber;
	@Column(nullable=true, name = "needle_valve_seal_number", length=50)
	private String needleValveSealNumber;

	@Column(nullable=true, name = "vessel_has_space_for_line_clearing", length=1)
	private boolean vesselHasSpaceForLineClearing;

	@Column(nullable=true, name = "remarks_before_operation", columnDefinition = "TEXT")
	private String remarksBeforeOperation;
	@Column(nullable=true, name = "remarks_after_operation", columnDefinition = "TEXT")
	private String remarksAfterOperation;


	@Column(nullable=true, name = "cargo_officer_name_before_operation", length=200)
	private String cargoOfficerNameBeforeOperation;
	@Column(nullable=true, name = "chief_enineer_name_before_operation", length=200)
	private String chiefEngineerNameBeforeOperation;
	@Column(nullable=true, name = "surveyor_name_before_operation", length=200)
	private String surveyorNameBeforeOperation;
	
	@Column(nullable=true, name = "cargo_officer_name_after_operation", length=200)
	private String cargoOfficerNameAfterOperation;
	@Column(nullable=true, name = "chief_enineer_name_after_operation", length=200)
	private String chiefEngineerNameAfterOperation;
	@Column(nullable=true, name = "surveyor_name_after_operation", length=200)
	private String surveyorNameAfterOperation;

	@Column(nullable=true, name = "opening_reading", length=200)
	private String openingReading;
	@Column(nullable=true, name = "closing_reading", length=200)
	private String closingReading;


	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "hose_connected_time", columnDefinition="DATETIME", nullable = true)
    LocalDateTime choseConnectedTime;

	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "pumping_stop_time", columnDefinition="DATETIME", nullable = true)
    LocalDateTime pumpingStopTime;

	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "hose_disconnected_time", columnDefinition="DATETIME", nullable = true)
    LocalDateTime hoseDisconnectedTime;

	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "commenced_pumping_start", columnDefinition="DATETIME", nullable = true)
    LocalDateTime commencedPumpingStart;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "commenced_pumping_stop", columnDefinition="DATETIME", nullable = true)
    LocalDateTime commencedPumpingStop;
//
//	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
//    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
//    @Column(name = "cargo_officer_signature_date_time_bo", columnDefinition="DATETIME", nullable = true)
//    LocalDateTime cargoOfficerSignatureDateTimeBeforeOperation;
//	
//	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
//    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
//    @Column(name = "chief_engineer_signature_date_time_bo", columnDefinition="DATETIME", nullable = true)
//    LocalDateTime chiefEngineerSignatureDateTimeBeforeOperation;
//	
//	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
//    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
//    @Column(name = "surveyor_signature_date_time_bo", columnDefinition="DATETIME", nullable = true)
//    LocalDateTime surveyorSignatureDateTimeBeforeOperation;
//
//
//	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
//    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
//    @Column(name = "cargo_officer_signature_date_time_ao", columnDefinition="DATETIME", nullable = true)
//    LocalDateTime cargoOfficerSignatureDateTimeAfterOperation;
//	
//	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
//    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
//    @Column(name = "chief_engineer_signature_date_time_ao", columnDefinition="DATETIME", nullable = true)
//    LocalDateTime chiefEngineerSignatureDateTimeAfterOperation;
//	
//	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
//    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
//    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
//    @Column(name = "surveyor_signature_date_time_ao", columnDefinition="DATETIME", nullable = true)
//    LocalDateTime surveyorSignatureDateTimeAfterOperation;

	@Column(nullable=true, name = "co_pre_sign_datetime", length=200)
	private String coPreSignDateTime;
	@Column(nullable=true, name = "co_post_sign_datetime", length=200)
	private String coPostSignDateTime;
	@Column(nullable=true, name = "ce_pre_sign_datetime", length=200)
	private String cePreSignDateTime;
	@Column(nullable=true, name = "ce_post_sign_datetime", length=200)
	private String cePostSignDateTime;
	@Column(nullable=true, name = "sur_pre_sign_datetime", length=200)
	private String surPreSignDateTime;
	@Column(nullable=true, name = "sur_post_sign_datetime", length=200)
	private String surPostSignDateTime;
	
	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	@Lob
	@Column(nullable=true,name="mfm_file_binary")
	private String mfmFileBinary;
	@Lob
	@Column(nullable=true,name="Pre_CO_Sign")
	private String preCOSign;
	@Lob
	@Column(nullable=true,name="Pre_CE_Sign")
	private String preCESign;
	@Lob
	@Column(nullable=true,name="Pre_SV_Sign")
	private String preSVSign;
	@Lob
	@Column(nullable=true,name="Post_SV_Sign")
	private String postSVSign;
	@Lob
	@Column(nullable=true,name="Post_CO_Sign")
	private String postCOSign;
	@Lob
	@Column(nullable=true,name="Post_CE_Sign")
	private String postCESign;

}
