package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@NoArgsConstructor 
@Entity(name = "bdn_parties")
public class BDNParty implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable=false, name = "company_name", unique=true, length=500)
	private String companyName;

	@Column(nullable=false, name = "bunker_supplier_lic_no",unique=true, length=500)
	private String bunkerSupplierLicNumber;
	
	@Column(nullable=false, name = "registration_no", length=500)
	private String registrationNumber;
	
	@Column(nullable = true, name = "is_default", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean itDefault;
	
	@Column(nullable=true, name = "address_one", length=2000)
	private String addressOne;
	
	@Column(nullable=true, name = "address_two", length=2000)
	private String addressTwo;
	
	@Column(nullable=true, name = "footer_text", length=2000)
	private String footerText;
	
	@Lob
	@Column(name="header_logo")
	private String headerLogo;
	
	@Lob
	@Column(name="footer_logo")
	private String footerLogo;
	
	@Column(nullable = true, name = "use_logos", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean useLogos;
	
	@Column(nullable = true, name = "chatereremail")
	private String chatererEmail;
	

//	FOR TIME BEING MOVING THESE TO BARGE AS IT SEEMS TO BE MORE RELEVANT TO HOLD THIS DATA BUT IN FUTURE IT MAY CHANGE BASED ON THE WORKFLOW AND CUSTOMER CONFIG.
//	@Column(name = "sgtradex_id")
//	private String sgTradexId;
//	
//	@Column(name = "sgtradex_name")
//	private String sgTradexName;
//	
//	@Column(name = "sgtradex_data_ref_id")
//	private String sgTradexDataRefId;
//	
//	@Column(name = "sgtradex_vendor_uen")
//	private String sgTradexVendorUEN;
//
//	@Column(name = "sgtradex_on_behalf_of_id")
//	private String sgTradexOnBehalfId;
	
}
