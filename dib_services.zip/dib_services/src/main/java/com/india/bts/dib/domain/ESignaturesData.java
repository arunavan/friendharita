package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity(name = "esignatures_data")
public class ESignaturesData implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20)
	private long jobId;
	
	@Lob
//	@Column(name="esignature", nullable=false, columnDefinition = "TEXT")
	private String esignature;

	
	@CreatedDate
	@Column(nullable=true, name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable=true, name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true, name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true, name = "updated_by", length=500)
	private String updatedUser;

  
}
