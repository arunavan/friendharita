package com.india.bts.dib.domain.ocr;

import java.util.List;

import lombok.Data;

@Data
public class Ocr {

public List<ParsedResult> ParsedResults;
public Integer OCRExitCode;
public Boolean IsErroredOnProcessing;
public String ProcessingTimeInMilliseconds;
public String SearchablePDFURL;

@Override
public String toString() {
	return "Ocr [ParsedResults=" + ParsedResults + ", OCRExitCode=" + OCRExitCode + ", IsErroredOnProcessing="
			+ IsErroredOnProcessing + ", ProcessingTimeInMilliseconds=" + ProcessingTimeInMilliseconds
			+ ", SearchablePDFURL=" + SearchablePDFURL + "]";
}



}