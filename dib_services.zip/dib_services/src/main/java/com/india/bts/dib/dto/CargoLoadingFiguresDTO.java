package com.india.bts.dib.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class CargoLoadingFiguresDTO {
	
    private BigDecimal loadedQty;
    private BigDecimal kiloLiters;
    private BigDecimal usBarrels; 
    private BigDecimal longTons;
    private BigDecimal mfmAQty;
    private BigDecimal bargeSoundingQty;
    private BigDecimal viscosity;
    private BigDecimal coqDensity;
    private BigDecimal waterContent;
    private BigDecimal flashPoint;
    private BigDecimal sulphurContent;
    private BigDecimal hydrogenSulfide;
    private BigDecimal totalAcidNumber;
    private BigDecimal pourPoint;
    private BigDecimal calculateCetaneIndex;
    private BigDecimal microCarbonResidue;
    private BigDecimal ash;
    private BigDecimal appearance;
    private BigDecimal oxidationStability;
    private BigDecimal lubricity;
    private String remarks;

}
