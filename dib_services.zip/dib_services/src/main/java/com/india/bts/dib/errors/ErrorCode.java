package com.india.bts.dib.errors;

public enum  ErrorCode {

    IBQMS001,
    IBQMS002,
    IBQMS003
}
