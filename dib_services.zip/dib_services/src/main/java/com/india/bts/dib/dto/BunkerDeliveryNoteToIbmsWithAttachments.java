package com.india.bts.dib.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import javax.persistence.Column;

import com.india.bts.dib.domain.BunkerDeliveryNoteToIbms;
import com.india.bts.dib.domain.FilesData;

import lombok.Data;

@Data
public class BunkerDeliveryNoteToIbmsWithAttachments implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String bunkerTankerLicenceNo;
	private String bunkerTankerName; 
	private String bunkerMeteringTicketNo;
	private String fuelTypeCode;
	private int refItemNo;
//	private String startDeliveryMeterTotaliser;
//	private String startLoadingMeterTotaliser;
//	private String endDeliveryMeterTotaliser;
//	private String endLoadingMeterTotaliser;
	private String operationDate;
	private String totalisersAutoPopulated;
	private String reasonNotAutoPopulated;
	private String bunkerSupplierName;
	private String bunkerSupplierUEN;
	private String bdnNo;
	private String receiveVesselName;
	private String receiveVesselImoNo;
	private String receiveVesselGst;
	private String deliveryLocationCode;
	private String deliveryLocationName;
	private String deliveryType;
	private String supplyType;
	private String temperature;
//	private String suppliedQuantityMFM;
	private String suppliedQuantityBDN;
	private String commencePumpingTime;
	private String completePumpingTime;
	private String alongsideTime;
//	private String castOffTime;
	private String durationOfDelivery;
	private String customerRating;
	private String protestNote;
	private String density;
	private String flashPoint;
	private String sulpherContent;
	private String viscosity;
	private String waterContent;
	private String cargoOfficerName;
	
	
	private String labSeal;
	private String labCounterSeal;
	private String labCounterSeal2;
	
	private String vesselSeal;
	private String vesselCounterSeal;
	private String vesselCounterSeal2;
	
	
	private String marpolSeal;
	private String marpolCounterSeal;
	private String marpolCounterSeal2;
	
	
	private String bunkerSeal;
	private String bunkerCounterSeal;
	private String bunkerCounterSeal2;
	
	private String surveyorSeal;
	private String surveyorCounterSeal;
	private String surveyorCounterSeal2;
	private String stemNo;
	
	private List<FilesData> attachments ;
	
	
}
