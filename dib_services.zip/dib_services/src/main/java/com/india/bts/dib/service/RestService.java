package com.india.bts.dib.service;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.india.bts.dib.controller.UtilsController;
import com.india.bts.dib.domain.ocr.Line;
import com.india.bts.dib.domain.ocr.Ocr;
import com.india.bts.dib.dto.BunkerDeliveryReportDTO;
import com.india.bts.dib.repository.JobRepository;
import com.india.bts.dib.utils.Constants;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Service
@Slf4j
public class RestService {
	
	@Autowired
	JobRepository jobRepository;
	
	@Value("${mpa.Token}")
	private String token;
	@Value("${cron}")
	private String cron;
	
    private OkHttpClient httpClient = new OkHttpClient();

    public Map<String, String> getOCRText(String data) {
    	
    	
   
    
	    String base64Image = "data:image/jpeg;base64,"+data;

        RequestBody formBody = new FormBody.Builder()
                .add("apikey", Constants.OCR_API_KEY)
                .add("isOverlayRequired", Constants.OCR_IS_OVERLAY_REQUIRED)
                .add("base64Image", base64Image)
                .add("OCREngine", Constants.OCR_ENGINE)
                
                .build();

        Request request = new Request.Builder()
                .url(Constants.OCR_API_URL)
                .addHeader("User-Agent", "API User")
                .post(formBody)
                .build();

        Response response = null;
        String responseStr = null;
        Map<String, String> transformedResponse = null;

        try {
        	OkHttpClient.Builder builder = new OkHttpClient.Builder();
        	builder.connectTimeout(0, TimeUnit.SECONDS); 
        	builder.readTimeout(0, TimeUnit.SECONDS); 
        	builder.writeTimeout(0, TimeUnit.SECONDS); 

        	response = httpClient.newCall(request).execute();
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            responseStr = response.body().string();
            // Get response body
            System.out.println("Response from OCR API:"+responseStr);
            transformedResponse = inspectAndTransformResponse(responseStr);
			
		} catch (Exception e) {
			System.out.println("Error while calling OCR API:"+e.getMessage());
			e.printStackTrace();
		}
        return transformedResponse;

    }
    
    public String runMPAPublisher() {
    	
        Request request = new Request.Builder()
                .url(Constants.MPA_PUBLISHER_URL)
                .addHeader("User-Agent", "API User")
                .get()
                .build();

        Response response = null;
        String responseStr = null;

        try {
        	OkHttpClient.Builder builder = new OkHttpClient.Builder();
        	builder.connectTimeout(0, TimeUnit.SECONDS); 
        	builder.readTimeout(0, TimeUnit.SECONDS); 
        	builder.writeTimeout(0, TimeUnit.SECONDS); 

        	response = httpClient.newCall(request).execute();
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            responseStr = response.body().string();
            // Get response body
            System.out.println("Response from MPA Publisher:"+responseStr);
			
		} catch (Exception e) {
			System.out.println("Error while calling MPA Publisher:"+e.getMessage());
			e.printStackTrace();
		}
        return responseStr;

    }
  
 @Scheduled(cron = "${cron}")
 public void runMPAPublisherSchedular() {
    	
        Request request = new Request.Builder()
                .url(Constants.MPA_PUBLISHER_URL)
                .addHeader("User-Agent", "API User")
                .get()
                .build();

        Response response = null;
        String responseStr = null;

        try {
        	OkHttpClient.Builder builder = new OkHttpClient.Builder();
        	builder.connectTimeout(0, TimeUnit.SECONDS); 
        	builder.readTimeout(0, TimeUnit.SECONDS); 
        	builder.writeTimeout(0, TimeUnit.SECONDS); 

        	response = httpClient.newCall(request).execute();
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            responseStr = response.body().string();
            // Get response body
            System.out.println("Response from MPA Publisher:"+responseStr);
			
		} catch (Exception e) {
			System.out.println("Error while calling MPA Publisher:"+e.getMessage());
			e.printStackTrace();
		}

    }
 public String runMPAPublisherWithJobId(String data) {
	 
	 MediaType JSON = MediaType.parse("application/json; charset=utf-8");
	 	RequestBody body = RequestBody.create(JSON, data);
    	
	 Request request = new Request.Builder()
             .url(Constants.MPA_PUBLISHER_URL_NEW)
             .addHeader("User-Agent", "API User")
             .post(body)
             .build();

        Response response = null;
        String responseStr = null;

        try {
        	OkHttpClient.Builder builder = new OkHttpClient.Builder();
        	builder.connectTimeout(0, TimeUnit.SECONDS); 
        	builder.readTimeout(0, TimeUnit.SECONDS); 
        	builder.writeTimeout(0, TimeUnit.SECONDS); 

        	response = httpClient.newCall(request).execute();
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            responseStr = response.body().string();
            // Get response body
            System.out.println("Response from MPA Publisher:"+responseStr);
			
		} catch (Exception e) {
			System.out.println("Error while calling MPA Publisher:"+e.getMessage());
			e.printStackTrace();
		}
        return responseStr;

    }
 public String blockChainRegistration(String data) {
	 
	 MediaType JSON = MediaType.parse("application/json; charset=utf-8");
 	RequestBody body = RequestBody.create(JSON, data);
 	
    	
        Request request = new Request.Builder()
                .url(Constants.MPA_BLOCKCHAIN_URL)
                .addHeader("User-Agent", "API User")
                .post(body)
                .build();

        Response response = null;
        String responseStr = null;

        try {
        	OkHttpClient.Builder builder = new OkHttpClient.Builder();
        	builder.connectTimeout(0, TimeUnit.SECONDS); 
        	builder.readTimeout(0, TimeUnit.SECONDS); 
        	builder.writeTimeout(0, TimeUnit.SECONDS); 

        	response = httpClient.newCall(request).execute();
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            responseStr = response.body().string();
            // Get response body
            System.out.println("Response from Block chain Publisher:"+responseStr);
			
		} catch (Exception e) {
			System.out.println("Error while calling MPA Block chain Publisher:"+e.getMessage());
			e.printStackTrace();
		}
        return responseStr;

    }


    private Map<String, String> inspectAndTransformResponse(String responseStr)
    {
    	System.out.println("Inspecting OCR data and transforming to MFM format.");
    	Map<String, String> transformedResponse = new HashMap<String, String>();
    	transformedResponse.put("ACTUAL-DATA", "OCR is unable to extract data from the MFM ticket.");
    	if(StringUtils.isNotBlank(responseStr))
    	{
    		Ocr ocrData = Constants.GSON.fromJson(responseStr, Ocr.class);
    		System.out.println("OCR in GSON:"+ocrData);
    		
    		String mfmDeviceType = null;
    		if(!ocrData.getIsErroredOnProcessing())
    		{
    			if(ocrData.getParsedResults()!=null && ocrData.getParsedResults().size()>0)
    			{
    				if(ocrData.getParsedResults().get(0).getTextOverlay()!=null && ocrData.getParsedResults().get(0).getTextOverlay().getLines()!=null && ocrData.getParsedResults().get(0).getTextOverlay().getLines().size()>0)
    				{
    					List<Line> lines = ocrData.getParsedResults().get(0).getTextOverlay().getLines();
    					mfmDeviceType = getMFMDeviceType(lines);
				    	transformedResponse.put("ACTUAL-DATA", ocrData.getParsedResults().get(0).getParsedText());
    					if(StringUtils.equalsIgnoreCase(mfmDeviceType, "EMERSON"))
    					{
    						System.out.println("********** MFM Device type is EMERSON");
    						transformedResponse = getEmersonMFM(lines);
    					}
    					else if(StringUtils.equalsIgnoreCase(mfmDeviceType, "E&H"))
    					{
    						System.out.println("********** MFM Device type is E&H");
    						transformedResponse = getEAndHMFM(lines);
    					}
    					else
    					{
    				    	transformedResponse.put("ACTUAL-DATA", "THE MFM DEVICE VENDOR("+mfmDeviceType+") IS NOT SUPPORTED.");
    					}
    				}
    				else
    				{
                		System.out.println("No lines of text extracted from the OCR");
    				}
    			}
    			else
    			{
            		System.out.println("No results found in the OCR parsed response");
    			}
    		}
    		else
    		{
        		System.out.println("OCR API ran into error while processing the request");
    		}
    	}
    	else
    	{
    		System.out.println("Response from OCR API is "+responseStr);
    	}
    	return transformedResponse;
    }
    
    private String getMFMDeviceType(List<Line> lines)
    {
    	String mfmDeviceType = null;
    	if(lines!=null && lines.size()>0)
    	{
    		if(StringUtils.containsIgnoreCase(lines.get(0).getLineText(), "MICRO") || 
					StringUtils.containsIgnoreCase(lines.get(0).getLineText(), "MOTION") || 
					StringUtils.containsIgnoreCase(lines.get(0).getLineText(), "MOT") || 
					StringUtils.containsIgnoreCase(lines.get(0).getLineText(), "EMERSON") || 
					StringUtils.containsIgnoreCase(lines.get(0).getLineText(), "MERSU"))
    		{
    			mfmDeviceType = "EMERSON";
    		}
    		else
    		{
    			mfmDeviceType = "E&H";
    		}
    	}
    	return mfmDeviceType;
    }
    
    private Map<String, String> getEmersonMFM(List<Line> lines)
    {
    	Map<String, String> emersonEMF = new HashedMap<String, String>();
    	String sbNumber = null;
//    	EXTRACT SB NUMBER
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "SB") || StringUtils.containsIgnoreCase(line.getLineText(), "SO") || StringUtils.containsIgnoreCase(line.getLineText(), "S0"))
    		{
    			sbNumber = line.getLineText();
    			break;
    		}
    	}
    	

//    	EXTRACT MFM Device ID
    	String deviceId = null;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "System ID") || StringUtils.containsIgnoreCase(line.getLineText(), "System"))
    		{
    			deviceId = line.getLineText().toUpperCase();
    			deviceId = StringUtils.replace(deviceId, "SYSTEM ID:", "");
    			deviceId = StringUtils.replace(deviceId, "SYSTEM ID", "");
    			deviceId = StringUtils.replace(deviceId, "SYSTEM", "");
    			break;
    		}
    	}
    	
//    	EXTRACT BTN
    	String btn = null;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "BTN NUMBER") || StringUtils.containsIgnoreCase(line.getLineText(), "BTN") || StringUtils.containsIgnoreCase(line.getLineText(), "BIN"))
    		{
    			btn = line.getLineText().toUpperCase();
    			btn = StringUtils.replace(btn, "BTN NUMBER", "");
    			btn = StringUtils.replace(btn, "BIN NUMBER", "");
    			btn = StringUtils.replace(btn, "NUNBER", "");
    			btn = StringUtils.replace(btn, "BTN", "");
    			btn = StringUtils.replace(btn, "BIN", "");
    			btn = StringUtils.replace(btn, ":", "");
    			break;
    		}
    	}


    	int index = 0;
    	
//    	EXTRACT RESET TIME
    	String resetTime = null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "RESET TIME") || StringUtils.containsIgnoreCase(line.getLineText(), "RESET"))
    		{
    			resetTime = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}
    	
//    	EXTRACT PRINT TIME
    	String printTime = null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "PRINT TIME") || StringUtils.containsIgnoreCase(line.getLineText(), "PRINT"))
    		{
    			printTime = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}
    	
    	
//    	EXTRACT BUNKER BEGIN TIME
    	String bunkerBeginTime = null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "BUNKER BEGIN TIME") || StringUtils.containsIgnoreCase(line.getLineText(), "BEGIN TIME") || StringUtils.containsIgnoreCase(line.getLineText(), "BEGIN"))
    		{
    			bunkerBeginTime = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}
    	
    	

//    	EXTRACT BUNKER END TIME
    	String bunkerEndTime = null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "BUNKER END TIME") || StringUtils.containsIgnoreCase(line.getLineText(), "END TIME") || StringUtils.containsIgnoreCase(line.getLineText(), "END"))
    		{
    			bunkerEndTime = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}
    	

//    	EXTRACT TOTALISER LOADING START
    	String totaliserLoadingStart= null;
    	index = 0;
    	for(Line line : lines)
    	{

    		if(		StringUtils.containsIgnoreCase(line.getLineText(), "BEGIN REV INV AIR") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "BEGIN REV")  
    		  )
    		{
    			totaliserLoadingStart = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}

    	
//    	EXTRACT TOTALISER LOADING END
    	String totaliserLoadingEnd= null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(		StringUtils.containsIgnoreCase(line.getLineText(), "END REV INV AIR") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "END REV") 
    		  )
    		{
    			totaliserLoadingEnd = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}

    	
//    	EXTRACT TOTALISER DELIVERY START
    	String totaliserDeliveryStart= null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(		StringUtils.containsIgnoreCase(line.getLineText(), "BEGIN FWD INV AIR") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "BEGIN FWD")  
    		  )
    		{
    			totaliserDeliveryStart = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}

    	
//    	EXTRACT TOTALISER DELIVERY END
    	String totaliserDeliveryEnd= null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(		StringUtils.containsIgnoreCase(line.getLineText(), "BEGIN FWD INV AIR") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "BEGIN FWD")  
    		  )
    		{
    			totaliserDeliveryEnd = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}

    	
//    	EXTRACT DELIVERED QTY
    	String quantityDelivered= null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(		StringUtils.containsIgnoreCase(line.getLineText(), "MASS IN AIR") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "MASS IN") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "MASS") 
    		  )
    		{
    			quantityDelivered = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}

//    	CLEANUP CHARACTERS AND SPACES FROM READINGS/MEASUREMENTS.
    	totaliserDeliveryStart = Utilities.removeCharsAndSpaces(totaliserDeliveryStart);
    	totaliserDeliveryEnd = Utilities.removeCharsAndSpaces(totaliserDeliveryEnd);
    	totaliserLoadingStart = Utilities.removeCharsAndSpaces(totaliserLoadingStart);
    	totaliserLoadingEnd = Utilities.removeCharsAndSpaces(totaliserLoadingEnd);
    	quantityDelivered = Utilities.removeCharsAndSpaces(quantityDelivered);
    	
    	emersonEMF.put("SB-NUMBER", sbNumber);
    	emersonEMF.put("DEVICE-ID", deviceId);
    	emersonEMF.put("BTN", btn);
    	emersonEMF.put("RESET-TIME", resetTime);
    	emersonEMF.put("PRINT-TIME", printTime);
    	emersonEMF.put("BUNKER-BEGIN-TIME", bunkerBeginTime);
    	emersonEMF.put("BUNKER-END-TIME", bunkerEndTime);
    	emersonEMF.put("TOTALIZER-DELIVERY-START", totaliserDeliveryStart);
    	emersonEMF.put("TOTALIZER-DELIVERY-END", totaliserDeliveryEnd);
    	emersonEMF.put("TOTALIZER-LOADING-START", totaliserLoadingStart);
    	emersonEMF.put("TOTALIZER-LOADING-END", totaliserLoadingEnd);
    	emersonEMF.put("QUANTITY-DELIVERED", quantityDelivered);
    	
    	
    	return emersonEMF;
    }
    
    private Map<String, String> getEAndHMFM(List<Line> lines)
    {
    	Map<String, String> emersonEMF = new HashedMap<String, String>();
    	String sbNumber = null;
//    	EXTRACT SB NUMBER
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "SB") || StringUtils.containsIgnoreCase(line.getLineText(), "SO") || StringUtils.containsIgnoreCase(line.getLineText(), "S0"))
    		{
    			sbNumber = line.getLineText();
    			break;
    		}
    	}
    	

//    	EXTRACT MFM Device ID
    	String deviceId = null;
    	int index = 0;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "System ID") || StringUtils.containsIgnoreCase(line.getLineText(), "System"))
    		{
    			deviceId = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}

    	
//    	EXTRACT BTN
    	String btn = null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "BTN NUMBER") || StringUtils.containsIgnoreCase(line.getLineText(), "BTN") 
    			|| StringUtils.containsIgnoreCase(line.getLineText(), "BIN")
				|| StringUtils.containsIgnoreCase(line.getLineText(), "B1N"))
    			
    		{
    			btn = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}


//    	EXTRACT PRINT TIME
    	String printTime = null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "PRINTOUT TIME:")
    				|| StringUtils.containsIgnoreCase(line.getLineText(), "PRINTOUT TIME")
    				|| StringUtils.containsIgnoreCase(line.getLineText(), "PRINTOUT")
    				|| StringUtils.containsIgnoreCase(line.getLineText(), "PRINT"))
    		{
    			printTime = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}


//    	RESET TIME IS NOT AVAILBLE IN THE E&H MFM TICKET.
////    	EXTRACT RESET TIME
    	String resetTime = null;
//    	index = 0;
//    	for(Line line : lines)
//    	{
//    		if(StringUtils.containsIgnoreCase(line.getLineText(), "RESET TIME") || StringUtils.containsIgnoreCase(line.getLineText(), "RESET"))
//    		{
//    			resetTime = lines.get(index+1).getLineText();
//    			break;
//    		}
//    		index++;
//    	}
    	
    	
//    	EXTRACT BUNKER BEGIN TIME
    	String bunkerBeginTime = null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "START TIME:") 
    				|| StringUtils.containsIgnoreCase(line.getLineText(), "START TIME") 
    				|| StringUtils.containsIgnoreCase(line.getLineText(), "START"))
    		{
    			bunkerBeginTime = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}
    	
    	

//    	EXTRACT BUNKER END TIME
    	String bunkerEndTime = null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(StringUtils.containsIgnoreCase(line.getLineText(), "END TIME:") 
    				|| StringUtils.containsIgnoreCase(line.getLineText(), "END TIME") 
    				|| StringUtils.containsIgnoreCase(line.getLineText(), "END"))
    		{
    			bunkerEndTime = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}
    	

//    	EXTRACT TOTALISER LOADING START
    	String totaliserLoadingStart= null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(		(StringUtils.containsIgnoreCase(line.getLineText(), "TOTALIZER LOADING") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "TOTALISER LOADING") ||  
    				StringUtils.containsIgnoreCase(line.getLineText(), "LOADING"))
    				&&
    				(StringUtils.containsIgnoreCase(lines.get(index+1).getLineText(), "START"))
    		  )
    		{
    			totaliserLoadingStart = lines.get(index+2).getLineText();
    			break;
    		}
    		index++;
    	}

    	
//    	EXTRACT TOTALISER LOADING END
    	String totaliserLoadingEnd= null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(		(StringUtils.containsIgnoreCase(line.getLineText(), "TOTALIZER LOADING") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "TOTALISER LOADING") ||  
    				StringUtils.containsIgnoreCase(line.getLineText(), "LOADING"))
    				&&
    				(StringUtils.containsIgnoreCase(lines.get(index+1).getLineText(), "END"))
    		  )
    		{
    			totaliserLoadingEnd = lines.get(index+2).getLineText();
    			break;
    		}
    		index++;
    	}

    	
//    	EXTRACT TOTALISER DELIVERY START
    	String totaliserDeliveryStart= null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(		(StringUtils.containsIgnoreCase(line.getLineText(), "TOTALIZER DELIVERY") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "TOTALISER DELIVERY") ||  
    				StringUtils.containsIgnoreCase(line.getLineText(), "DELIVERY")||
    				StringUtils.containsIgnoreCase(line.getLineText(), "DETIVERY"))
    				&&
    				(StringUtils.containsIgnoreCase(lines.get(index+1).getLineText(), "START"))
    		  )
    		{
    			totaliserDeliveryStart = lines.get(index+2).getLineText();
    			break;
    		}
    		index++;
    	}

    	
//    	EXTRACT TOTALISER DELIVERY END
    	String totaliserDeliveryEnd= null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(		(StringUtils.containsIgnoreCase(line.getLineText(), "TOTALIZER DELIVERY") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "TOTALISER DELIVERY") ||  
    				StringUtils.containsIgnoreCase(line.getLineText(), "DELIVERY"))
    				&&
    				(StringUtils.containsIgnoreCase(lines.get(index+1).getLineText(), "END"))
    		  )
    		{
    			totaliserDeliveryEnd = lines.get(index+2).getLineText();
    			break;
    		}
    		index++;
    	}

    	
//    	EXTRACT DELIVERED QTY
    	String quantityDelivered= null;
    	index = 0;
    	for(Line line : lines)
    	{
    		if(		StringUtils.containsIgnoreCase(line.getLineText(), "MASS DELIVERED") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "MASS") || 
    				StringUtils.containsIgnoreCase(line.getLineText(), "DELIVERED:")||  
    				StringUtils.containsIgnoreCase(line.getLineText(), "DELIVERED")  
    		  )
    		{
    			quantityDelivered = lines.get(index+1).getLineText();
    			break;
    		}
    		index++;
    	}

    	
//    	CLEANUP CHARACTERS AND SPACES FROM READINGS/MEASUREMENTS.
    	totaliserDeliveryStart = Utilities.removeCharsAndSpaces(totaliserDeliveryStart);
    	totaliserDeliveryEnd = Utilities.removeCharsAndSpaces(totaliserDeliveryEnd);
    	totaliserLoadingStart = Utilities.removeCharsAndSpaces(totaliserLoadingStart);
    	totaliserLoadingEnd = Utilities.removeCharsAndSpaces(totaliserLoadingEnd);
    	quantityDelivered = Utilities.removeCharsAndSpaces(quantityDelivered);

    	emersonEMF.put("SB-NUMBER", sbNumber);
    	emersonEMF.put("DEVICE-ID", deviceId);
    	emersonEMF.put("BTN", btn);
    	emersonEMF.put("RESET-TIME", resetTime);
    	emersonEMF.put("PRINT-TIME", printTime);
    	emersonEMF.put("BUNKER-BEGIN-TIME", bunkerBeginTime);
    	emersonEMF.put("BUNKER-END-TIME", bunkerEndTime);
    	emersonEMF.put("TOTALIZER-DELIVERY-START", totaliserDeliveryStart);
    	emersonEMF.put("TOTALIZER-DELIVERY-END", totaliserDeliveryEnd);
    	emersonEMF.put("TOTALIZER-LOADING-START", totaliserLoadingStart);
    	emersonEMF.put("TOTALIZER-LOADING-END", totaliserLoadingEnd);
    	emersonEMF.put("QUANTITY-DELIVERED", quantityDelivered);
    	
    	
    	return emersonEMF;
    }
    
    public String getOCRPython(String data) {
		String url = "http://localhost:37500/ocr";
        RequestBody formBody = new FormBody.Builder()
                .add("user", "DIB")
                .add("data", "data:image/jpeg;base64,"+data)
                .build();

        Request request = new Request.Builder()
                .url(url)
                .addHeader("User-Agent", "OkHttp Bot")
                .post(formBody)
                .build();

        Response response = null;
        String responseStr = null;
        try {
        	response = httpClient.newCall(request).execute();
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            responseStr = response.body().string();
            // Get response body
            System.out.println("Response from OCR API:"+responseStr);
			
		} catch (Exception e) {
			System.out.println("Error while calling OCR API:"+e.getMessage());
			e.printStackTrace();
		}
        return responseStr;
    }
    
public String getVesselGrossTonnage(String data) throws IOException {
        
    	MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    	RequestBody body = RequestBody.create(JSON, data);

        Request request = new Request.Builder()
                .url(Constants.MPA_VESSEL_GST_URL)
                .addHeader("User-Agent", "API User")
                .post(body)
                .build();

        Response response = null;
        String responseStr = null;
        try {
        	response = httpClient.newCall(request).execute();
        	System.out.print(response);
        	if(!response.isSuccessful()){
        		throw new IOException("Error while calling MPA Vessel API");
        	}
     
        	responseStr = response.body().string();
        	log.info("Response from MPA"+responseStr);
        	 
            } catch (Exception e) {
			System.out.println("Error while calling MPA Vessel API:"+e.getMessage());
			e.printStackTrace();
			throw new IOException("Error while calling MPA Vessel API");
		}
        return responseStr;
    }
 public Object getVesselDataAndGST(String data,String vesselNmae,String IMO) throws Exception {
        
    	MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    	RequestBody body = RequestBody.create(JSON, data);
    	
//    	   RequestBody formBody = new FormBody.Builder()
//                   .add("vesselName",vesselNmae)
//                   .add("imoNumber",IMO)
//                   .build();
//    	
    	log.info("get VesselData And GST");
        Request request = new Request.Builder()
                .url(Constants.MPA_VESSEL_DATA)
                .addHeader("User-Agent", "API User")
                .addHeader("Authorization","Bearer "+token)
                .post(body)
                .build();
    	log.info("Success VesselData And GST");
        Response response = null;
        Object responseStr = null;
        try {
        	response = httpClient.newCall(request).execute();
            //if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            responseStr = response.body().string();
            // Get response body
            System.out.println("Response from MPA Vessel API:"+responseStr);
         
		} catch (Exception e) {
			System.out.println("Error while calling MPA Vessel API:"+e.getMessage());
			throw e;
		}
        return responseStr;
    }

 public Object generateToken() throws Exception {
	 String data = "{\r\n"
	 		+ "\"grant_type\":\"client_credentials\",\r\n"
	 		+ "\"validity_period\":4800\r\n"
	 		+ "}";
	 
	 MediaType JSON = MediaType.parse("application/json; charset=utf-8");
 	RequestBody body = RequestBody.create(JSON, data);
     
 Request request = new Request.Builder()
             .url(Constants.MPA_VESSEL_TOKEN)
             .addHeader("User-Agent", "API User")
             .addHeader("Authorization","Basic "+"UENMUTMyRXhmU0JiOGlXNlA1Y1hVcXlfRmJzYTpSeU1xcThtaWI0T3VKZU1vTnliMnYzbDhXZE1h")
             .post(body)
             .build();
     Response response = null;
     Object responseStr = null;
     try {
    	 log.info("Calling MPA Token");
     	response = httpClient.newCall(request).execute();
     	log.info("DONE MPA Token");

      responseStr = response.body().string();
      log.info("Success VesselData And GST");
      
		} catch (Exception e) {
			System.out.println("Error while calling MPA Token API:"+e.getMessage());
			e.printStackTrace();
			throw e;
		}
     return responseStr;
 }
public String jsonAttachment(String data) {
	 
	 MediaType JSON = MediaType.parse("application/json; charset=utf-8");
 	RequestBody body = RequestBody.create(JSON, data);
 	
    	
        Request request = new Request.Builder()
                .url(Constants.JSON_ATTACHMENT)
                .addHeader("User-Agent", "API User")
                .post(body)
                .build();

        Response response = null;
        String responseStr = null;

        try {
        	OkHttpClient.Builder builder = new OkHttpClient.Builder();
        	builder.connectTimeout(0, TimeUnit.SECONDS); 
        	builder.readTimeout(0, TimeUnit.SECONDS); 
        	builder.writeTimeout(0, TimeUnit.SECONDS); 

        	response = httpClient.newCall(request).execute();
            if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

            responseStr = response.body().string();
            // Get response body
            System.out.println("Response from jsonAttachment:"+responseStr);
			
		} catch (Exception e) {
			System.out.println("Error while calling jsonAttachment:"+e.getMessage());
			e.printStackTrace();
		}

        return responseStr;
    }
@Scheduled(cron = "${cron}")
public void testSchedular() {
	System.out.print("Testing Schedular.............123");
	log.info("TEST SCHEDULAR");
}

public String pushToSGTradex(String json2,Long jobId) throws Exception {
	 MediaType JSON = MediaType.parse("application/json; charset=utf-8");
	 	RequestBody body = RequestBody.create(JSON, json2);
	 	System.out.print(body);
	 	
	        Request request = new Request.Builder()
	                .url(Constants.SGTradex_URL+Constants.BDN_DELIVERY_NOTE_TO_SGTradex)
	                .addHeader("User-Agent", "API User")
	                .addHeader("Authorization", "Bearer "+Constants.SGTradex_TOKEN)
	                .post(body)
	                .build();

	        Response response = null;
	        String responseStr = null;
	        try {
	        	OkHttpClient.Builder builder = new OkHttpClient.Builder();
	        	builder.connectTimeout(0, TimeUnit.SECONDS); 
	        	builder.readTimeout(0, TimeUnit.SECONDS); 
	        	builder.writeTimeout(0, TimeUnit.SECONDS); 

	        	response = httpClient.newCall(request).execute();
	            if (!response.isSuccessful()) {
	            	jobRepository.updateSGTradexStatus("ERROR",response.message(),null,response.body().string(),jobId);
	            	throw new IOException("Unexpected code " + response);
	            }else {
	            	jobRepository.updateSGTradexStatus("PUBLISHED",response.message(),null,response.body().string(),jobId);
	            }

	            // Get response body
	            System.out.println("Response from SGTradex:"+responseStr);
				
			} catch (Exception e) {
				System.out.println("Error while calling SGTradex:"+e.getMessage());
				e.printStackTrace();
				throw e;
			}

	        return "Successfully Pushed to SGTradex";
}

}


