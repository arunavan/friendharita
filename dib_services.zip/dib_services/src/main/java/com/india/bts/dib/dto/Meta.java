package com.india.bts.dib.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Meta implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String data_ref_id;

}
