package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.india.bts.dib.domain.SealCategory;

public interface SealCategoryRepository extends JpaRepository<SealCategory, Long> {

}
