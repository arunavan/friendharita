package com.india.bts.dib.dto;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class TransferOrderDTO {

	@ApiModelProperty(notes = "From Barge", required = true)
	private String fromBarge;

	@ApiModelProperty(notes = "To Barge", required = true)
	private String toBarge;

	@ApiModelProperty(notes = "Location name", required = true)
	private String location;

	@ApiModelProperty(notes = "Bunkering operation type", required = true)
	private String operationType;

	@ApiModelProperty(notes = "formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime nominationDateTime;

	@ApiModelProperty(notes = "Transfer Order Number", required = true)
	private String transferOrderNo;

	private Long bargeId;
	private Long bdnPartyId;
	private String bdnPartyName;

	private String bargeName;
	private String bargeLicenceNo;
	private String bargePumpingRate;

	private String surveyor;
	private String surveyorEmail;

	private boolean printBdn;

	private List<NominationDTO> nominations;
	
	private int is_Updated;
	private String sourceType;
}
