/*******************************************************************************
 * BTS INDIA COPYRIGHT
 * ___________________
 *   
 * [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 * All Rights Reserved.
 *   
 * NOTICE:  All information contained herein is, and remains
 * the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 * and its suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/

package com.india.bts.dib.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name="email_notification_log")
@Data
@NoArgsConstructor
public class EmailNotificationLog implements Serializable {

	private static final long serialVersionUID = 4125027688485616531L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name="job_id")
	private Long jobId;

	@Column(name="email_content_i")
	private Long emailContentId;

	@Column(name="error_msg")
	private String errorMessage;

	@Column(name="receipter")
	private String receipter;

	@Column(name="to_email")
	private String toEmail;

	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;
	
	public EmailNotificationLog(String adminName, String adminEmail, Long jobId, Long contentId) {
		this.receipter = adminName;
		this.toEmail = adminEmail;
		this.jobId = jobId;
		this.emailContentId = contentId;
		this.createdDate = DateTime.now();
	}

	public EmailNotificationLog(String receipterName, String receipterEmail,String errorMessage, Long jobId, Long contentId) {
		this.receipter = receipterName;
		this.toEmail = receipterEmail;
		this.jobId = jobId;
		this.emailContentId = contentId;
		this.errorMessage = errorMessage.substring(0,200);
		this.createdDate = DateTime.now();
	}

	
}
