package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="bunker_requisition_data") 
public class BunkerRequisitionData implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6360097131484204211L;
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20, unique = false)
	private long jobId;
	@Column(nullable=false, updatable =false,name = "vessel_name", length=200)
	private String vesselName;
	@Column(nullable=false, updatable =false,name = "location_name", length=200)
	private String locationName;
	@Column(nullable=true, name = "fuel_oil_qty", length=100)
	private String fuelOilQty;
	@Column(nullable=true, name = "fuel_oil_cst", length=100)
	private String fuelOilCst;
	@Column(nullable=true, name = "gas_oil_qty", length=20)
	private String gasOilQty;
	@Column(nullable=true, name = "nominated_grade", length=100)
	private String nominatedGrade;
	@Column(nullable=true, name = "blended_onboard_in_advance", length=3)
	private boolean blendedOnboardInAdvance;
	@Column(nullable=true, name = "viscosity", length=20)
	private String viscosity;
	@Column(nullable=true, name = "density", length=20)
	private String density;
	@Column(nullable=true, name = "water_content", length=20)
	private String waterContent;
	@Column(nullable=true, name = "flash_point", length=20)
	private String flashPoit;
	@Column(nullable=true, name = "sulpher_content", length=20)
	private String sulpherContent;
	@Column(nullable=true, name = "fuel_supply_first", length=100)
	private String fuelSupplyFirst;
	@Column(nullable=true, name = "fuel_supply_first_qty", length=100)
	private String fuelSupplyFirstQty;
	@Column(nullable=true, name = "fuel_supply_next", length=100)
	private String fuelSupplyNext;
	@Column(nullable=true, name = "fuel_supply_next_qty", length=100)
	private String fuelSupplyNextQty;
	@Column(nullable=true, name = "temperature", length=20)
	private String deliveryTemperature;
	@Column(nullable=true, name = "pumping_rate_fuel_oil", length=20)
	private String requiredPumpingRateFuelOil;
	@Column(nullable=true, name = "pumping_rate_gas_oil", length=20)
	private String requiredPumpingRateGasOil;
	@Column(nullable=true, name = "witness_meter_readings", length=3)
	private boolean witnessMeterReadings;
	@Column(nullable=true, name = "witness_sampling", length=3)
	private boolean witnessSamplingOnVessel;
	@Column(nullable=true, name = "allow_pumping_to_clear_hose", length=3)
	private boolean allowPumpingToClearHose;
	@Column(nullable=true, name = "vesseL_under_fqt", length=3)
	private boolean vesselUnderFQTProgramme;
	@Column(nullable=true, name = "cargo_officer_name", length=200)
	private String cargoOfficer;
	@Column(nullable=true, name = "chief_enineer_name", length=200)
	private String chiefEngineer;
	@Column(nullable=true, name = "surveyor_name", length=200)
	private String surveyor;
	
	
	@Column(nullable=true, name = "co_pre_sign_datetime", length=200)
	private String coPreSignDateTime;
	@Column(nullable=true, name = "co_post_sign_datetime", length=200)
	private String coPostSignDateTime;
	@Column(nullable=true, name = "ce_pre_sign_datetime", length=200)
	private String cePreSignDateTime;
	@Column(nullable=true, name = "ce_post_sign_datetime", length=200)
	private String cePostSignDateTime;
	@Column(nullable=true, name = "sur_pre_sign_datetime", length=200)
	private String surPreSignDateTime;
	@Column(nullable=true, name = "sur_post_sign_datetime", length=200)
	private String surPostSignDateTime;
	
	

	@Column(nullable=true, name ="remarks",  length=2000)
	private String remarks;
	@Column(nullable=true, name ="fuel_supply_rob",  length=200)
	private String fuelSupplyrob;
	
	
	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	
	//@JsonProperty( value = "req_file_binary", access = JsonProperty.Access.WRITE_ONLY)
	
	@Lob
	@Column(nullable=true,name="req_file_binary")
	private String reqFileBinary;
	
	@Column(nullable = true, name = "MPAGrade", length = 500)
	private String mPAGrade;
	@Lob
	@Column(nullable=true,name="CO_Sign")
	private String cOSign;
	@Lob
	@Column(nullable=true,name="CE_Sign")
	private String cESign;
	@Lob
	@Column(nullable=true,name="SV_Sign")
	private String sVSign;
	
	public String getmPAGrade() {
		return mPAGrade;
	}

	public void setmPAGrade(String mPAGrade) {
		this.mPAGrade = mPAGrade;
	}

	public String getcOSign() {
		return cOSign;
	}

	public void setcOSign(String cOSign) {
		this.cOSign = cOSign;
	}

	public String getcESign() {
		return cESign;
	}

	public void setcESign(String cESign) {
		this.cESign = cESign;
	}

	public String getsVSign() {
		return sVSign;
	}

	public void setsVSign(String sVSign) {
		this.sVSign = sVSign;
	}

}
