package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="job_sof") 
public class Sof implements Serializable  {
	
	private static final long serialVersionUID = -6360097131484204215L;
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20)
	private long jobId;
	@Column(nullable=true, name = "sof_date", columnDefinition = "DATE")
	private String sofDate;
	@Column(nullable=true, name = "sof_time", columnDefinition = "TIME")
	private String sofTime;
	@Column(nullable=true, name = "bunker_tanker_name", length=200)
	private String bunkerTankerName;
	@Column(nullable=true, name = "vessel_name", length=200)
	private String vesselName;
	@Column(nullable=true, name = "refference", length=500)
	private String refference;
	@Column(nullable=true, name = "location_name", length=200)
	private String locationName;
	
	@Column(nullable = false,name = "operation_did_commence", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean operationDidCommence;
	
	@Column(nullable=true, name = "pumpin_rate_below_qmin", length=5)
	private String pumpinRateBelowQmin;
	
	@Column(nullable=true, name = "pumpin_rate_below_qmin_remarks", columnDefinition = "TEXT")
	private String pumpinRateBelowQminRemarks;
	
	@Column(nullable = false,name = "operation_request_commence", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean operationRequestCommence;
	
	@Column(nullable=true, name = "rquest_to_commence", length=5)
	private String rquestToCommence;
	
	@Column(nullable = false,name = "operation_did_stoppage", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean operationDidStoppage;
	
	@Column(nullable=true, name = "rquest_to_stoppage", length=5)
	private String rquestToStoppage;
	
	@Column(nullable = false,name = "lower_qmin", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean lowerqmin;
	
	@Column(nullable=true, name = "qty", length=5)
	private String qty;
	
	@Column(nullable=true, name = "lower_qmin_remarks", columnDefinition = "TEXT")
	private String lowerqminRemarks;
	
	@Column(nullable = false,name = "master_aware", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean masterAware;
	
	@Column(nullable = false,name = "line_clearing", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean lineClearing;
	
	@Column(nullable = false,name = "switching_manifold", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean switchingManifold;
	
	@Column(nullable = false,name = "pipeline_restriction", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean pipelineRestriction;
	
	@Column(nullable = false,name = "other_reason", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean otherReason;
	
	@Column(nullable=true, name = "other_reason_remarks", columnDefinition = "TEXT")
	private String otherReasonRemarks;
	
	
	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	
	@Column(nullable=true, name = "cargoofficername", length=250)
	private String cargoOfficer;
	@Column(nullable=true, name = "chiefengineername", length=250)
	private String chiefEngineer;
	@Column(nullable=true, name = "surveyorname", length=250)
	private String surveyor;
	
	
	@Lob
	@Column(nullable=true,name="CO_Sign")
	private String cOSign;
	public String getcOSign() {
		return cOSign;
	}
	public void setcOSign(String cOSign) {
		this.cOSign = cOSign;
	}
	public String getcESign() {
		return cESign;
	}
	public void setcESign(String cESign) {
		this.cESign = cESign;
	}
	public String getsVSign() {
		return sVSign;
	}
	public void setsVSign(String sVSign) {
		this.sVSign = sVSign;
	}
	@Lob
	@Column(nullable=true,name="CE_Sign")
	private String cESign;
	@Lob
	@Column(nullable=true,name="SV_Sign")
	private String sVSign;
	
	@Lob
	@Column(nullable=true,name="sof_file_binary")
	private String sofFileBinary;


	

}
