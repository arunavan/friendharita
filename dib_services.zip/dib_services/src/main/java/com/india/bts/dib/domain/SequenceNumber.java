package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity(name="sequence_number")
public class SequenceNumber implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8665195400064627512L;

	@Id
	@JsonIgnore
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false,name="current_sequence_number")
	private Long sequenceNumber;
	
	
}
