package com.india.bts.dib.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.Grade;
import com.india.bts.dib.domain.Location;
import com.india.bts.dib.repository.GradeRepository;
import com.india.bts.dib.repository.LocationRepository;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.utils.ResponseObject;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class GradeController {
	
	
	@Autowired
	GradeRepository gradeRepo;
	@Autowired
	CurrentUserService currentUserService;
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/grade", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> add(@RequestBody Grade grade) {
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			grade = gradeRepo.save(grade);
		} catch (Exception e) {
			log.error("Unable to add grade", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(grade, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/grade", method = RequestMethod.PATCH, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> update(@RequestBody Grade grade) {
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			grade = gradeRepo.save(grade);
		} catch (Exception e) {
			log.error("Unable to add grade", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(grade, HttpStatus.OK);
	}
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/grade", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> modify(@RequestBody Grade grade) {
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			grade = gradeRepo.save(grade);
		} catch (Exception e) {
			log.error("Unable to add grade", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(grade, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/grade/{id}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> get(@PathVariable("id") long id) {
		Optional<Grade> grade = null;
		try {
			grade = gradeRepo.findById(id);
		} catch (Exception e) {
			log.error("Unable to get grade", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(grade.get(), HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/grade/all", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAll() {
		List<Grade> pages = null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN", "CARGO OFFICER" })) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);	
//		}
			pages = gradeRepo.findAll();
		} catch (Exception e) {
			log.error("Unable to get all grages, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(pages, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = Utilities.APP_VERSION + "/grade/{id}", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Object> delete(@PathVariable("id") long id) {
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			gradeRepo.deleteById(id);
		} catch (Exception e) {
			log.error("Unable to delete grade, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>("Deleted grade with id:"+ id, HttpStatus.OK);
	}


}
