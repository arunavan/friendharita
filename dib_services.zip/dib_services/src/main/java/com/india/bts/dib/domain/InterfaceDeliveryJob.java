package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="jobs_Interface_Delivery") 
public class InterfaceDeliveryJob implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	

	@Column(nullable=false,name="job_type")
	private String jobType;
	@Column(nullable=true,name="stem_no")
    private String stemNo;
	@Column(nullable=true,name="vessel_name")
    private String vesselName;
	@Column(nullable=true,name="vessel_imo")
    private String vesselIMO;
	@Column(nullable=true,name="surveyor_eamil")
    private String surveyorEmail;
	@Column(nullable=false,name="bdn_party_name")
	private String bdnPartyName;
	@Column(nullable=true,name="port")
    private String port;
	@Column(nullable=true,name="location")
    private String location;
	@Column(nullable=true,name="barge_name")
    private String bargeName;
	@Column(nullable=true,name="operation_type")
    private String operationType;
	@Column(nullable=true,name="customer")
    private String customer;
	@Column(nullable=true,name="agent")
    private String agent;
	@Column(nullable=true,name="agent_contact_no")
    private String agentContactNo;
	@Column(nullable=true,name="surveyor")
    private String surveyor;
	@Column(nullable=true,name="cargo_officer")
    private String cargoOfficer;
	@Column(nullable=true,name="cargo_officer_email")
    private String cargoOfficerEmail;
	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(nullable = true, name = "nomination_date")
	private LocalDate nominationDate;
	
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(nullable = true, name = "eta_date_time")
	private LocalDateTime eta;
	
	
	
	@Column(nullable = false,name = "created_date",insertable = true, updatable = false)
	private LocalDateTime createdDate;


	@JsonIgnore
	@Column(name = "created_by", length=500)
	private String createdUser;
	@Column(name="SourceType")
	private String sourceType;
	
	@Column(nullable = false,name ="grade")
	private String grade;
	
	@Column(nullable = false,name ="uom")
	private String uom;
	
	@Column(nullable = false,name ="quantity")
	private String quantity;
	
	@Column(nullable = false,name ="MPAGrade")
	private String mpaGrade;
	@Column(nullable = false,name ="RefitemNo")
	private int refItemNo;
	
	
	

}
