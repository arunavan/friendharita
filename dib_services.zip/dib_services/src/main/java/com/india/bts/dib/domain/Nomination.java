package com.india.bts.dib.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity (name = "nominations") 
public class Nomination implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5349655115909335218L;

	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ApiModelProperty(notes = "Name of the grade", required = true )
	@Column
	private String grade;
	
	@Column(nullable = false,  columnDefinition = "varchar(10) default 'MT'")
	@Enumerated(EnumType.STRING)
	private UomType uom;
	
	@ApiModelProperty(notes = "Quantity of the grade", required = true )
	@Column
	private String quantity;
	
	@ApiModelProperty(notes = "type of the grade", required = true, example = "NOMINATED_GRADE, SUPPLYING_GRADE, RECEIVING_GRADE")
	@Column(name = "type" , nullable = false, columnDefinition = "varchar(255) default 'NOMINATED_GRADE'")
	@Enumerated(EnumType.STRING)
    private GradeType nominationType;
	 
	@ApiModelProperty(notes = "Name of the grade", required = true )
	@Column
	private String mPAGrade;
	
	
	@JsonIgnore
	@ManyToOne
    private Job job;
	
	
	public String getSafeGrade() {
		String safeGrade = StringUtils.replace(this.grade, " ", "-");
		safeGrade = StringUtils.replace(safeGrade, "(", "");
		safeGrade = StringUtils.replace(safeGrade, ")", "");
		safeGrade = StringUtils.replace(safeGrade, "<", "");
		safeGrade = StringUtils.replace(safeGrade, ">", "");
		safeGrade = StringUtils.replace(safeGrade, "%", "");
		safeGrade = StringUtils.replace(safeGrade, ".", "");


		return safeGrade;
	}


	public String getmPAGrade() {
		return mPAGrade;
	}


	public void setmPAGrade(String mPAGrade) {
		this.mPAGrade = mPAGrade;
	}
}
