/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _______________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data 
@NoArgsConstructor 
@Entity(name = "barge")
@ToString
public class Barge implements Serializable {

	private static final long serialVersionUID = -4910485058600118472L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable=false, name = "name", unique=true, length=500)
	@NotBlank
	private String name;
	
	@Column(nullable=true, name = "grade",  length=500)
	@NotBlank
	private String grade;
	
	@Column(nullable=true, name = "pumping_rate", length=500)
	@NotBlank
	private String pumpingRate;
	
	@Column(nullable=true, name = "seiral_numner",length=500)
	@NotBlank
	private String seiralNumner;
	
	@Column(nullable=true, name = "brand", length=500)
	@NotBlank
	private String brand;

	@Column(nullable=true, name = "sb_number",  length=500)
	private String sbNumber;

	
	@Column(nullable=true,name = "min_capacity", columnDefinition="Decimal(16,8) default '00.00'")
	private BigDecimal minCapacity;

	@Column(nullable=true,name = "max_capacity", columnDefinition="Decimal(16,8) default '00.00'")
	private BigDecimal maxCapacity;


	@Column(nullable=true,name = "capacity", columnDefinition="Decimal(16,8) default '00.00'")
	private BigDecimal capacity;
	
	@Column(nullable=true, name = "data_provider",  length=500)
	private String dataProvider;
	
	@Column(nullable = true, name = "is_default", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean itDefault;
	
	@Lob
	@Column(name="barge_logo")
	private String logo;
	
	@Column(name = "sgtradex_id")
	private String sgTradexId;
	
	@Column(name = "sgtradex_name")
	private String sgTradexName;
	
	@Column(name = "sgtradex_data_ref_id")
	private String sgTradexDataRefId;
	
	@Column(name = "sgtradex_vendor_uen")
	private String sgTradexVendorUEN;

	@Column(name = "sgtradex_on_behalf_of_id")
	private String sgTradexOnBehalfId;
	
	@Column(name ="COSupervisorName")
	private String cOSupervisorName;
	
	@Column(name ="COSupervisorEmail")
	private String cOSupervisorEmail;
	
	@Column(name ="Fuel_CategoryId")
	private Long fuelCategoryId;
	
//	@OneToMany(mappedBy = "barge",fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//    private List<BargeMfmSealChecklist> checkList ;
	

	

}
