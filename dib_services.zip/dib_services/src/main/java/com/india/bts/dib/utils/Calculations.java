package com.india.bts.dib.utils;

import java.math.BigDecimal;
public class Calculations {

	public static void main(String[] args) throws Exception {
		calculateVCF(72.806,30,0.8638);	
//		calculateVCF(142.427,30,0.8630);	
//		calculateVCF(4.000,35,0.8638);	
//		calculateVCF(12.997,35,0.6783);	
//		calculateVCF(165.267,40,0.7692);	
//		Above passed parameters in calculateVCF(,,) taken from sample of GoogleSphread sheet.
	}
	
	private static void calculateVCF(double gov,float temp,double density) {
		BigDecimal vcf;
		BigDecimal gsv;
		BigDecimal wcf;
		BigDecimal netQty;

		//VAR1 - VAR8 Are the sub formulas, breaks down for better readability.
		double VAR1 = Math.round(1000*density*100)/100.00;
		BigDecimal VAR2 = doubleValueRounder(-0.00336312+2680.3206/Math.pow(VAR1,2),2);
		BigDecimal VAR3= doubleValueRounder(((594.5418/Math.pow(VAR1,2))+(0/VAR1)),7);
		BigDecimal VAR4= doubleValueRounder(((186.9696/Math.pow(VAR1,2))+(0.4862/VAR1)),7);
		BigDecimal VAR5= doubleValueRounder(((330.301/Math.pow(VAR1,2))+(0/VAR1)),7);
		BigDecimal VAR6= doubleValueRounder(((346.4228/Math.pow(VAR1,2))+(0.4388/VAR1)),7);
		BigDecimal VAR7= doubleValueRounder((temp-15),2);
		BigDecimal VAR8 = getVAR8Value(density,VAR2,VAR3,VAR4,VAR5,VAR6);

		if(gov != 0) {
			vcf = (bigDecimalValueRounder((bigDecimalValueRounder(VAR8.multiply(VAR7),8).negate().add(bigDecimalValueRounder(((VAR8.multiply(VAR8)).multiply(VAR7.multiply(VAR7)).multiply(new BigDecimal(0.8))),9).negate())),8));
		}else {
			vcf = new BigDecimal(0);
		}

		 String vcfString = String.format("%.4f",Math.exp(vcf.doubleValue()));
		 System.out.println("vcf: "+vcfString);
		Response response = new Response();
		
		response.setVcf(vcfString);
		gsv = caclculateGsf(gov,vcfString); 
		response.setStandardVolume(gsv.toString());
		wcf = caclculateWCF(density); 
		response.setWcf(wcf.toString());
		netQty = caclcualteMTs(gov,gsv,wcf);
		response.setNetQuantity(netQty.toString());
		
	}
	
	private static BigDecimal caclcualteMTs(double gov, BigDecimal gsf, BigDecimal wcf) {
		//METRIC TONS
		
		BigDecimal mt;
		if(gov == 0) {
			mt =  new BigDecimal(0);
		}else {
			mt = bigDecimalValueRounder(gsf.multiply(wcf),3);
		}
		System.out.println("mt: "+mt);
		return mt;
	}

	private static BigDecimal caclculateWCF(double density) {
		//W.C.F. ASTM T56		
		
		BigDecimal wcf;
		if(density == 0) {
			wcf = new BigDecimal(0);
		}else {
			wcf = new BigDecimal(density).subtract(new BigDecimal(0.0011));
		}
		wcf = bigDecimalValueRounder(wcf,4);
		System.out.println("wcf: "+wcf);
		return wcf;
	}

	private static BigDecimal caclculateGsf(double gov, String vcfString) {
//		GSF(Gross Standard Volume - 15 C):
		
		BigDecimal gsv;
		if(gov == 0) {
			gsv =  new BigDecimal(0);
		}else {
			gsv = bigDecimalValueRounder(new BigDecimal(gov).multiply(new BigDecimal(vcfString)),3);
		}
		System.out.println("gsv: "+gsv);
		return gsv;
	
	}

	private static BigDecimal getVAR8Value(double density, BigDecimal vAR2, BigDecimal vAR3, BigDecimal vAR4, BigDecimal vAR5, BigDecimal vAR6) {

//		This is also formula, but made it as method for better readability.  
		BigDecimal var8;
		if(density< 0.7705) {
			var8 = vAR6;
		}else {
			if(density<0.7875) {
				var8 = vAR2;
			}else {
				if (density<0.839) {
					var8 = vAR3;
				}else {
					if(density<1.075) {
						var8 = vAR4;
					}else {
						var8 = vAR5;
					}
				}
			}
		}
		
		return var8;
	}
	
	static BigDecimal doubleValueRounder(double value,Integer roundCount){
		//This is Custom method for to round the decimal places of double Value.
		String countFormatString = "%."+roundCount+"f";
		String stringConvertrdValue = String.format(countFormatString, value);
		BigDecimal bigDecimal=new BigDecimal(stringConvertrdValue);
		return bigDecimal;
	}

	static BigDecimal bigDecimalValueRounder(BigDecimal value,Integer roundCount){
		//This is Custom method for to round the decimal places of double Value.
		String countFormatString = "%."+roundCount+"f";
		String stringConvertrdValue = String.format(countFormatString, value);
		BigDecimal bigDecimal=new BigDecimal(stringConvertrdValue);
		return bigDecimal;
	}
}


class Response{
	String vcf;
	String wcf;
	String standardVolume;
	String netQuantity;
	
	public String getVcf() {
		return vcf;
	}
	public void setVcf(String vcf) {
		this.vcf = vcf;
	}
	public String getWcf() {
		return wcf;
	}
	public void setWcf(String wcf) {
		this.wcf = wcf;
	}
	public String getStandardVolume() {
		return standardVolume;
	}
	public void setStandardVolume(String standardVolume) {
		this.standardVolume = standardVolume;
	}
	public String getNetQuantity() {
		return netQuantity;
	}
	public void setNetQuantity(String netQuantity) {
		this.netQuantity = netQuantity;
	}
	
}