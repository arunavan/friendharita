package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.india.bts.dib.domain.CargoLoadingData;

public interface CargoLoadingDataRepository  extends  JpaRepository<CargoLoadingData, Long>{
	
	CargoLoadingData findByJobId(long jobId);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE cargo_loading_data SET Cargo_file_binary= :Cargo_file_binary WHERE job_id = :jobId ", nativeQuery=true)
	void updateBinaryData(@Param("Cargo_file_binary") String Cargo_file_binary,@Param("jobId") Long jobId);
}
