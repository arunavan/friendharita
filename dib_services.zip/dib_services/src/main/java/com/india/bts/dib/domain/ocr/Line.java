package com.india.bts.dib.domain.ocr;

import java.util.List;

import lombok.Data;
@Data
public class Line {

public String LineText;
public List<Word> Words = null;
public Integer MaxHeight;
public Integer MinTop;

}