package com.india.bts.dib.dto;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class CargoLoadingDataDTO {
	
	private String poNumber;
	private String bargeName;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    LocalDateTime loadingDateTime;
	
	private String cargeOwner;
	private String blNo;

	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    LocalDateTime alongsideBerthDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    LocalDateTime commencedLoadingDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    LocalDateTime completedLoadingDateTime;
	
	private List<CargoLoadingFiguresDTO> figures;
}
