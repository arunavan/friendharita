package com.india.bts.dib.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class LoginDTO implements Serializable {
	
	private String username;
	private String password;

}
