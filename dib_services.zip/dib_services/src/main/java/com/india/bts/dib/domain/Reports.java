package com.india.bts.dib.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import lombok.Data;

@Data 
@Entity(name = "job_reports")
public class Reports {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;
	@Column(name="reportid")
	private int reportId;
	@Column(name="reportname")
	private String reportName;
	@Column(name="moduleid")
	private int moduleId;
	@Column(name="transactionid")
	private int transactionId;
	@Lob
	@Column(name ="report_file_binary")
	private String reportFileBinary;
	@Column(name ="job_id")
	private Long jobId;
	

}
