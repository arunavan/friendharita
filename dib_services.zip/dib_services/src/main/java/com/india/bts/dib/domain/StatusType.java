package com.india.bts.dib.domain;

public enum StatusType {
	
	CREATED,
	REGISTRED,
	EXECUTING,
	COMPLETED

}

