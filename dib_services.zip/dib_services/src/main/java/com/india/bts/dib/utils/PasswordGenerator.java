package com.india.bts.dib.utils;

import org.joda.time.LocalDateTime;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordGenerator {

	public static void main(String[] args) {
		System.out.println(LocalDateTime.now().toDate().toString());

		BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
		System.out.println(bCryptPasswordEncoder.encode("zSIuiOXxvDrhq6s"));
	}

}