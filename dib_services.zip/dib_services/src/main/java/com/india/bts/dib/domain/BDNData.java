package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "bdn_data")
@Data
@NoArgsConstructor
public class BDNData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20, unique=true)
	private long jobId;
	
	@Column(nullable=true, length=200)
	private String port;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd", required = true, example = "2022-05-25")
    @JsonFormat(pattern="yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd") 
	@Column(name="bdn_date", columnDefinition = "DATE")
	LocalDate date;
	
	@Column(nullable=true, length=200)
	private String location;
	
	@Column(nullable=true, length=200)
	private String barge;
	
	@Column(nullable=true, name ="vessel_imo",  length=200)
	private String vesselIMO;
	
	@Column(nullable=true, name ="vessel_name",  length=200)
	private String vesselName;
	
	@Column(nullable=true, name ="barge_licence_no",  length=200)
	private String bargeLicenceNo;
	
	@Column(nullable=true, name ="bmt_number",  length=200)
	private String bmtNumber;
	
	@Column(nullable=true, name ="bdn_number",  length=200)
	private String bdnNumber;
	
	@Column(nullable=true, name ="gross_tonnage",  length=200)
	private String grossTonnage;
	
	@Column(nullable=true, name ="vessel_along_side",  length=200)
	private String vesselAlongSide;
	
	@Column(nullable=true, name ="owner",  length=200)
	private String owner;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "commenced_pumping_start", columnDefinition="DATETIME", nullable = false)
    LocalDateTime commencedPumpingStart;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "commenced_pumping_stop", columnDefinition="DATETIME", nullable = false)
    LocalDateTime commencedPumpingStop;
	
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "etd", columnDefinition="DATETIME", nullable = false)
    LocalDateTime etd;
	
	@Column(nullable=true, name ="next_port",  length=200)
	private String nextPort;
	
	@Column(nullable=true, name ="annex_limit_value",  length=200)
	private String annexLimitValue;
	
	@Column(nullable=true, name ="annex_regulation_value",  length=200)
	private String annexRegValue;
	
	@Column(nullable=true, name ="annex_purchaes_value",  length=200)
	private String annexPurValue;
	
	@Column(nullable=true, name ="specified_limit_value",  length=200)
	private String specifiedLimitValue;
	
	@Column(nullable=true, name ="viscosity",  length=200)
	private String viscosity;
	
	@Column(nullable=true, name ="water_content",  length=200)
	private String waterContent;
	
	@Column(nullable=true, name ="sulpher_content",  length=200)
	private String sulpherContent;
	
	@Column(nullable=true, name ="density",  length=200)
	private String density;
	
	@Column(nullable=true, name ="flash_poit",  length=200)
	private String flashPoit;
	
	@Column(nullable=true, name ="fuel_supply_first",  length=200)
	private String fuelSupplyFirst;
	
	@Column(nullable=true, name ="quantity_supplied",  length=200)
	private String quantitySupplied;
	
	@Column(nullable=true, name ="vessel_seal",  length=200)
	private String vesselSeal;
	@Column(nullable=true, name ="vessel_counter_seal",  length=200)
	private String vesselCounterSeal;
	@Column(nullable=true, name ="vessel_counter_seal_two",  length=200)
	private String vesselCounterSeal2;
	
	
	@Column(nullable=true, name ="marpol_seal",  length=200)
	private String marpolSeal;
	@Column(nullable=true, name ="marpol_counter_seal",  length=200)
	private String marpolCounterSeal;
	@Column(nullable=true, name ="marpol_counter_seal_two",  length=200)
	private String marpolCounterSeal2;
	
	
	@Column(nullable=true, name ="bunker_seal",  length=200)
	private String bunkerSeal;
	@Column(nullable=true, name ="bunker_counter_seal",  length=200)
	private String bunkerCounterSeal;
	@Column(nullable=true, name ="bunker_counter_seal_two",  length=200)
	private String bunkerCounterSeal2;
	
	@Column(nullable=true, name ="surveyor_seal",  length=200)
	private String surveyorSeal;
	@Column(nullable=true, name ="surveyor_counter_seal",  length=200)
	private String surveyorCounterSeal;
	@Column(nullable=true, name ="surveyor_counter_seal_two",  length=200)
	private String surveyorCounterSeal2;
	
	@Column(nullable=true, name ="lab_seal",  length=200)
	private String labSeal;
	@Column(nullable=true, name ="lab_counter_seal",  length=200)
	private String labCounterSeal;
	@Column(nullable=true, name ="lab_counter_seal_two",  length=200)
	private String labCounterSeal2;
	
	
	@Column(nullable=true, name ="other_seal",  length=200)
	private String otherSeal;
	@Column(nullable=true, name ="other_counter_seal",  length=200)
	private String otherCounterSeal;
	@Column(nullable=true, name ="other_counter_seal_two",  length=200)
	private String otherCounterSeal2;
	
	@Column(nullable=true, name ="remarks",  length=2000)
	private String remarks;
	
	@Column(nullable=true, name ="customer_feedback",  length=20)
	private String customerFeedback;
	
	@Column(nullable=true, name ="note_of_protest_issued",  length=20)
	private String noteOfProtestIssued;
	
	@Column(nullable=true, name ="copy_of_msdn_received",  length=20)
	private String copyOfMsdnReceived; 	
	@Lob
	@Column(name="bdn_file_binary")
	private String bdnFileBinary;

	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	
	@Column(nullable=true, name = "co_pre_sign_datetime", length=200)
	private String coPreSignDateTime;
	@Column(nullable=true, name = "co_post_sign_datetime", length=200)
	private String coPostSignDateTime;
	@Column(nullable=true, name = "ce_pre_sign_datetime", length=200)
	private String cePreSignDateTime;
	@Column(nullable=true, name = "ce_post_sign_datetime", length=200)
	private String cePostSignDateTime;
	@Column(nullable=true, name = "sur_pre_sign_datetime", length=200)
	private String surPreSignDateTime;
	@Column(nullable=true, name = "sur_post_sign_datetime", length=200)
	private String surPostSignDateTime;
	@Column(nullable = true, name = "MPAGrade", length = 500)
	private String mPAGrade;
	
	public String getmPAGrade() {
		return mPAGrade;
	}
	public void setmPAGrade(String mPAGrade) {
		this.mPAGrade = mPAGrade;
	}
	@Column(nullable=true, name = "cargoofficername", length=250)
	private String cargoOfficer;
	@Column(nullable=true, name = "chiefengineername", length=250)
	private String chiefEngineer;
	@Column(nullable=true, name = "surveyorname", length=250)
	private String surveyor;
	@Lob
	@Column(nullable=true,name="CO_Sign")
	private String cOSign;
	@Lob
	@Column(nullable=true,name="CE_Sign")
	private String cESign;
	public String getcOSign() {
		return cOSign;
	}
	public void setcOSign(String cOSign) {
		this.cOSign = cOSign;
	}
	public String getcESign() {
		return cESign;
	}
	public void setcESign(String cESign) {
		this.cESign = cESign;
	}
	public String getsVSign() {
		return sVSign;
	}
	public void setsVSign(String sVSign) {
		this.sVSign = sVSign;
	}
	@Lob
	@Column(nullable=true,name="SV_Sign")
	private String sVSign;
	
	@Column(nullable=true, name = "temperature")
	private String temperature;

}
