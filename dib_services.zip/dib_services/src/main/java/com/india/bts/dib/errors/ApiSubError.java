package com.india.bts.dib.errors;

public abstract class ApiSubError {
}
