package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="sof_question_option") 
public class SOFQuestionOption implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -11300308776453881L;

	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=true,name="option_name",length=1000)
    private String optionName;
	@Column(nullable=true,name="option_value",columnDefinition = "TEXT")
    private String optionValue;
	@Column(nullable=true,name="is_selected",length=1)
    private boolean isSelected;

	
	@ManyToOne
	@JsonIgnore
    private SOFQuestion sofQuestion;
								  
}
