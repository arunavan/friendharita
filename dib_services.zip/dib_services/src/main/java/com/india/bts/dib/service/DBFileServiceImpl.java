package com.india.bts.dib.service;

import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.india.bts.dib.domain.Attachment;
import com.india.bts.dib.domain.File;
import com.india.bts.dib.repository.DBFileRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DBFileServiceImpl implements DBFileService {
	
	@Autowired
	FileStorageService fileService;
	
	@Autowired
	DBFileRepository dbFileRepo;

	@Override
	public File save(File file) {
		return dbFileRepo.save(file);
	}

	@Override
	public List<File> findByJobId(Long jobId) {
		return dbFileRepo.findByJobId(jobId);
	}
	
	@Override
	public List<File> findByJobIdAndDocumentType(Long jobId, String documentType) {
		return dbFileRepo.findByJobIdAndDocumentTypeOrderByIdDesc(jobId, documentType);
	}
	
	public void savecontent(Attachment dto,HttpServletResponse response,
    		HttpServletRequest request) throws Exception {
		byte[] bytes = null;
		if(FilenameUtils.getExtension(dto.getFileName()).equals("pdf")) {
			bytes = Base64.getDecoder().decode(dto.getContent().substring(28));
		}else if(FilenameUtils.getExtension(dto.getFileName()).equals("jfif")||FilenameUtils.getExtension(dto.getFileName()).equals("jpeg")
				||FilenameUtils.getExtension(dto.getFileName()).equals("jpg")) {
		bytes = Base64.getDecoder().decode(dto.getContent().substring(23));
		}
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		buffer.write(bytes);
		//String filename = dto.getFileName().substring(0, dto.getFileName().lastIndexOf("."));
		fileService.storeFile(dto.getFileName(), buffer,dto.getJobId());
		
	}
	
	
	

}
