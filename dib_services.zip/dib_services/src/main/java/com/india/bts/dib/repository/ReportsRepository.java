package com.india.bts.dib.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.india.bts.dib.domain.Reports;

public interface ReportsRepository extends JpaRepository<Reports,Long>{

	Reports findByJobIdAndReportName(Long job_id, String reportname);

	@Modifying
	@Transactional
	@Query(value="update job_reports set report_file_binary =?3 where job_id =?1 and reportname =?2",nativeQuery =true)
	void updateBinaryData(Long job_id, String printName,String binaryData);

	List<Reports> findByJobId(Long id);

	@Modifying
	@Transactional
	void deleteByJobIdAndReportName(Long job_id, String reportname);

}
