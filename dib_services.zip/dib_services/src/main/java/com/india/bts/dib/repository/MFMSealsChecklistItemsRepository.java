package com.india.bts.dib.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.india.bts.dib.domain.MFMSealsChecklistData;
import com.india.bts.dib.domain.MFMSealsChecklistItems;

@Repository
public interface MFMSealsChecklistItemsRepository extends JpaRepository<MFMSealsChecklistItems, Long> {

	@Modifying
	@Transactional
	void deleteByMfmSealsChecklistId(long id);
	
	@Modifying
	@Transactional
	void deleteByMfmSealsChecklist(MFMSealsChecklistData mfmSealsChecklist);

	@Modifying
	@Transactional
	@Query(value="delete from mfm_seals_checklist_items  where mfmSealsChecklist_id = ?1", nativeQuery = true)
	void deleteALLMfmSealsChecklist(long id);

}
