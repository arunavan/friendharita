package com.india.bts.dib.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.CargoLoadingData;
import com.india.bts.dib.dto.CargoLoadingDataDTO;
import com.india.bts.dib.service.CargoLoadingDataServiceImpl;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CargoLoadingDataController {
	
	@Autowired
	CargoLoadingDataServiceImpl cargoService;

	@Autowired
	ModelMapper modelMapper;

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/cargo-loading", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> add(@RequestBody CargoLoadingDataDTO dto) {
		CargoLoadingData postRequest = null;
		try {
			postRequest = modelMapper.map(dto, CargoLoadingData.class);
			log.info("job:" + postRequest.toString());
			postRequest = cargoService.create(postRequest);

		} catch (Exception e) {
			log.error("Unable to add job", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(postRequest, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/cargo-loading/{id}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> update(@PathVariable("id") long id, @RequestBody CargoLoadingDataDTO dto) {
		CargoLoadingData postRequest = null;
		try {
			postRequest = modelMapper.map(dto, CargoLoadingData.class);
			postRequest.setId(id);
			log.info("job:" + postRequest.toString());
			postRequest = cargoService.create(postRequest);

		} catch (Exception e) {
			log.error("Unable to add job", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(postRequest, HttpStatus.OK);
	}


}
