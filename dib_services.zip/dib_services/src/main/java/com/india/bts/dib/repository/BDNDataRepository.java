package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.india.bts.dib.domain.BDNData;

public interface BDNDataRepository extends JpaRepository<BDNData, Long> {
	
	BDNData findByJobId(long jobId);

	@Modifying
	@Transactional
	@Query(value ="UPDATE bdn_data SET commenced_pumping_start =:commenced_pumping_start ,commenced_pumping_stop =:commenced_pumping_stop,quantity_supplied=:quantity_supplied,bmt_number=:bmt_number WHERE job_id = :jobId ", nativeQuery=true)
	void updatePumpingStartEndTimes(@Param("commenced_pumping_start") String commenced_pumping_start, @Param("commenced_pumping_stop") String commenced_pumping_stop,@Param("quantity_supplied") String quantity_supplied,
			@Param("bmt_number") String bmt_number,@Param("jobId") Long jobId);
	@Modifying
	@Transactional
	@Query(value ="UPDATE bdn_data SET viscosity=:viscosity,density=:density,sulpher_content=:sulpher_content,water_content=:water_content,flash_poit=:flash_poit  WHERE job_id = :jobId ", nativeQuery=true)
	void updateManditoryFields(@Param("jobId") Long jobId, @Param("viscosity")String viscosity,@Param("density") String density,@Param("water_content") String water_content, @Param("sulpher_content")String sulpher_content,
			@Param("flash_poit") String flash_poit);
	
	//updating signatures to null if any changes made in breq,meterticket
	@Modifying
	@Transactional
	@Query(value ="UPDATE bdn_data SET co_pre_sign_datetime=null,ce_pre_sign_datetime= null,bdn_file_binary= null, "
			+ "CO_Sign=null,CE_Sign=null,SV_Sign=null WHERE job_id = :jobId ", nativeQuery=true)
	void clearDateFields(@Param("jobId") Long jobId);
	
	
	@Modifying
	@Transactional
	@Query(value ="UPDATE bdn_data SET quantity_supplied=:quantity_supplied  WHERE job_id = :jobId ", nativeQuery=true)
	void updateDeliverqty(@Param("quantity_supplied") String quantity_supplied,@Param("jobId") Long jobId);
	
	


}
