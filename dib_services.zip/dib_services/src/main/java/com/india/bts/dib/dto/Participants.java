package com.india.bts.dib.dto;

import lombok.Data;

@Data
public class Participants {

	private String id;
	 
	private String name;

	private Meta meta;

}
