package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.india.bts.dib.domain.BunkerRequisitionData;
import com.india.bts.dib.domain.ESignaturesData;

public interface ESignatureRepository extends JpaRepository<ESignaturesData, Long> {
	
	ESignaturesData findByJobId(long jobId);
}
