package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="timelog_checklist_items") 
public class TimelogChecklistItems implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -11300308776453733L;

	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=true,name="item_name",length=500)
    private String itemName;
	
	@Column(nullable=true,name="date_time",length=200)
    private String dateTime;

	@Column(nullable=true,name="remarks ",columnDefinition = "TEXT")
    private String remarks;
	
	
	@ManyToOne
	@JsonIgnore
    private TimelogData timelogChecklist;
								  
}
