package com.india.bts.dib.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;

import com.india.bts.dib.controller.DocumentController;
import com.india.bts.dib.domain.FileStorageProperties;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FileStorageService {
	
	private final Path fileStorageLocation;
	
	@Autowired
	public FileStorageService(FileStorageProperties fileStorageProperties) throws Exception {
		this.fileStorageLocation = Paths.get(fileStorageProperties.getUpload()).toAbsolutePath().normalize();

		try {
			Files.createDirectories(this.fileStorageLocation);
		} catch (Exception ex) {
			throw ex;
		}
	}

	public FileStorageService() {
		this.fileStorageLocation = null;
	}
	public String storeFile(String folderName, ByteArrayOutputStream poReport,Long jobId) {
		FileOutputStream fos = null;
		String fileName = folderName ;
		Path targetLocation = null;
		try {
			
			Calendar cal = Calendar.getInstance();
			String extendedPath = cal.get(Calendar.YEAR) + "\\" 
					+ "\\" + jobId + "\\";

				boolean dirExists = Files.exists(this.fileStorageLocation.resolve(extendedPath));
				if (!dirExists) {
					Files.createDirectories(this.fileStorageLocation.resolve(extendedPath));
				}

				// Copy file to the target location (Replacing existing file with the same name)
				targetLocation = this.fileStorageLocation.resolve(extendedPath).resolve(fileName);
				log.info("Target path to store file " + targetLocation);
				fos = new FileOutputStream(new File(targetLocation.toString()));

				poReport.writeTo(fos);
		
				
		} catch (IOException ioe) {
			log.error("Got error while storing  file into " + targetLocation + ioe.getMessage());
			ioe.printStackTrace();
		} finally {
			try {
				fos.close();
			} catch (IOException e) {
				log.error("Got error while storing  file into " + targetLocation + e.getMessage());
				e.printStackTrace();
			}
		}
		return targetLocation.toString();
	}

	public Resource loadFileAsResource(String strFilePath) throws Exception {
		try {
			Path filePath = Paths.get(strFilePath);

			Resource resource = new UrlResource(filePath.toUri());
			if (resource.exists()) {
				return resource;
			} else {
				throw new Exception("File not found " + strFilePath);
			}
		} catch (MalformedURLException ex) {
			throw new Exception("File not found " + strFilePath, ex);
		}
	}
	
	
	public boolean deletedDocument(String strFilePath) throws IOException {
		Path targetLocation = null;
		try {
			Path filePath = Paths.get(strFilePath);
			targetLocation = filePath;
			Files.deleteIfExists(targetLocation);
		}catch (IOException e) {
			log.error("Got error while deleting file from " + targetLocation + e.getMessage());
			throw e;
		}
		return true;
	}

}
