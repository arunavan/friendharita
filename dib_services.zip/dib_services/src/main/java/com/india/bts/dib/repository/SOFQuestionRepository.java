package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.india.bts.dib.domain.SOFQuestion;

public interface SOFQuestionRepository extends JpaRepository<SOFQuestion, Long> {
	
	  void  deleteBySofDataId(long id);
	
}
