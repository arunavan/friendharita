package com.india.bts.dib.service;

public interface AsynServices {
	void generateBinaryData(Long job_id,String reportPath,String printName,int moduleId,int transactionId);
	public void saveAttachment(Long job_id,int moduleId,int reportId,String binaryData,String printName,int transactionId);
	//void compressPdf(String targetPath);

}
