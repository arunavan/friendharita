package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="sales_order") 
public class SalesOrder implements  Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4811637676631729915L;
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "job_id")
    Long jobId;
	
	
	@OneToOne
    @PrimaryKeyJoinColumn(name = "job_id")
    Job job;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(nullable = true, name = "nomination_date_time", columnDefinition="DATETIME")
    LocalDateTime nominationDateTime;
	
	@ApiModelProperty(notes = "Stem Number", required = true )
	@Column(nullable=true,name="stem_no",length=500)
    private String stemNo;
	@ApiModelProperty(notes = "Name of the Vessel", required = false )
	@Column(nullable=true,name="vessel_name",length=500)
    private String vesselName;
	@ApiModelProperty(notes = "IMO number of the Vessel", required = false )
	@Column(nullable=true,name="vessel_imo",length=500)
    private String vesselIMO;
	@ApiModelProperty(notes = "Vessel email", required = false )
	@Column(nullable=true,name="vessel_eamil",length=500)
    private String vesselEmail;
	@ApiModelProperty(notes = "Port name", required = true )
	@Column(nullable=true,name="port",length=500)
    private String port;
	
	@ApiModelProperty(notes = "Location name", required = true )
	@Column(nullable=true,name="location",length=500)
    private String location;
	
	@ApiModelProperty(notes = "Name of the bare ", required = true )
	@Column(nullable=true,name="barge_name",length=500)
    private String bargeName;
	@ApiModelProperty(notes = "Barge licence number", required = true )
	@Column(nullable=true,name="barge_licence_no",length=500)
    private String bargeLicenceNo;
	@ApiModelProperty(notes = "Barge pumping rate", required = true )
	@Column(nullable=true,name="barge_pumping_rae",length=500)
    private String bargePumpingRate;
	
	@Column(nullable=true,name="customer",length=500)
    private String customer;
	@Column(nullable=true,name="agent",length=500)
    private String agent;
	@Column(nullable=true,name="agent_contact_no",length=500)
    private String agentContactNo;

	@Column(nullable=true,name="chief_engineer",length=500)
    private String chiefEngineer;
	
	
	@Column(nullable=true,name="surveyor",length=500)
    private String surveyor;
	
	@Column(nullable=true,name="cargo_officer",length=500)
    private String cargoOfficer;
	
//	@JsonManagedReference
//	@OneToMany(mappedBy="job",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
//	private List<Nomination> nominations;
	
//	@JsonIgnore
//	@OneToOne(mappedBy = "salesOrder")
//	@MapsId
//    private Job job;

}
