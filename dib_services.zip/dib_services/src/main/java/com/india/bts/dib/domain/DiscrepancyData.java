package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity(name = "discrepancy_data")
public class DiscrepancyData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20)
	private long jobId;
	
	@Column(nullable=true, name = "barge")
	private String barge;
	@Column(nullable=true, name = "barge_licence_no")
	private String bargeLicenceNo;
	@Column(nullable=true, name = "vessel_name")
	private String vesselName;
	@Column(nullable=true, name = "nominated_qty")
	private String nominatedQty;
	@Column(nullable=true, name = "nominated_grade")
	private String nominatedGrade;
	@Column(nullable=true, name = "po_number")
	private String poNumber;
	@Column(nullable=true, name = "cargo_owner")
	private String cargoOwner;
	@Column(nullable=true, name = "location_name")
	private String locationName;
	
	@Column(nullable=true, name = "is_letter_of_protest", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean letterOfProtest;
	@Column(nullable=true, name = "is_notice_of_discrepancy",columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean noticeOfDiscrepancy;
	@Column(nullable=true, name = "is_after", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean after;
	@Column(nullable=true, name = "is_loading", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean loading;
	@Column(nullable=true, name = "is_transhipment", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean transhipment;
	@Column(nullable=true, name = "is_before", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean before;
	@Column(nullable=true, name = "is_discharge", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean discharge;
	
	@Column(nullable=true, name = "userName")
	private String userName;
	
	@Column(nullable=true, name = "is_auantity_discrepancy", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean quantityDiscrepancy;
	@Column(nullable=true, name = "is_transit_variance", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean transitVariance;
	@Column(nullable=true, name = "is_metric_tonnes", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean metricTonnes;
	@Column(nullable=true, name = "is_bbls", columnDefinition = "TINYINT(1) DEFAULT 0", length = 1)
	private boolean bbls;
	
	@Column(nullable=true, name = "bl_qty")
	private String blQty;
	@Column(nullable=true, name = "mfm_qty")
	private String mfmQty;
	@Column(nullable=true, name = "sounding_qty")
	private String soundingQty;
	@Column(nullable=true, name = "sound_diff")
	private String soundDiff;
	@Column(nullable=true, name = "sound_diff_in_percentage")
	private String soundDiffInPercentage;
	@Column(nullable=true, name = "mfm_diff")
	private String mfmDiff;
	@Column(nullable=true, name = "mfm_diff_in_percentage")
	private String mfmDiffInPercentage;
	@Column(nullable=true, name = "co_pre_sign_datetime")
	private String coPreSignDateTime;
	@Column(nullable=true, name = "sur_pre_sign_datetime")
	private String surPreSignDateTime;
	@Column(nullable=true, name = "ce_pre_sign_datetime")
	private String cePreSignDateTime;
	@Column(nullable=true, name = "remarks", length = 2500)
	private String remarks;
		
	@CreatedDate
	@Column(nullable=true, name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable=true, name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true, name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true, name = "updated_by", length=500)
	private String updatedUser;
	

}
