package com.india.bts.dib.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Column;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class SalesOrderDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(notes = "formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	LocalDateTime nominationDateTime;
	
	@ApiModelProperty(notes = "formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	LocalDateTime eta;
	
	@ApiModelProperty(notes = "Stem Number", required = true)
	private String stemNo;
	@ApiModelProperty(notes = "Name of the Vessel", required = false)
	private String vesselName;
	@ApiModelProperty(notes = "IMO number of the Vessel", required = false)
	private String vesselIMO;
	@ApiModelProperty(notes = "Vessel email", required = false)
	private String vesselEmail;
	@ApiModelProperty(notes = "formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime vesselAlongSideTime;
	@ApiModelProperty(notes = "Port name", required = true)
	private String port;

	@ApiModelProperty(notes = "Location name", required = true)
	private String location;

	private Long bargeId;
	@ApiModelProperty(notes = "Name of the bare ", required = true)
	private String bargeName;
	@ApiModelProperty(notes = "Barge licence number", required = true)
	private String bargeLicenceNo;
	@ApiModelProperty(notes = "Barge pumping rate", required = true)
	private String bargePumpingRate;

	@ApiModelProperty(notes = "Bunkering operation type", required = true)
	private String operationType;

	private String customer;
	private String agent;
	private String agentContactNo;
	
	private Long bdnPartyId;
	private String bdnPartyName;

	private String chiefEngineer;
	private String cargoOfficer;
	private String cargoOfficerEmail;
	
    private String surveyor;
    private String surveyorEmail;
    private int mode;

	private List<NominationDTO> nominations;
	private int isVesselVerified;
	private String contigencyRemarks;
	private int contigencyCeVerified;
	private int contigencyCeEmailFailed;
	private int contigencyCeAccessFailed;
	private int contigencyCeLoginFailed;
	private int contigencyCeApprovalSupervisor;
	private int is_Updated;
	private String sourceType;
	private BigDecimal minCapacity;
	private BigDecimal maxCapacity;
	private Long fuelCategoryId;

}
