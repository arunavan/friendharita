package com.india.bts.dib.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.india.bts.dib.domain.BDNParty;

@Repository
public interface BDNPartyRepository extends JpaRepository<BDNParty, Long> {
	
	@Transactional
	@Modifying
	@Query(value="UPDATE bdn_parties SET is_default=0 WHERE id > 0", nativeQuery = true)
	void setAllUnDefault();
	
	BDNParty findByCompanyName(String companyName);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE bdn_data SET bdn_file_binary=:bdn_file_binary WHERE job_id = :jobId ", nativeQuery=true)
	void updateBinaryData(@Param("bdn_file_binary") String bdn_file_binary,@Param("jobId") Long jobId );


}
