package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.india.bts.dib.domain.MFMSealChecklist;

public interface MFMSealChecklistRepository extends JpaRepository<MFMSealChecklist, Long> {

	@Modifying
	@Transactional
	@Query(value="UPDATE mfm_seals_checklist_data SET sur_pre_sign_datetime= :sur_pre_sign_datetime,sur_post_sign_datetime= :sur_post_sign_datetime where job_id =:job_id")
	void updateTimeStamps(@Param("job_id") Long jobId,@Param("sur_pre_sign_datetime") String sur_pre_sign_datetime,@Param("sur_post_sign_datetime") String sur_post_sign_datetime);

}
