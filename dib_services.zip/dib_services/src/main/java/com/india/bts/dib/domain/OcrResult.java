package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @Entity(name = "ocr_result")
public class OcrResult implements Serializable  {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name="job_id")
	private Long jobId;
	
	@Column(name="btn")
	private String btn;
	
	@Column(name="printout_time")
	private String printoutTime;
	
	@Column(name="vessel_id")
	private String vesselId;
	
	@Column(name="system_id")
	private String systemId;
	
	@Column(name="start_time")
	private String startTime;
	
	@Column(name="end_time")
	private String endTime;
	
	@Column(name="totalizer_loading_operation_start")
	private String totalizerLoadingOperationStart;
	
	@Column(name="totalizer_loading_operation_end")
	private String totalizerLoadingOperationEnd;
	
	@Column(name="totalizer_delivery_operation_start")
	private String totalizerDeliveryOperationStart;
	
	@Column(name="totalizer_delivery_operation_end")
	private String totalizerDeliveryOperationEnd;
	
	@Column(name="delivered")
	private String delivered;
	

}
