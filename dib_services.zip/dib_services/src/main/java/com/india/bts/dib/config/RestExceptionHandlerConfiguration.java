package com.india.bts.dib.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.india.bts.dib.errors.RestExceptionHandler;

@Configuration
public class RestExceptionHandlerConfiguration {

    @Bean
    public RestExceptionHandler restControllerExceptionHandler(){
        return new RestExceptionHandler();
    }

}
