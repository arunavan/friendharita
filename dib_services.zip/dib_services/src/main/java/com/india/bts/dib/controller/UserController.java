/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _________________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.controller;


import static com.india.bts.dib.security.SecurityConstants.EXPIRATION_TIME;
import static com.india.bts.dib.security.SecurityConstants.HEADER_EMAIL;
import static com.india.bts.dib.security.SecurityConstants.HEADER_PASSWORD;
import static com.india.bts.dib.security.SecurityConstants.HEADER_STRING;
import static com.india.bts.dib.security.SecurityConstants.SECRET;
import static com.india.bts.dib.security.SecurityConstants.TOKEN_PREFIX;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestWrapper;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.Barge;
import com.india.bts.dib.domain.User;
import com.india.bts.dib.domain.UserRole;
import com.india.bts.dib.dto.LoginResponseDTO;
import com.india.bts.dib.dto.PasswordChangeReqDTO;
import com.india.bts.dib.dto.UserDTO;
import com.india.bts.dib.repository.ApplicationUserRepository;
import com.india.bts.dib.repository.BargeRepository;
import com.india.bts.dib.repository.UserRepository;
import com.india.bts.dib.repository.UserRoleRepository;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.utils.ResponseObject;
import com.india.bts.dib.utils.Utilities;
import com.itextpdf.text.log.SysoCounter;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class UserController {

	private ApplicationUserRepository applicationUserRepository;
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	CurrentUserService currentUserService;

	@Autowired
	UserRepository userRepo;
	
	@Autowired
	UserRoleRepository roleRepository;
	
	@Autowired
	BargeRepository bargeRepository;
	

	public UserController(ApplicationUserRepository applicationUserRepository,
			BCryptPasswordEncoder bCryptPasswordEncoder) {
		this.applicationUserRepository = applicationUserRepository;
		this.bCryptPasswordEncoder = bCryptPasswordEncoder;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/user", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> add(@RequestBody UserDTO userDto) {
		User user = null;
		try {
		
			user = new User(userDto, currentUserService.getCurrentUser());
		
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
			user = userRepo.save(user);
		
		} catch (Exception e) {
			log.error("Unable to add user, please try again!, posible error: ", e);
			return new ResponseEntity<Object>(
					new ResponseObject(500, "Unable to add  user, Please try again! ", null, true),
					HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Object>(new ResponseObject(200, "user created successfully", user, true),
				HttpStatus.OK);
	}

	
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ "user", method = RequestMethod.PATCH, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> modify(@RequestBody UserDTO userDto) {
		User user = null;
		User registredUser = null;
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				if(!StringUtils.equalsIgnoreCase(userDto.getEmail(), currentUserService.getCurrentUser().getEmail()))
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}

			Optional<User> result =  userRepo.findById(userDto.getId());
			if(result.isPresent()){
				registredUser = result.get();
			}
			
			if(registredUser != null) {
				userDto.setPassword(registredUser.getPassword());
			}
			user = new User(userDto, currentUserService.getCurrentUser());
			if(user.isRequiredToResetPassword())
				user.setPassword(bCryptPasswordEncoder.encode("Test@123"));

			user = userRepo.save(user);
							
		} catch (Exception e) {
			log.error("Unable to update user with id: " + userDto.getId(), e);
			return new ResponseEntity<Object>(
					new ResponseObject(500, "Internal Server Error,Unable to update user with id: " + user.getId()
							+ ", error: " + e.getMessage(), null, true),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(
				new ResponseObject(200, "Update user details with id : " + user.getId(), user, true), HttpStatus.OK);
	}
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ "user", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> update(@RequestBody UserDTO userDto) {
		User user = null;
		try {
//			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN"})) {
//				if(!StringUtils.equalsIgnoreCase(userDto.getEmail(), currentUserService.getCurrentUser().getEmail()))
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			
			User registrerdUser = userRepo.findById(userDto.getId()).get();
			if(registrerdUser != null) {
				userDto.setPassword(registrerdUser.getPassword());
			}
			user = new User(userDto, currentUserService.getCurrentUser());
			if(user.isRequiredToResetPassword())
				user.setPassword(bCryptPasswordEncoder.encode("Test@123"));
			
			user = userRepo.save(user);

			
							
		} catch (Exception e) {
			log.error("Unable to update user with id: " + userDto.getId(), e);
			return new ResponseEntity<Object>(
					new ResponseObject(500, "Internal Server Error,Unable to update user with id: " + user.getId()
							+ ", error: " + e.getMessage(), null, true),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(
				new ResponseObject(200, "Update user details with id : " + user.getId(), user, true), HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/sign-in", method = RequestMethod.POST)
	@ResponseBody
	public LoginResponseDTO loginUser(HttpServletRequest req ) throws Exception {
		log.info("Calling service /sign-in");
		String token = null;
		String refreshToken = null;
		Optional<Barge> barge = null;
		try {

			String email = req.getHeader(HEADER_EMAIL);
			String password = req.getHeader(HEADER_PASSWORD);
			log.info("From Header: EMail=" + email + " Password=*********");
			
			Authentication authentication = authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(email, password, new ArrayList<>()));

			SecurityContextHolder.getContext().setAuthentication(authentication);
			
			User appUser = applicationUserRepository.findByEmail(email);
			if(appUser.getBargeId()!= null) {
				barge = bargeRepository.findById(appUser.getBargeId());
			}
			
			System.out.println("_______Built user obj from user creds as:"+appUser.toString());
			if (authentication.isAuthenticated()) {
				token = Jwts.builder()
						.setSubject(((org.springframework.security.core.userdetails.User) authentication.getPrincipal())
								.getUsername())
						.setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
						.signWith(SignatureAlgorithm.HS512, SECRET.getBytes()).compact();
				
			} else {

				throw new Exception("Invalid Credentials");
			}

			return new LoginResponseDTO(appUser.getId(), email, appUser.getFirstName()+" "+appUser.getLastName(), TOKEN_PREFIX + token,
					refreshToken, EXPIRATION_TIME, appUser.getRoles().iterator().next().getRole(),
					false,
					appUser.getBargeId()!= null ? barge.isPresent() ? barge.get().getId() :null: null, 
							appUser.getBargeId()!= null ? barge.isPresent() ? barge.get().getName() :null : null,
									appUser.getBargeId()!= null ? barge.isPresent() ? barge.get().getSbNumber() :null: null );
		} catch (Exception e) {
			log.error("Something wrong in login service", e);
			throw new Exception("Server Exception");
		}
	}
	

	@RequestMapping(value = Utilities.APP_VERSION + "/userbytoken", method = RequestMethod.GET)
	@ResponseBody
	public User getUserData(HttpServletRequest request) {
		log.info("Calling service /userbytoken");
		try {
			String token = request.getHeader(HEADER_STRING);
			if (token != null) {
				// parse the token.
				String user = Jwts.parser().setSigningKey(SECRET.getBytes())
						.parseClaimsJws(token.replace(TOKEN_PREFIX, "")).getBody().getSubject();
				log.info("userbytoken =" + user);
				if (user != null) {
					User appUser = applicationUserRepository.findByEmail(user);
					return appUser;
				
				}
			}
		} catch (Exception e) {
			log.error("Unable to get user with token, error: ", e);
			
		}
		return null;
	}
	

	@RequestMapping(value = Utilities.APP_VERSION + "/user/{userId}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getUserById(@PathVariable("userId") Long userId) {
		Optional<User> user = null;
		try {
			User currentUser = currentUserService.getCurrentUser();
			String currentUserRole = currentUser.getRoles().iterator().next().getRole();
			if (currentUserRole.equals("ADMIN") || currentUserRole.equals("MANAGER")) {
				user = userRepo.findById(userId);
			} else {
				log.error("Unable to get user details ",
						new Exception("Beceause current user is unauthorized to modify user details"));
				return new ResponseEntity<Object>(new ResponseObject(403,
						"Unable to get user details with id:" + userId + ", error:"
								+ new Exception("Beceause current user is unauthorized to modify user details"),
						null, true), HttpStatus.FORBIDDEN);
			}
		} catch (Exception e) {
			log.error("Unable to get user with id:" + userId, e);
			return new ResponseEntity<Object>(new ResponseObject(500,
					"Unable to get user with id:" + userId + ", error:" + e.getMessage(), null, true),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(new ResponseObject(200, "User with id:" + userId, user, true), HttpStatus.OK);
	}
	
	@RequestMapping(value = Utilities.APP_VERSION + "/user/all", method = RequestMethod.GET)
	@ResponseBody
	public Object getAll() {
		ArrayList<User> pageUsers = null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(),
//					new String[] { "ADMIN", "CARGO OFFICER" })) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			pageUsers = (ArrayList<User>) userRepo.findAll();
			

		} catch (Exception e) {
			log.error("Unable to get all users,", e);
			return new Exception("Internal Server Error");
		}
		return pageUsers;
	}
	@RequestMapping(value = Utilities.APP_VERSION + "/user/all/CO", method = RequestMethod.GET)
	@ResponseBody
	public Object getAllCargoOfficers() {
		ArrayList<User> pageUsers = null;
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(),
//					new String[] { "ADMIN", "CARGO OFFICER" })) {
//				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//						HttpStatus.FORBIDDEN);
//			}
			pageUsers = (ArrayList<User>) userRepo.findAllCargoOfficers("CARGO OFFICER");
			

		} catch (Exception e) {
			log.error("Unable to get all users,", e);
			return new Exception("Internal Server Error");
		}
		return pageUsers;
	}

	@RequestMapping(value = Utilities.APP_VERSION + "/user/{userId}", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Object> deleteUser(@PathVariable("userId") Long userId) {
		try {
			User currentUser = currentUserService.getCurrentUser();
			String currentUserRole = currentUser.getRoles().iterator().next().getRole();
			if (currentUserRole.equals("ADMIN") || currentUserRole.equals("MANAGER")) {
				userRepo.deleteById(userId);
			} else {
				log.error("Unable to delete user details ",
						new Exception("Beceause current user is unauthorized to modify user details"));
				return new ResponseEntity<Object>(new ResponseObject(403,
						"Unable to delete user details with id:" + userId + ", error:"
								+ new Exception("Beceause current user is unauthorized to modify user details"),
						null, true), HttpStatus.FORBIDDEN);
			}
		} catch (Exception e) {
			log.error("Unable to delete user with id:" + userId, e);
			return new ResponseEntity<Object>(new ResponseObject(500,
					"Unable to delete user with id:" + userId + ", error: " + e.getMessage(), null, true),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(new ResponseObject(200, "Deleted user with id:" + userId, null, true),
				HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/demo-sign-up", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> demoSingup(@Valid @RequestBody UserDTO userDto, Errors errors) {
		User user = null;
		try {
			user = new User(userDto, null);

			if (errors.hasErrors()) {
				// return Utilities.getValidationErrors(errors);
			}

			if (applicationUserRepository.findByEmail(user.getEmail()) != null) {
				log.error("UserName already taken",
						new Exception("UserName already taken, so you please try again with another username."));
				return new ResponseEntity<Object>(
						new ResponseObject(406,
								"UserName already taken, so you please try again with another username. ", null, true),
						HttpStatus.NOT_ACCEPTABLE);
			}
			if (applicationUserRepository.findByEmail(user.getEmail()) == null) {
				user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
				user = applicationUserRepository.save(user);
			} else {
				log.error("Email already exits", new Exception("Email already exits, so you please! sign-in."));
				return new ResponseEntity<Object>(new ResponseObject(406, "Email Already Exits!! ", null, true),
						HttpStatus.NOT_ACCEPTABLE);
			}
		} catch (ConstraintViolationException e) {
			log.error("Unable to add User, possible error: " + e);
			return new ResponseEntity<Object>(
					new ResponseObject(400,
							"Request Validation Error, Unable to add User, possible error: "
									+ e.getConstraintViolations().iterator().next().getMessageTemplate(),
							null, true),
					HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			log.error("Unable to add user, please try again!, posible error: ", e);
			return new ResponseEntity<Object>(
					new ResponseObject(500, "Unable to add  user, Please try again! ", null, true),
					HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Object>(new ResponseObject(200, "Signup created successfully", user, true),
				HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + "user/all/surveyor", method = RequestMethod.GET)
	@ResponseBody
	public Object getAllSurveyoresAsUser() throws Exception {
		List<User> surveyors = new ArrayList<>();
		try {
			for(String roleString : Arrays.asList("Incharge Surveyor","Attending Surveyor")) {
				UserRole role = roleRepository.findByRole(roleString);
				if(role!= null) {
					surveyors.addAll(applicationUserRepository.findByRoles(role));	
				}
			}
		} catch (Exception e) {
			log.error("Unable to get users whos containes role as surveyor,working_surveyor, possible error:", e);
			throw new Exception("Unable to get users whos containes role as surveyor,working_surveyor, possible error: "+e.getMessage());
		}
		return surveyors;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION + "/user/verify-email/{email}", method = RequestMethod.GET)
	@ResponseBody
	public PasswordChangeReqDTO getUserById(@PathVariable("email") String email) {
		PasswordChangeReqDTO dto = new PasswordChangeReqDTO();
		User user = null;
		try {
			user = userRepo.findByEmailIgnoreCase(email);
		} catch (Exception e) {
			log.error("Unable to get user with email:" + email, e);
		}
		
		if(user!= null && user.getEmail().equals(email) ) {
			dto.setEmail(user.getEmail());
			dto.setStatus(true);
		}
		return dto;
	}
	

	
	@RequestMapping(value = Utilities.APP_VERSION + "/user/update-password", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public PasswordChangeReqDTO setPasswordByEmail(@Valid @RequestBody PasswordChangeReqDTO passReqDTO) {
		User user = null;
		try {
			user = userRepo.findByEmailIgnoreCase(passReqDTO.getEmail());
			user.setPassword(bCryptPasswordEncoder.encode(passReqDTO.getPassword()));
			user.setRequiredToResetPassword(false);
			userRepo.save(user);

			passReqDTO.setStatus(true);
		} catch (Exception e) {
			log.error("Unable to get user with email:" + passReqDTO.getEmail(), e);
			passReqDTO.setStatus(false);
		}
		
		return passReqDTO;
	}
	
	@RequestMapping(value = Utilities.APP_VERSION + "/user/verify-internet-connection/{timestamp}", method = RequestMethod.GET)
	@ResponseBody
	public long getInternetConnection(@PathVariable("timestamp") String username) {
		return System.currentTimeMillis();
	}
	
	
	
}
