package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.joda.time.DateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name="bunker_safety_checklist_items") 
public class BunkerSafetyChecklistItems implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -11300308776453989L;

	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=true,name="item_name",length=500)
    private String itemName;
	
	@Column(nullable=true,name="yes_for_bunker", length=5)
    private String yesForBunker;
	
	@Column(nullable=true, name="yes_for_vessel", length=5)
    private String yesForVessel;
	
	@Column(nullable=true,name="remarks ",columnDefinition = "TEXT")
    private String remarks;
	
	@OneToMany(mappedBy="bunkerSafetyChecklistItems",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<GradeItems> gradeItems;
	
	
	@ManyToOne
	@JsonIgnore
    private BunkerSafetyChecklistData bunkerSafetyChecklist;

}
