package com.india.bts.dib.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.india.bts.dib.domain.Barge;
import com.india.bts.dib.domain.Job;

public interface BargeRepository extends JpaRepository<Barge, Long> {
	
	@Transactional
	@Modifying
	@Query(value="UPDATE barge SET is_default=0 WHERE id > 0", nativeQuery = true)
	void setAllUnDefault();
	
	Barge findByName(String name);

}
