package com.india.bts.dib.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="cargo_loading_data") 
public class CargoLoadingData implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6360097131484204275L;
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=true, name = "job_id", length=20)
	private long jobId;
	
	@Column(nullable=false, name = "po_number", length=500)
	private String poNumber;
	
	@Column(nullable=true, name = "barge_name", length=500)
	private String bargeName;
	
	@Column(nullable=true, name = "location_name", length=500)
	private String locationName;
	
	@Column(nullable=true, name = "grade", length=500)
	private String grade;

	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "loading_date_time", columnDefinition="DATETIME", nullable = true)
    LocalDateTime loadingDateTime;
	
	@Column(nullable=true, name = "cargo_owner", length=500)
	private String cargoOwner;
	@Column(nullable=true, name = "bl_no", length=500)
	private String bargeLicenseNumber;
	
	@Column(nullable=true, name = "blorcq_no", length=500)
	private String blOrcqNo;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "alongside_berth_datetime", columnDefinition="DATETIME", nullable = true)
    LocalDateTime berthAlongSideDateTime;
	

	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "commenced_loading_datetime", columnDefinition="DATETIME", nullable = true)
    LocalDateTime commencedLoadingDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "completed_loading_datetime", columnDefinition="DATETIME", nullable = true)
    LocalDateTime completedLoadingDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "barge_arrived_location_datetime", columnDefinition="DATETIME", nullable = true)
	LocalDateTime bargearrivedLocationDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "barge_left_location_datetime", columnDefinition="DATETIME", nullable = true)
	LocalDateTime bargeleftLocationDateTime;
	
	
	@Column(nullable=true,name="bl_qty",length=500)
    private String blQty;
	@Column(nullable=true,name="bl_viscosity",length=500)
    private String blviscosity;
	@Column(nullable=true,name="bl_coq_density",length=500)
    private String blcoqDensity; 
	@Column(nullable=true,name="bl_water_content",length=500)
    private String blwaterContent;
	@Column(nullable=true,name="bl_flash_point",length=500)
    private String blflashPoint;
	@Column(nullable=true,name="bl_sulphur_content",length=500)
    private String blsulphurContent;
	
	@Column(nullable=true,name="mfm_qty",length=500)
    private String mfmQty;
	@Column(nullable=true,name="mfm_viscosity",length=500)
    private String mfmviscosity;
	@Column(nullable=true,name="mfm_coq_density",length=500)
    private String mfmcoqDensity; 
	@Column(nullable=true,name="mfm_water_content",length=500)
    private String mfmwaterContent;
	@Column(nullable=true,name="mfm_flash_point",length=500)
    private String mfmflashPoint;
	@Column(nullable=true,name="mfm_sulphur_content",length=500)
    private String mfmsulphurContent;
	
	@Column(nullable=true,name="sounding_qty",length=500)
    private String soundingQty;
	@Column(nullable=true,name="s_viscosity",length=500)
    private String sviscosity;
	@Column(nullable=true,name="s_coq_density",length=500)
    private String scoqDensity; 
	@Column(nullable=true,name="s_water_content",length=500)
    private String swaterContent;
	@Column(nullable=true,name="s_flash_point",length=500)
    private String sflashPoint;
	@Column(nullable=true,name="s_sulphur_content",length=500)
    private String ssulphurContent;
	
	
	@Column(nullable=true,name="remarks ", columnDefinition = "TEXT")
    private String remarks;
	
	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	
	
	@Lob
	@Column(nullable=true,name="Cargo_file_binary")
	private String cargoFileBinary;
}
