package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.india.bts.dib.domain.BunkerRequisitionData;

public interface BunkerRequistionRepository extends JpaRepository<BunkerRequisitionData, Long> {
	
	BunkerRequisitionData findByJobId(long jobId);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE bunker_requisition_data SET req_file_binary=:req_file_binary WHERE job_id = :jobId ", nativeQuery=true)
	void updateBinaryData(@Param("req_file_binary") String req_file_binary,@Param("jobId") Long jobId);

	@Query(value="select temperature from  bunker_requisition_data WHERE job_id = :jobId ", nativeQuery=true)
	String getTemperatureByJobId(@Param("jobId") long jobId);
	
}
