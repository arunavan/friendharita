package com.india.bts.dib.dto;

import java.math.BigDecimal;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.india.bts.dib.domain.GradeType;
import com.india.bts.dib.domain.UomType;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class NominationDTO {
	
	@ApiModelProperty(notes = "Name of the grade", required = true )
	private String grade;
	
	@Enumerated(EnumType.STRING)
	private UomType uom;
	
	@ApiModelProperty(notes = "Quantity of the grade", required = true )
	private String quantity;
	
	@ApiModelProperty(notes = "type of the grade", required = true, example = "NOMINATED_GRADE, SUPPLYING_GRADE, RECEIVING_GRADE")
	@Enumerated(EnumType.STRING)
    private GradeType nominationType;
	
	private String mPAGrade;

	public String getmPAGrade() {
		return mPAGrade;
	}

	public void setmPAGrade(String mPAGrade) {
		this.mPAGrade = mPAGrade;
	}
	

}
