package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="date_time_test") 
public class DateTimeTest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=true,name="job_type",length=500)
    private String jobType;

	@ApiModelProperty(notes ="formate:yyyy-MM-dd", required = true, example = "2022-05-25")
    @JsonFormat(pattern="yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd") 
	@Column(name="nomination_date", columnDefinition = "DATE")
	LocalDate nominationDate;
    
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "created_date", columnDefinition="DATETIME")
    LocalDateTime createdDateTime;
	

}
