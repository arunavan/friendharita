package com.india.bts.dib.dto;

import java.util.List;

import lombok.Data;


@Data
public class BunkerDeliveryReportDTO {
	private List<Participants> participants;
	 
	private List<BunkerDeliveryReport> payload; 

	private List<OnBehalfOf> on_behalf_of;

}
