package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "mpa_published_delivery_jobs")
@Data
@NoArgsConstructor
public class BunkerDeliveryNoteToIbms implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="id")
	private Long id;
	@Column(name="barge_licence_no")
	private String bunkerTankerLicenceNo;
	@Column(name="barge_name")
	private String bunkerTankerName; 
	@Column(name ="bmt_number")
	private String bunkerMeteringTicketNo;
	@Column(name ="fuel_type_code")
	private String fuelTypeCode;
	@Column(name ="RefitemNo")
	private int refItemNo;
//	@Column(name ="start_delivery_meter_totaliser")
//	private String startDeliveryMeterTotaliser;
//	@Column(name ="start_loading_meter_totaliser")
//	private String startLoadingMeterTotaliser;
//	@Column(name ="end_delivery_meter_totaliser")
//	private String endDeliveryMeterTotaliser;
//	@Column(name ="end_loading_meter_totaliser")
//	private String endLoadingMeterTotaliser;
	@Column(name ="operation_date")
	private String operationDate;
	@Column(name ="totalisersAutoPopulated")
	private String totalisersAutoPopulated;
	@Column(name ="reasonNotAutoPopulated")
	private String reasonNotAutoPopulated;
	@Column(name ="supplier_name")
	private String bunkerSupplierName;
	@Column(name ="bunker_supplier_uen")
	private String bunkerSupplierUEN;
	@Column(name="bdn_number")
	private String bdnNo;
	@Column(name="vessel_name")
	private String receiveVesselName;
	@Column(name="vessel_imo")
	private String receiveVesselImoNo;
	@Column(name="density")
	private String density;
	@Column(name="flash_point")
	private String flashPoint;
	@Column(name="sulpher_content")
	private String sulpherContent;
	@Column(name="viscosity")
	private String viscosity;
	@Column(name="temperature")
	private String temperature;
	@Column(name="water_content")
	private String waterContent;
	@Column(name="cargoofficername")
	private String cargoOfficerName;
	@Column(name="gross_tonnage")
	private String receiveVesselGst;
	@Column(name ="code")
	private String deliveryLocationCode;
	@Column(name ="name")
	private String deliveryLocationName;
	@Column(name ="delivery_type")
	private String deliveryType;
	@Column(name ="supply_type")
	private String supplyType;
//	@Column(name ="mfm_supplied_quantity")
//	private String suppliedQuantityMFM;
	@Column(name ="bdn_supplied_quantity")
	private String suppliedQuantityBDN;
	@Column(name ="commence_pumping_time")
	private String commencePumpingTime;
	@Column(name ="complete_pumping_time")
	private String completePumpingTime;
	@Column(name ="alongside_time")
	private String alongsideTime;
//	@Column(name ="castoff_time")
//	private String castOffTime;
	@Column(name ="duration_of_delivery")
	private String durationOfDelivery;
	@Column(name ="customer_rating")
	private String customerRating;
	@Column(name ="protest_note")
	private String protestNote;
//	@Column(name ="bdn_file_binary")
//	private String bdnFile;
//	@Column(name ="mfm_file_binary")
//	private String mfmFile;
//	
	@Column(name ="lab_seal")
	private String labSeal;
	@Column(name ="lab_counter_seal")
	private String labCounterSeal;
	@Column(name ="lab_counter_seal_two")
	private String labCounterSeal2;
	
	@Column(name ="vessel_seal")
	private String vesselSeal;
	@Column(name ="vessel_counter_seal")
	private String vesselCounterSeal;
	@Column(name ="vessel_counter_seal_two")
	private String vesselCounterSeal2;
	
	
	@Column(name ="marpol_seal")
	private String marpolSeal;
	@Column(name ="marpol_counter_seal")
	private String marpolCounterSeal;
	@Column(name ="marpol_counter_seal_two")
	private String marpolCounterSeal2;
	
	
	@Column(name ="bunker_seal")
	private String bunkerSeal;
	@Column(name ="bunker_counter_seal")
	private String bunkerCounterSeal;
	@Column(name ="bunker_counter_seal_two")
	private String bunkerCounterSeal2;
	
	@Column(name ="surveyor_seal")
	private String surveyorSeal;
	@Column(name ="surveyor_counter_seal")
	private String surveyorCounterSeal;
	@Column(name ="surveyor_counter_seal_two")
	private String surveyorCounterSeal2;
	
	@Column(name ="stem_no")
	private String stemNo;
	
	
}
