package com.india.bts.dib.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.india.bts.dib.domain.BunkerSafetyChecklistData;

public interface BunkerSafetyChecklistRepository extends JpaRepository<BunkerSafetyChecklistData, Long> {
	
	BunkerSafetyChecklistData findByJobId(long jobId);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE bunker_safety_checklist_data SET safety_file_binary=:safety_file_binary WHERE job_id = :jobId ", nativeQuery=true)
	void updateBinaryData(@Param("safety_file_binary") String safety_file_binary,@Param("jobId") Long jobId);
}
