/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _______________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.india.bts.dib.utils.Utilities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity(name = "email_content")
public class EmailContent implements Serializable{
	private static final long serialVersionUID = -7193532295502363311L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "from_email_id",nullable=false)
	private String fromEmailId;
	
	@Column(nullable=false,name = "to_email_id", columnDefinition = "TEXT")
	private String toEmailId;
	
	@Column(name = "cc_Email_id",columnDefinition = "TEXT")
	private String ccEmailId;
	
	@Column(name = "bcc_email_id",columnDefinition = "TEXT")
	private String bccEmailId;

	@Column(nullable=false,name = "subject", columnDefinition = "TEXT")
	private String subject;

	@Column(nullable=false, name = "body",columnDefinition = "TEXT")
	private String body;
	
	@Column(nullable=true, name = "job_id")
	private Long jobId;
	
	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	public EmailContent(Long id) {
		this.id = id;
	}

	public String getCreatedDateTime() {
		if(createdDate == null)
			return null;
		else
			return createdDate.toString("yyyy-MM-dd HH:mm:ss");
	}

	public void refreshDate()
	{
		if(StringUtils.isNotBlank(body))
		{
			if(StringUtils.containsIgnoreCase(body, "^^DATE^^"))
			{
				this.body = StringUtils.replace(body, "^^DATE^^", Utilities.getTodaysDate());
			}
			else if(StringUtils.containsIgnoreCase(body, "DD:"))
			{
				String dt= StringUtils.substringBetween(body, "DD:", "</p>");
				if(StringUtils.isBlank(dt))
				{
					dt = StringUtils.substringBetween(body, "Dd:", "</p>");
				}
				this.body = StringUtils.replace(body, dt, "<b> "+Utilities.getTodaysDate()+"</b>");

			}
		}
	}

	public EmailContent(EmailContent emailBody) {
		this.bccEmailId = emailBody.getBccEmailId();
		this.body = emailBody.getBody();
		this.ccEmailId = emailBody.getCcEmailId();
		this.fromEmailId = emailBody.getFromEmailId();
		this.subject = emailBody.getSubject();
		this.toEmailId = emailBody.getToEmailId();
		this.createdDate = DateTime.now(); 

	}

}
