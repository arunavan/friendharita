package com.india.bts.dib.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.india.bts.dib.domain.CargoLoadingData;
import com.india.bts.dib.domain.MeterTotaliserLog;

@Repository
public interface MeterTotaliserLogRepository extends JpaRepository<MeterTotaliserLog, Long> {
	
	List<MeterTotaliserLog> findByBargeId(long bargeId);
	MeterTotaliserLog findByJobId(long jobId);



}
