package com.india.bts.dib.dto;

import java.time.LocalDateTime;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Lob;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class BunkerRequistionDTO {
	
	private String jobId;
	private String vesselName;
	private String locationName;
	private String fuelOilQty;
	private String fuelOilCst;
	private String gasOilQty;
	private String nominatedGrade;
	private boolean blendedOnboardInAdvance;
	private String viscosity;
	private String density;
	private String waterContent;
	private String flashPoit;
	private String sulpherContent;
	private String fuelSupplyFirst;
	private String fuelSupplyNext;
	private String deliveryTemperature;
	private String requiredPumpingRateFuelOil;
	private String requiredPumpingRateGasOil;
	private boolean witnessMeterReadings;
	private boolean witnessSamplingOnVessel;
	private boolean allowPumpingToClearHose;
	private boolean vesselUnderFQTProgramme;
	private String cargoOfficerName;
	private String chiefEngineerName;
	private String surveyorName;
	private String reqFileBinary;
	private String mPAGrade;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    LocalDateTime bunkerStampDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    LocalDateTime vesselStampDateTime;

	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    LocalDateTime companyStampDateTime;

	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    LocalDateTime samplingSignatureCargoOfficerDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    LocalDateTime samplingSignatureChiefEngineerDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    LocalDateTime samplingSignatureSurveyorDateTime;
	
}
