/*******************************************************************************
 * BTS INDIA COPYRIGHT
 * ___________________
 *   
 * [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 * All Rights Reserved.
 *   
 * NOTICE:  All information contained herein is, and remains
 * the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 * and its suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/

package com.india.bts.dib.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="jobs") 
public class Job implements Serializable{

	private static final long serialVersionUID = 1L;
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ApiModelProperty(notes = "specify the jobtype", required = true, example = "loading, delivery, transfer")
	@Column(nullable=false,name="job_type",length=50)
	@Enumerated(EnumType.STRING)
    private JOBTYPE jobType;
	
	@Column(name = "status" , nullable = false, columnDefinition = "varchar(255) default 'CREATED'")
	@Enumerated(EnumType.STRING)
    private StatusType status;
	
	
	@ApiModelProperty(notes = "Stem Number", required = true )
	@Column(nullable=true,name="stem_no",length=500)
    private String stemNo;
	@ApiModelProperty(notes = "Name of the Vessel", required = false )
	@Column(nullable=true,name="vessel_name",length=500)
    private String vesselName;
	@ApiModelProperty(notes = "IMO number of the Vessel", required = false )
	@Column(nullable=true,name="vessel_imo",length=500)
    private String vesselIMO;
	@ApiModelProperty(notes = "Vessel email", required = false )
	@Column(nullable=true,name="vessel_eamil",length=500)
    private String vesselEmail;
	@ApiModelProperty(notes = "Surveyor email", required = false )
	@Column(nullable=true,name="surveyor_eamil",length=500)
    private String surveyorEmail;
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(nullable = true, name = "vessel_alongside_time", columnDefinition="DATETIME")
	private LocalDateTime vesselAlongSideTime;
	@Column(name="bdn_party_id", nullable = true)
	private Long bdnPartyId;
	@ApiModelProperty(notes = "No.of emails with C/E login details sent to Vessel email", required = false )
	@Column(name="vessel_email_send_count", nullable = false)
	private Long vesselEmailSendCount = 0L;

	@ApiModelProperty(notes = "No.of emails with Surveyor login details sent to Surveyor email", required = false )
	@Column(name="surveyor_email_send_count", nullable = false)
	private Long surveyorEmailSendCount = 0L;

	@Column(name="bdn_party_name")
	private String bdnPartyName;

	@ApiModelProperty(notes = "Port name", required = true )
	@Column(nullable=true,name="port",length=500)
    private String port;
	
	@ApiModelProperty(notes = "Location name", required = true )
	@Column(nullable=true,name="location",length=500)
    private String location;
	
	@Column(name="barge_id", nullable = false)
	private Long bargeId;
	
	@ApiModelProperty(notes = "Name of the bare ", required = true )
	@Column(nullable=true,name="barge_name",length=500)
    private String bargeName;
	@ApiModelProperty(notes = "Barge licence number", required = true )
	@Column(nullable=true,name="barge_licence_no",length=500)
    private String bargeLicenceNo;
	@ApiModelProperty(notes = "Barge pumping rate", required = true )
	@Column(nullable=true,name="barge_pumping_rae",length=500)
    private String bargePumpingRate;
	
	@ApiModelProperty(notes = "Bunkering operation type", required = true )
	@Column(nullable=true,name="operation_type",length=500)
    private String operationType;

	@Column(nullable=true,name="customer",length=500)
    private String customer;
	@Column(nullable=true,name="agent",length=500)
    private String agent;
	@Column(nullable=true,name="agent_contact_no",length=500)
    private String agentContactNo;

	@Column(nullable=true,name="chief_engineer",length=500)
    private String chiefEngineer;
	
	
	@Column(nullable=true,name="surveyor",length=500)
    private String surveyor;
	
	@Column(nullable=true,name="cargo_officer",length=500)
    private String cargoOfficer;
	@Column(nullable=true,name="cargo_officer_email",length=500)
    private String cargoOfficerEmail;

	//Purchase Order
	@ApiModelProperty(notes = "Purchase order number", required = true )
	@Column(nullable=true,name="purchase_order_no",length=500)
    private String purchaseOrderNo;

	@Column(nullable=true,name="nomination_no",length=500)
    private String nominationNo;

	@Column(nullable=true,name="terminal_berth_anchorage",length=500)
    private String terminal;
	
	@Column(nullable=true,name="cargo_owner",length=500)
    private String cargoOwner;
	
	//Transfer Order
	
	@Column(nullable=true,name="transfer_order_no",length=500)
    private String transferOrderNo;
	
	@ApiModelProperty(notes = "From Barge", required = true)
	@Column(nullable = true, name = "from_barge", length = 500)
	private String fromBarge;

	@ApiModelProperty(notes = "To Barge", required = true)
	@Column(nullable = true, name = "to_barge", length = 500)
	private String toBarge;	
	
	@Column(nullable = true,name = "print_bdn", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean printBdn;

	// common to all
	
	@ApiModelProperty(notes = "formate:yyyy-MM-dd", required = true, example = "2022-05-25")
	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(nullable = true, name = "nomination_date", columnDefinition="DATE")
	private LocalDate nominationDate;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(nullable = true, name = "nomination_date_time", columnDefinition="DATETIME")
    LocalDateTime nominationDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = true, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(nullable = true, name = "eta_date_time", columnDefinition="DATETIME")
	private LocalDateTime eta;
	
	@OneToMany(mappedBy="job",fetch = FetchType.EAGER, cascade = CascadeType.MERGE)
	private List<Nomination> nominations;
	
	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	
	
	@Column(name="year")
	private Long year;
	
	@Column(name="month")
	private String month;
	
	@Column(name="mpa_publish_status", columnDefinition = "varchar(100) default 'PENDING'")
	private String mpaPublishStatus;

	@Column(name="mpa_publish_error_msg")
	private String mpaPublishErrorMsg;

	@Column(name="mpa_publish_request", columnDefinition = "TEXT")
	private String mpaPublishRequest;
	
	@Column(name="mpa_publish_response", columnDefinition = "TEXT")
	private String mpaPublishResponse;

	@Column(name="sgtradex_publish_status", columnDefinition = "varchar(100) default 'PENDING'")
	private String sgtradexPublishStatus;

	@Column(name="sgtradex_publish_error_msg")
	private String sgtradexPublishErrorMsg;
	
	@Column(name="sgtradex_publish_request", columnDefinition = "TEXT")
	private String sgtradexPublishRequest;

	@Column(name="sgtradex_publish_response", columnDefinition = "TEXT")
	private String sgtradexPublishResponse;
	
	@Column(name="blockchain_registration_status", columnDefinition = "varchar(100) default 'PENDING'")
	private String blockchainRegistrationStatus;

	@Column(name="blockchain_registration_error_msg")
	private String blockchainRegistrationErrorMsg;
	
	@Column(name="blockchain_registration_response", columnDefinition = "TEXT")
	private String blockchainRegistrationResponse;
	
	@Column(name="blockchain_file_id", columnDefinition = "TEXT")
	private String blockchainFileId;
	
	@Column(name="client")
	private String client;
	
	@Column(name="mode",columnDefinition = "INT(1) DEFAULT 1")
	private int mode;
	
	@Column(name="isvesselverified",columnDefinition = "INT(1) DEFAULT 0")
	private int isVesselVerified;
	@Column(nullable = true, name = "contigencyRemarks", length = 500)
	private String contigencyRemarks;
	
	@Column(name="doc_sent_status")
	private String docSentStatus;
	
	@Column(name="contigency_ce_verified")
	private int contigencyCeVerified;
	
	@Column(name="contigency_ce_emailfailed")
	private int contigencyCeEmailFailed;
	
	@Column(name="contigency_ce_accessfailed")
	private int contigencyCeAccessFailed;
	
	@Column(name ="contigency_ce_loginfailed")
	private int contigencyCeLoginFailed;
	
	@Column(name ="contigency_ce_approval_supervisor")
	private int contigencyCeApprovalSupervisor;
	
	@Column(name ="Is_Updated")
	private int is_Updated;
	
	@Column(name="SourceType")
	private String sourceType;
	
	@Column(nullable=true,name = "min_capacity")
	private BigDecimal minCapacity;

	@Column(nullable=true,name = "max_capacity")
	private BigDecimal maxCapacity;
	
	@Column(name ="Fuel_CategoryId")
	private Long fuelCategoryId;
	
	
}


