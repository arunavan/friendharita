package com.india.bts.dib.service;

import java.util.List;

import com.india.bts.dib.domain.BDNData;
import com.india.bts.dib.domain.BunkerRequisitionData;
import com.india.bts.dib.domain.BunkerSafetyChecklistData;
import com.india.bts.dib.domain.BunkerTransferData;
import com.india.bts.dib.domain.CargoLoadingData;
import com.india.bts.dib.domain.DiscrepancyData;
import com.india.bts.dib.domain.ESignaturesData;
import com.india.bts.dib.domain.JOBTYPE;
import com.india.bts.dib.domain.Job;
import com.india.bts.dib.domain.MFMReadingData;
import com.india.bts.dib.domain.MFMSealsChecklistData;
import com.india.bts.dib.domain.NOPData;
import com.india.bts.dib.domain.OcrResult;
import com.india.bts.dib.domain.Sof;
import com.india.bts.dib.domain.TaskType;
import com.india.bts.dib.domain.TimelogData;

public interface JobService {
	
	public abstract Job createJob(Job job);
	public abstract Job updateJob(Job job);
	public abstract Job updateOnlyJob(Job job);
	
//	public abstract Optional<Job> getById(long jobId);
	public abstract Job getById(long jobId);
	public abstract Job getOrderById(long id);

	public abstract List<Job> getAll();
	public abstract List<Job> getAllByJobType(JOBTYPE jobType);
	
	public abstract void delete(long jobId);
	
	public abstract Job findByStemNo(String stemNo);
	public abstract Job findByPurchaseOrderNo(String purchaseOrderNo);
	public abstract Job findByTransferOrderNo(String transferOrderNo);
	public abstract Job findByTransferOrderNoAndJobType(String transferOrderNo, JOBTYPE jobType);

	
	public BunkerRequisitionData createBunkerRequisition(BunkerRequisitionData bunkerRequisitionData) throws Exception;
	public BunkerRequisitionData updateBunkerRequisition(BunkerRequisitionData bunkerRequisitionData) throws Exception;
	public BunkerRequisitionData getBunkerRequisition(long jobId);

	public BunkerSafetyChecklistData createBunkerSafetyChecklist(BunkerSafetyChecklistData bunkerSafetyChecklistData) ;
	public BunkerSafetyChecklistData updateBunkerSafetyChecklist(BunkerSafetyChecklistData bunkerSafetyChecklistData) ;
	public BunkerSafetyChecklistData getBunkerSafetyChecklist(long jobId) ;

	public MFMSealsChecklistData createMFMSealsChecklist(MFMSealsChecklistData mFMSealsChecklistData);
	public MFMSealsChecklistData updateMFMSealsChecklist(MFMSealsChecklistData mFMSealsChecklistData);
	public MFMSealsChecklistData getMFMSealsChecklist(long jobId);

	public TimelogData createTimeLogData(TimelogData timelogData);
	public TimelogData updateTimelogData(TimelogData timelogData);
	public TimelogData getTimelogData(long jobId);

	public MFMReadingData createMFMReadingData(MFMReadingData mfmReadingData);
	public MFMReadingData updateMFMReadingData(MFMReadingData mfmReadingData);
	public MFMReadingData getMFMReadingData(long jobId);
	   
	public Sof createSOFData(Sof sofData);
	public Sof updateSOFData(Sof sofData);
	public Sof getSOFData(long jobId);
	
	public ESignaturesData createESignData(ESignaturesData eSignData);
	public ESignaturesData updateESignData(ESignaturesData eSignData);
	public ESignaturesData getESignData(long jobId);

	public BDNData createBDNData(BDNData bdnData);
	public BDNData updateBDNData(BDNData bdnData);
	public BDNData getBDNData(long jobId);
	
	public NOPData createNOPData(NOPData bdnData);
	public NOPData updateNOPData(NOPData bdnData);
	public NOPData getNOPData(long jobId);
	
	public DiscrepancyData createDiscrepancyData(DiscrepancyData bdnData);
	public DiscrepancyData updateDiscrepancyData(DiscrepancyData bdnData);
	public DiscrepancyData getDiscrepancyData(long jobId);
	
	public BunkerTransferData createBunkerTransferData(BunkerTransferData bdnData);
	public BunkerTransferData updateBunkerTransferData(BunkerTransferData bdnData);
	public BunkerTransferData getBunkerTransferData(long jobId);
	
	public CargoLoadingData createCargoLoadingData(CargoLoadingData bdnData);
	public CargoLoadingData updateCargoLoadingData(CargoLoadingData bdnData);
	public CargoLoadingData getCargoLoadingData(long jobId);
	
	public OcrResult createOcrResult(OcrResult result);
	public OcrResult updateOcrResult(OcrResult result) throws Exception;
	public OcrResult getOcrResult(long id);

	
	Job updateJobStatus(String status, Long jobId);
	
	Job findAndUpdateBargeData(Job job) throws RuntimeException;
	Job findAndUpdateBdnParty(Job job);
	Job findAndUpdateLocation(Job job);
	
	public void createThreadToSendEmail(Job job, TaskType taskType);



}
