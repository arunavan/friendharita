package com.india.bts.dib.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.SealCategory;
import com.india.bts.dib.domain.SequenceNumber;
import com.india.bts.dib.repository.SequenceNumberRepository;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class SequenceNumberGenerator {
	
	@Autowired
	SequenceNumberRepository sequenceNumberRepository;
	
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ "/sequence-number", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getNextNumber() {
		SequenceNumber sequenceNumber = null;
		try {
			Optional<SequenceNumber>  seqNumber = sequenceNumberRepository.findById(new Long(1));
			if(seqNumber.isPresent()) {
				sequenceNumber = seqNumber.get();
				sequenceNumber.setSequenceNumber(sequenceNumber.getSequenceNumber()+1);
			}else {
				sequenceNumber = new SequenceNumber();
				sequenceNumber.setSequenceNumber(new Long(900100));
			}
			
			sequenceNumber = sequenceNumberRepository.save(sequenceNumber);
			
		} catch (Exception e) {
			log.error("Unable to update or generate sequenceNumber", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(sequenceNumber, HttpStatus.OK);
	}


}
