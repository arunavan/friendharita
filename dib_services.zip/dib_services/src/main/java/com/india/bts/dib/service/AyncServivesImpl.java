package com.india.bts.dib.service;

import java.io.ByteArrayOutputStream;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;


import com.india.bts.dib.domain.Reports;
import com.india.bts.dib.repository.BDNPartyRepository;
import com.india.bts.dib.repository.BunkerRequistionRepository;
import com.india.bts.dib.repository.BunkerSafetyChecklistRepository;
import com.india.bts.dib.repository.CargoLoadingDataRepository;
import com.india.bts.dib.repository.MFMReadingDataRepository;
import com.india.bts.dib.repository.MFMSealsChecklistRepository;
import com.india.bts.dib.repository.NOPDataRepository;
import com.india.bts.dib.repository.ReportsRepository;
import com.india.bts.dib.repository.SOFDataRepository;
import com.india.bts.dib.repository.TimelogChecklistRepository;
//import com.lowagie.text.pdf.PdfDocument;


import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

@Service
public class AyncServivesImpl implements AsynServices{
	
	@Value("${spring.datasource.url}")
	private String Url;
	@Value("${spring.datasource.username}")
	private String userName;
	@Value("${spring.datasource.password}")
	private String password; 
	
	@Autowired
	BDNPartyRepository bdnPartyRepository;
	
	@Autowired
	BunkerRequistionRepository bunkerRequistionRepository;
	
	@Autowired
	MFMSealsChecklistRepository mfmSealsChecklistRepository;
	
	@Autowired
	MFMReadingDataRepository mfmReadingRepository;
	
	@Autowired
	BunkerSafetyChecklistRepository bunkerSafetyChecklistRepository;
	@Autowired
	SOFDataRepository sOFDataRepository;
	
	@Autowired
	FileStorageService fileService;
	@Autowired
	CargoLoadingDataRepository cargoLoadingDataRepository;
	
	@Autowired
	NOPDataRepository nOPDataRepository;
	
	@Autowired
	TimelogChecklistRepository timelogChecklistRepository;
	
	@Autowired
	ReportsRepository reportsRepository;
	
	@Async
	@Override
	public void generateBinaryData(Long job_id,String reportPath,String printName,int moduleId,int transactionId) {
		byte[] dataList = null;
		String targetPath="";
		Resource fileResource=null;
		String folderName="";
		Reports report = new Reports();
		try {
		 Connection con = DriverManager.getConnection(Url, userName, password);
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("job_id",job_id);		
		JasperReport compileReport = JasperCompileManager
				.compileReport(new FileInputStream(reportPath));
		JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, parameters,con);
		dataList = JasperExportManager.exportReportToPdf(jasperPrint);
		String encodedString = Base64.getEncoder().encodeToString(dataList);
		System.out.print(encodedString);
		//uploadBinaryData(encodedString,job_id,printName);
		
		//implement the report table to insert the binary data seperately to increase the performance
		
		saveAttachment(job_id,moduleId,1,encodedString,printName,transactionId);
		
		if(printName.equals("ebdn")) {
			folderName ="Bunker DeliveryNote.pdf";
		}else if(printName.equals("breq")) {
			folderName="Bunker Requisition.pdf";
		}else if(printName.equals("safety")) {
			folderName="Bunker Safety Checklist.pdf";
		}else if(printName.equals("mfm")) {
			folderName="MFM Meter Reading.pdf";
		}else if (printName.equals("seals")) {
			folderName="MFM Seals Checklist.pdf";
		}else if(printName.equals("nop")){
			folderName="Note of Protest.pdf";
		}else if(printName.equals("cargoloading")){
			folderName="CargoLoading.pdf";
		}else if(printName.equals("timelog")){
			folderName="TimeLog.pdf";
		}else if(printName.equals("sof")){
			folderName="SOF.pdf";
		}
		
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		buffer.write(dataList);
		targetPath =fileService.storeFile(folderName, buffer,job_id);
		//compressPdf(targetPath);
		fileResource=fileService.loadFileAsResource(targetPath);
		
		}catch (Exception ex) {
			//throw ex;
		}

	}
	
	public void uploadBinaryData(String data, Long jobId,String printName) {		
		try {
			if(printName.equals("ebdn")) {
				bdnPartyRepository.updateBinaryData(data, jobId);
				
			}else if(printName.equals("breq")) {
				bunkerRequistionRepository.updateBinaryData(data, jobId);
				;
			}else if(printName.equals("safety")) {
				bunkerSafetyChecklistRepository.updateBinaryData(data, jobId);
			}else if(printName.equals("mfm")) {
				mfmReadingRepository.updateBinaryData(data, jobId);
			
			}else if (printName.equals("seals")) {
				mfmSealsChecklistRepository.updateBinaryData(data, jobId);
			}else if (printName.equals("nop")) {
				nOPDataRepository.updateBinaryData(data, jobId);
			}else if (printName.equals("cargoloading")) {
				cargoLoadingDataRepository.updateBinaryData(data, jobId);
			}else if(printName.equals("timelog")){
				timelogChecklistRepository.updateBinaryData(data, jobId);
			}else if(printName.equals("sof")){
				sOFDataRepository.updateBinaryData(data, jobId);
			}
		
   }catch(Exception ex) {
	   //throw ex;
   }
	}
//	public void compressPdf(String targetpath) {
//		PdfDocument document = new PdfDocument();
//		document.loadFromFile(targetpath);
//		document.getFileInfo().setIncrementalUpdate(false);
//		document.setCompressionLevel(PdfCompressionLevel.Best);
//		document.getFileInfo().setIncrementalUpdate(false);
//
//	        //Traverse all pages
//	        for (int i = 0; i < document.getPages().getCount(); i++) {
//	            PdfPageBase page = document.getPages().get(i);
//	            if (page != null) {
//	                if (page.getImagesInfo() != null) {
//	                    for (int j = 0; j < page.getImagesInfo().length; j++) {
//	                        PdfImageInfo info = page.getImagesInfo()[j];
//	                        page.tryCompressImage(info.getIndex());
//	                    }
//	                }
//	            }
//	        }
//		document.saveToFile(targetpath, FileFormat.PDF);
//		document.close();
//	}
	
	public void saveAttachment(Long job_id,int moduleId,int reportId,String binaryData,String printName,int transactionId) {
		Reports report = new Reports();
		try {
//			report =reportsRepository.findByJobIdAndReportName(job_id,printName);
//			if(report != null) {
//				reportsRepository.updateBinaryData(job_id,printName,binaryData);
//			}
//			else {
				Reports reportNew = new Reports();
				reportNew.setJobId(job_id);
				reportNew.setModuleId(moduleId);
				reportNew.setReportId(reportId);
				reportNew.setReportFileBinary(binaryData);
				reportNew.setReportName(printName);
				reportNew.setTransactionId(transactionId);
				reportsRepository.deleteByJobIdAndReportName(job_id,printName);
				reportsRepository.save(reportNew);
			//}
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		
	}
	
	

}
