package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity(name="bunker_safety_checklist_data") 
public class BunkerSafetyChecklistData implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6360097131484204212L;
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20)
	private long jobId;
	@Column(nullable=false, name = "vessel_name", length=200)
	private String vesselName;
	@Column(nullable=false, name = "vessel_imo", length=200)
	private String vesselImo;
	@Column(nullable=false, name = "location_name", length=200)
	private String locationName;
	@Column(nullable=false, name = "bunker_tanker_name", length=200)
	private String bunkerTankerName;
	@Column(nullable=true, name = "agent_name", length=200)
	private String agentName;
	@Column(nullable=false, name = "port", length=200)
	private String port;
	@Column(nullable=true, name = "cargo_officer_name", length=200)
	private String cargoOfficer;
	@Column(nullable=true, name = "chief_enineer_name", length=200)
	private String chiefEngineer;
	@Column(nullable=true, name = "surveyor_name", length=200)
	private String surveyor;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd", required = false, example = "2022-05-25")
    @JsonFormat(pattern="yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd") 
    @Column(name = "bunker_safety_checklist_date", columnDefinition="DATE", nullable = true)
    LocalDate bunkerSafetyChecklistDate;

	
	@OneToMany(mappedBy="bunkerSafetyChecklist",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<BunkerSafetyChecklistItems> checklistItems;
	
	

	@Column(nullable=true, name = "co_pre_sign_datetime", length=200)
	private String coPreSignDateTime;
	@Column(nullable=true, name = "co_post_sign_datetime", length=200)
	private String coPostSignDateTime;
	@Column(nullable=true, name = "ce_pre_sign_datetime", length=200)
	private String cePreSignDateTime;
	@Column(nullable=true, name = "ce_post_sign_datetime", length=200)
	private String cePostSignDateTime;
	@Column(nullable=true, name = "sur_pre_sign_datetime", length=200)
	private String surPreSignDateTime;
	@Column(nullable=true, name = "sur_post_sign_datetime", length=200)
	private String surPostSignDateTime;
	

	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	@Lob
	@Column(nullable=true,name="safety_file_binary")
	private String safetyFileBinary;
	
	@Lob
	@Column(nullable=true,name="CO_Sign")
	private String cOSign;
	public String getcOSign() {
		return cOSign;
	}
	public void setcOSign(String cOSign) {
		this.cOSign = cOSign;
	}
	public String getcESign() {
		return cESign;
	}
	public void setcESign(String cESign) {
		this.cESign = cESign;
	}
	public String getsVSign() {
		return sVSign;
	}
	public void setsVSign(String sVSign) {
		this.sVSign = sVSign;
	}
	@Lob
	@Column(nullable=true,name="CE_Sign")
	private String cESign;
	@Lob
	@Column(nullable=true,name="SV_Sign")
	private String sVSign;

}
