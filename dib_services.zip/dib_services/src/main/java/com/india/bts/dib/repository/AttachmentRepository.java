package com.india.bts.dib.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import com.india.bts.dib.domain.Attachment;
import com.india.bts.dib.domain.AttachmentNoContent;
import com.india.bts.dib.domain.File;
import com.india.bts.dib.domain.UserRole;


public interface AttachmentRepository extends PagingAndSortingRepository<Attachment, Long> {
	
	List<Attachment> findByJobId(long jobId);
	
	List<Attachment> findByJobIdAndWorkflow(Long jobId, String string);

	Attachment findByJobIdAndFileName(Long jobId,String fileName);

	@Query(value ="SELECT id,file_name from attachment WHERE workflow not in ('VESSEL_STAMPS','SURVEYOR_STAMPS') AND jobId =:jobId ", nativeQuery=true)
	List<Object[]> getFileNames(@Param("jobId") Long jobId);



}
