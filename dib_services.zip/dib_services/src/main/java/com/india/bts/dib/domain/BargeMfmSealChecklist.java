package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@NoArgsConstructor
@Entity(name = "barge_mfm_seal_checklist")
public class BargeMfmSealChecklist implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -798225301680252457L;
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(nullable=false, name = "barge_id", length=200)
	private Long bargeId;
	
	@Column(nullable=false, name = "seal_category", length=200)
	@NotBlank
	private String sealCategory;
	
	@Column(nullable=false, name = "seal_location", length=200)
	@NotBlank
	private String sealLocation;
	
	@Column(nullable=false, name = "tag_number", length=200)
	@NotBlank
	private String tagNumber;
	
	@Column(nullable=false, name = "seal_number", length=200)
	@NotBlank
	private String sealNumber;
	
	@Column(nullable=true, name = "remarks", length=2500)
	private String remarks;
	
	@Column(nullable=false, name = "verification_report_number",  length=2500)
	private String verificationReportNumber;
	
	
	@ApiModelProperty(notes = "formate:yyyy-MM-dd", required = true, example = "2022-05-25")
	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(nullable=false, name = "verification_report_date", length=2500)
	private LocalDate verificationReportDate;
	
	@Column(nullable = true, name = "is_default", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean itDefault;
	
	
	
	
	

}
