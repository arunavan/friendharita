package com.india.bts.dib.domain.ocr;

import lombok.Data;
@Data
public class Word {

public String WordText;
public Integer Left;
public Integer Top;
public Integer Height;
public Integer Width;

}