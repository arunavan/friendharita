package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity(name = "note_of_protest_data")
public class NOPData implements Serializable {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20)
	private long jobId;
	
	@Column(nullable=true, name = "barge")
	private String barge;
	
	@Column(nullable=true, name = "barge_licence_no")
	private String bargeLicenceNo;
	
	@Column(nullable=true, name = "vessel_name")
	private String vesselName;
	
	@Column(nullable=true, name = "nominated_qty")
	private String nominatedQty;
	
	@Column(nullable=true, name = "nominated_grade")
	private String nominatedGrade;
	
	@Column(nullable=true, name = "nop_date")
	private String nopDate;
	
	@Column(nullable=true, name = "operation_date")
	private String operationDate;


	@Column(nullable=true,name="operation_start_hours")
	String operationStartHours;
	
	@Column(nullable=true,name="operation_end_hours")
	String operationEndHours;
	
	@Column(nullable=true,name="received_qty")
	String receivedQty;

	
	@Column(nullable=true, name = "jetty_no")
	private String jettyNo;
	
	@Column(nullable=true, name = "coq_qty")
	private String coqQty;
	
	
	@Column(nullable=true, name = "bdn_number")
	private String bdnNumber;
	
	@Column(nullable=true, name = "bdn_to")
	private String bdnTo;
	
	@Column(nullable=true, name = "location")
	private String location;


	@CreatedDate
	@Column(nullable=true, name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable=true, name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true, name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true, name = "updated_by", length=500)
	private String updatedUser;
	
	@Column(nullable=true, name = "co_pre_sign_datetime", length=200)
	private String coPreSignDateTime;
	
	@Column(nullable=true, name = "sur_pre_sign_datetime", length=200)
	private String surPreSignDateTime;
	
	@Column(nullable=true, name = "ce_pre_sign_datetime", length=200)
	private String cePreSignDateTime;

	@Column(nullable=true, name = "cargoofficername", length=250)
	private String cargoOfficer;
	@Column(nullable=true, name = "chiefengineername", length=250)
	private String chiefEngineer;
	@Column(nullable=true, name = "surveyorname", length=250)
	private String surveyor;
	
	@Lob
	@Column(nullable=true,name="nop_file_binary")
	private String nopFileBinary;
	
	@Lob
	@Column(nullable=true,name="CO_Sign")
	private String cOSign;
	@Lob
	@Column(nullable=true,name="CE_Sign")
	private String cESign;
	@Lob
	@Column(nullable=true,name="SV_Sign")
	private String sVSign;

	public String getcOSign() {
		return cOSign;
	}

	public void setcOSign(String cOSign) {
		this.cOSign = cOSign;
	}

	public String getcESign() {
		return cESign;
	}

	public void setcESign(String cESign) {
		this.cESign = cESign;
	}

	public String getsVSign() {
		return sVSign;
	}

	public void setsVSign(String sVSign) {
		this.sVSign = sVSign;
	}
	
	@Column(nullable=true,name="additional_Remarks")
	private String additionalRemarks;
	

}
