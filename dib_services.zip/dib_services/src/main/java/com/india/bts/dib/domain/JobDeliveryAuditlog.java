package com.india.bts.dib.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Entity(name = "Job_Delivery_Auditlog")
@Data
public class JobDeliveryAuditlog {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private Long id;
	@Column(name="Job_Id")
	private Long jobId;
	@Column(name ="Is_Sync")
	private int isSync;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "Pull_Date", nullable = true)
    LocalDateTime pullDate;

}
