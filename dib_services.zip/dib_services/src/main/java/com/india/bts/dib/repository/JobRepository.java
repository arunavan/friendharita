package com.india.bts.dib.repository;

import java.util.List;


import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.india.bts.dib.domain.JOBTYPE;
import com.india.bts.dib.domain.Job;

public interface JobRepository extends JpaRepository<Job, Long> {
	
	
	@Query(value="SELECT * FROM jobs where job_type in ('transfer_in', 'transfer_out')", nativeQuery=true)
	List<Job> findForTransferJobs();
	
	@Query(value="SELECT * FROM jobs where job_type in ('transfer_in', 'transfer_out') and barge_id= ?1", nativeQuery=true)
	List<Job> findForTransferJobsAndBargeId(Long bargeId);

	
	List<Job> findByJobType(JOBTYPE jobType);
	List<Job> findByJobTypeAndBargeId(JOBTYPE jobType, Long bargeId);
	
	@Query(value="select* from jobs where job_type = :jobType  and status != 'created' and jobs.vessel_eamil= :vessel_eamil ", nativeQuery=true)
	List<Job> getData(@Param("jobType") String jobType,@Param("vessel_eamil") String vessel_eamil);
	
	@Query(value="SELECT * FROM jobs where job_type in ('transfer_in', 'transfer_out')  and status != 'created' and jobs.vessel_eamil= :vessel_eamil", nativeQuery=true)
	List<Job> getDataForTransfer(@Param("vessel_eamil") String vessel_eamil);

	@Query(value="select * from jobs where job_type = :jobType and status != 'created' and jobs.surveyor_eamil= :surveyor_eamil", nativeQuery=true)
	List<Job> getSurveyorData(@Param("jobType") String jobType,@Param("surveyor_eamil") String surveyor_eamil);
	
	
	@Query(value="SELECT * FROM jobs where job_type in ('transfer_in', 'transfer_out')  and status != 'created' and jobs.surveyor_eamil= :surveyor_eamil", nativeQuery=true)
	List<Job> getTransferJobsSurveyor(@Param("surveyor_eamil") String surveyor_eamil);
	

	Job findByStemNo(String stemNo);
	Job findByPurchaseOrderNo(String purchaseNo);
	Job findByPurchaseOrderNoAndBargeName(String purchaseNo,String bargeName);
	Job findByTransferOrderNo(String purchaseNo);
	Job findByTransferOrderNoAndJobType(String purchaseNo, JOBTYPE jobType);

	
	@Modifying
	@Transactional
	@Query(value="UPDATE jobs SET status = ?1, updated_date = ?2, updated_by = ?3 WHERE id = ?4 ", nativeQuery=true)
	void updateStatus(String status, DateTime updatedDate, String updatedBy, Long jobId);

	@Modifying
	@Transactional
	@Query(value="UPDATE jobs SET surveyor_email_send_count = vessel_email_send_count+1  WHERE id = ?1 ", nativeQuery=true)
	void incrementSurveyorEmailSendCount(Long id);

	@Modifying
	@Transactional
	@Query(value="UPDATE jobs SET vessel_email_send_count = vessel_email_send_count+1  WHERE id = ?1 ", nativeQuery=true)
	void incrementVeselEmailSendCount(Long id);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE jobs SET mode= :mode,contigencyRemarks= :contigencyRemarks WHERE id=:jobId",nativeQuery=true)
	void updatemode(@Param("jobId") Long jobId,@Param("mode") int mode,@Param("contigencyRemarks") String contigencyRemarks);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE jobs SET surveyor= :surveyor,cargo_officer= :CO ,chief_engineer= :CE where id =:jobId")
	void updateCEAndCOAndSurveyor(@Param("surveyor") String surveyor,@Param("CE") String CE,@Param("CO") String CO ,@Param("jobId") Long jobId);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE jobs SET sgtradex_publish_status= :sgtradexPublishStatus,sgtradex_publish_error_msg= :sgtradexPublishErrorMsg ,"
			+ "sgtradex_publish_request= :sgtradexPublishRequest,sgtradex_publish_response= :sgtradexPublishResponse where id =:jobId")
	void updateSGTradexStatus(@Param("sgtradexPublishStatus") String sgtradexPublishStatus,@Param("sgtradexPublishErrorMsg") String sgtradexPublishErrorMsg,
			@Param("sgtradexPublishRequest") String sgtradexPublishRequest ,@Param("sgtradexPublishResponse") String sgtradexPublishResponse ,@Param("jobId") Long jobId);
	
	@Modifying
	@Transactional
	@Query(value="UPDATE jobs SET doc_sent_status= :docSentStatus where id =:jobId")
	void updateEmailStatus(@Param("docSentStatus") String docSentStatus,@Param("jobId") Long jobId);
	

	@Query(value = "call st_get_job_validation (?1)",nativeQuery=true)
	List<Object[]> jobValidationChecking(Long jobId);

	@Query(value="select * from jobs Inner join nominations on jobs.id=nominations.job_id where jobs.stem_no= :stemNo and jobs.barge_name=:bargeName and nominations.MPAGrade=:productName", nativeQuery=true)
	Job findByStemNoAndBargeNameAndproductName(@Param("stemNo")String stemNo, @Param("bargeName")String bargeName,@Param("productName") String productName);
	
	@Query(value="select * from jobs Inner join nominations on jobs.id=nominations.job_id where jobs.purchase_order_no= :purchaseOrderNo and jobs.barge_name=:bargeName and nominations.MPAGrade=:productName", nativeQuery=true)
	Job findByPurchaseOrderNoAndBargeNameAndproductName(@Param("purchaseOrderNo")String purchaseOrderNo, @Param("bargeName")String bargeName,@Param("productName") String productName);

	@Query(value ="select grade from nominations where job_id =:jobId order by id desc limit 1",nativeQuery =true)
	String getGrade(@Param("jobId") Long jobId);
	
//	@Query(value="select* from jobs where job_type =?2 and barge_id =?1 and status != 'created' and  jobs.surveyor_eamil= :surveyor_eamil", nativeQuery=true)
//	List<Job> findByJobTypeAndBargeIdAndEmail(@Param("bargeId") Long bargeId,@Param("jobType") String jobType,@Param("surveyor_eamil") String surveyor_eamil);
	
	
	
}
