package com.india.bts.dib.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.MFMSealChecklist;
import com.india.bts.dib.repository.MFMSealChecklistRepository;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.utils.ResponseObject;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class MFMSealChecklistController {
	
	@Autowired
	MFMSealChecklistRepository checkListRepo;
	@Autowired
	CurrentUserService currentUserService;
	
	@RequestMapping(value = Utilities.APP_VERSION
			+Utilities.API_PATH_SEAL_CHECKLIST, method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> add(@RequestBody MFMSealChecklist checklist) {
		try {
			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN", "CARGO OFFICER"})) {
				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
						HttpStatus.FORBIDDEN);
			}
			checklist = checkListRepo.save(checklist);
		} catch (Exception e) {
			log.error("Unable to add MFMSealChecklist", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(checklist, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ Utilities.API_PATH_SEAL_CHECKLIST, method = RequestMethod.PATCH, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> update(@RequestBody MFMSealChecklist checklist) {
		try {
			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN", "CARGO OFFICER"})) {
				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
						HttpStatus.FORBIDDEN);
			}
			checklist = checkListRepo.save(checklist);
		} catch (Exception e) {
			log.error("Unable to add MFMSealChecklist", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(checklist, HttpStatus.OK);
	}
	
	@RequestMapping(value = Utilities.APP_VERSION
			+ Utilities.API_PATH_SEAL_CHECKLIST, method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> modify(@RequestBody MFMSealChecklist checklist) {
		try {
			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN", "CARGO OFFICER"})) {
				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
						HttpStatus.FORBIDDEN);
			}
			checklist = checkListRepo.save(checklist);
		} catch (Exception e) {
			log.error("Unable to add MFMSealChecklist", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(checklist, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ Utilities.API_PATH_SEAL_CHECKLIST+"/{id}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> get(@PathVariable("id") long id) {
		Optional<MFMSealChecklist> checklist = null;
		try {
			checklist = checkListRepo.findById(id);
		} catch (Exception e) {
			log.error("Unable to add MFMSealChecklist", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(checklist.get(), HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION + Utilities.API_PATH_SEAL_CHECKLIST+"/all", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getAll() {
		List<MFMSealChecklist> pages = null;
		try {
			pages = checkListRepo.findAll();
		} catch (Exception e) {
			log.error("Unable to get all MFMSealChecklist, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(pages, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = Utilities.APP_VERSION + Utilities.API_PATH_SEAL_CHECKLIST +"/{id}", method = RequestMethod.DELETE)
	@ResponseBody
	public ResponseEntity<Object> delete(@PathVariable("id") long id) {
		try {
			if(!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[]{"ADMIN", "CARGO OFFICER"})) {
				return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
						HttpStatus.FORBIDDEN);
			}
			checkListRepo.deleteById(id);
		} catch (Exception e) {
			log.error("Unable to delete MFMSealChecklist, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>("Deleted MFMSealChecklist with id:"+ id, HttpStatus.OK);
	}

}
