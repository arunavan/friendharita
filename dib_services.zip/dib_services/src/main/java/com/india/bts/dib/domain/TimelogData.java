package com.india.bts.dib.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@Entity(name="timelog_data") 
public class TimelogData implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6360097131484204213L;
	@ApiModelProperty(notes = "The database generated ID", required = false )
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(nullable=false, name = "job_id", length=20)
	private long jobId;
	
    @Column(name = "time_log_date",  nullable = true)
    String timelogDate;


	@Column(nullable=true, name = "port", length=200)
	private String port;

	@Column(nullable=true, name = "vessel_terminal_name", length=200)
	private String vesselName;
	@Column(nullable=true, name = "location_berth_name", length=200)
	private String locationName;
	@Column(nullable=false, name = "barge_name", length=200)
	private String bunkerTankerName;

	@Column(nullable=true, name = "grade_and_qty", length=200)
	private String gradeAndQty;
	
	
	@OneToMany(mappedBy="timelogChecklist",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private List<TimelogChecklistItems> timeLogItems;

	@Column(nullable=true, name = "cargo_officer_name", length=200)
	private String cargoOfficer;
	@Column(nullable=true, name = "termina_vessel_representative_name", length=200)
	private String terminalOrVesselRepresentative;
	@Column(nullable=true, name = "surveyor_name", length=200)
	private String surveyor;
	
	

	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "cargo_officer_signature_date", columnDefinition="DATETIME", nullable = true)
    LocalDateTime cargoOfficerSignatureDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "chief_engineer_signature_date", columnDefinition="DATETIME", nullable = true)
    LocalDateTime chiefEngineerSignatureDateTime;
	
	@ApiModelProperty(notes ="formate:yyyy-MM-dd HH:mm:ss", required = false, example = "2022-05-25 06:30:22")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") 
    @Column(name = "surveyor_signature_date", columnDefinition="DATETIME", nullable = true)
    LocalDateTime surveyorSignatureDateTime;

	@Column(nullable=true,name="remarks ",columnDefinition = "TEXT")
    private String remarks;

	@Column(nullable = false,name = "has_delay", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean hasDelay;
	
	@Column(nullable = false,name = "has_stoppages", columnDefinition = "TINYINT(1) DEFAULT 1", length = 1)
	private boolean hasStoppages;

	@CreatedDate
	@Column(nullable = false,name = "created_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = false)
	@JsonIgnore
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	private DateTime createdDate;

	@LastModifiedDate
	@Column(nullable = false,name = "updated_date", columnDefinition = "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP", insertable = true, updatable = true)
	@Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
	@JsonIgnore
	private DateTime updatedDate;
	
	@JsonIgnore
	@Column(nullable=true,name = "created_by", length=500)
	private String createdUser;

	@JsonIgnore
	@Column(nullable=true,name = "updated_by", length=500)
	private String updatedUser;
	
	@Lob
	@Column(nullable=true,name="CO_Sign")
	private String cOSign;
	@Lob
	@Column(nullable=true,name="CE_Sign")
	private String cESign;
	public String getcOSign() {
		return cOSign;
	}
	public void setcOSign(String cOSign) {
		this.cOSign = cOSign;
	}
	public String getcESign() {
		return cESign;
	}
	public void setcESign(String cESign) {
		this.cESign = cESign;
	}
	public String getsVSign() {
		return sVSign;
	}
	public void setsVSign(String sVSign) {
		this.sVSign = sVSign;
	}
	@Lob
	@Column(nullable=true,name="SV_Sign")
	private String sVSign;
	
	
	@Lob
	@Column(nullable=true,name="timelog_file_binary")
	private String timelogFileBinary;

}
