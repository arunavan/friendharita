package com.india.bts.dib.domain;

public enum UomType {
	
	MT,
	IMPERIAL,

}
