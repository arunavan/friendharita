package com.india.bts.dib.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.JOBTYPE;
import com.india.bts.dib.domain.MeterTotaliserLog;
import com.india.bts.dib.repository.MeterTotaliserLogRepository;
import com.india.bts.dib.security.CurrentUserService;
import com.india.bts.dib.utils.ResponseObject;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class MeterTotaliserLogController {

	@Autowired
	MeterTotaliserLogRepository repo;
	@Autowired
	CurrentUserService currentUserService;

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/meter-log", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> add(@RequestBody MeterTotaliserLog meterLog) {
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "CARGO OFFICER" })) {
//					if (!currentUserService.getCurrentUser().getBargeId()
//							.equals(meterLog.getBargeId())) {
//						return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//								HttpStatus.FORBIDDEN);
//					}
//				} else {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);	
//				
//				}
//			}
			meterLog = repo.save(meterLog);
		} catch (Exception e) {
			log.error("Unable to add location", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(meterLog, HttpStatus.OK);
	}

	@RequestMapping(value = Utilities.APP_VERSION
			+ "/meter-log", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<Object> update(@RequestBody MeterTotaliserLog meterLog) {
		try {
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "CARGO OFFICER" })) {
//					if (!currentUserService.getCurrentUser().getBargeId()
//							.equals(meterLog.getBargeId())) {
//						return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//								HttpStatus.FORBIDDEN);
//					}
//				} else {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);	
//				
//				}
//			}
			meterLog = repo.save(meterLog);
		} catch (Exception e) {
			log.error("Unable to add location", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(meterLog, HttpStatus.OK);
	}

	
	@RequestMapping(value = Utilities.APP_VERSION + "/meter-log/{bargeId}/{year}/{month}", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Object> getALLByBargeId(@PathVariable("bargeId") long bargeId, @PathVariable("year") int year, @PathVariable("month") String month) {
		List<MeterTotaliserLog> meterLogs = new ArrayList<MeterTotaliserLog>();
		log.info ("received req params: month:" + month);
		LocalDate currentDate = LocalDate.now();
		String currentMonth = currentDate.getMonth().name();
		log.info ("currentMonth:" + currentMonth);
		try {
			
//			if (!Utilities.checkAuthorization(currentUserService.getCurrentUser(), new String[] { "ADMIN" })) {
//				if (!currentUserService.getCurrentUser().getBargeId().equals(bargeId)) {
//					return new ResponseEntity<Object>(new ResponseObject(403, "Access Denied", null, false),
//							HttpStatus.FORBIDDEN);
//				}
//			}
			
			List<MeterTotaliserLog> tempLogs =null;
			if(bargeId == 0) {
				tempLogs = repo.findAll();
			}else {
				tempLogs = repo.findByBargeId(bargeId);
			}
			
			if(month.equalsIgnoreCase("All Months")) {
				meterLogs = tempLogs.stream().filter(tempLog -> tempLog.getLogDateTime().getYear() == year ).collect(Collectors.toList());
			}else {
				meterLogs = tempLogs.stream().filter(tempLog -> tempLog.getLogDateTime().getMonth().name().equals(month) 
						&& tempLog.getLogDateTime().getYear() == year ).collect(Collectors.toList());
			}

		} catch (Exception e) {
			log.error("Unable to delete location, ", e);
			return new ResponseEntity<Object>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Object>(meterLogs, HttpStatus.OK);
	}

}
