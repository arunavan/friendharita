package com.india.bts.dib.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import javax.persistence.Column;

import lombok.Data;

@Data
public class BunkerDeliveryReport implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//private Long id;
	private String bunkerTankerLicenceNo;
	private String bunkerTankerName; 
	private String bunkerMeteringTicketNo;
	private String fuelTypeCode;
	private String operationDate;
	private String totalisersAutoPopulated;
	private String reasonNotAutoPopulated;
	private String bunkerSupplierName;
	private String bunkerSupplierUEN;
	private String bdnNo;
	private BigDecimal startDeliveryMeterTotaliser;
	private BigDecimal startLoadingMeterTotaliser;
	private BigDecimal endDeliveryMeterTotaliser;
	private BigDecimal endLoadingMeterTotaliser;
	private String receiveVesselName;
	private String receiveVesselImoNo;
	private BigDecimal receiveVesselGst;
	private String deliveryLocationCode;
	private String deliveryLocationName;
	private int deliveryType;
	private String supplyType;
	private BigDecimal suppliedQuantityMFM;
	private BigDecimal suppliedQuantityBDN;
	private String commencePumpingTime;
	private String completePumpingTime;
	private String alongsideTime;
	private String castOffTime;
	private String durationOfDelivery;
	private int customerRating;
	private String protestNote;
	private String vendorUen;
	
	private List<HashMap<String,Object>> attachments ;

}
