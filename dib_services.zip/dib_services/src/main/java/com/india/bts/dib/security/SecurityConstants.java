/*******************************************************************************
 * BTS INDIA COPYRIGHT
 *  _________________________
 *    
 *  [2019] - [2021] BTS IT Solutions India Pvt. Ltd.
 *  All Rights Reserved.
 *    
 *  NOTICE:  All information contained herein is, and remains
 *  the property of BTS IT Solutions India Pvt. Ltd. and its suppliers,
 *  if any.  The intellectual and technical concepts contained
 *  herein are proprietary to BTS IT Solutions India Pvt. Ltd.
 *  and its suppliers and are protected by trade secret or copyright law.
 *  Dissemination of this information or reproduction of this material
 *  is strictly forbidden unless prior written permission is obtained
 *  from BTS IT Solutions India Pvt. Ltd.
 ******************************************************************************/
package com.india.bts.dib.security;

public class SecurityConstants {

	public static final String SECRET = "2h9vqSHLcLaAUrOElyReHVrfmoiqU0acuw6BaWFY-QY8ulRRcaxigfDwSFUtkAgF0jjiz9yfAcPsQ8CemEuK26lKE2Co-Og3vuceMr5PKH7Z_JzCZ73mzXxjBlfNc2Nn4dvTsAQDv2waBDFrxjuuDQXfp4k2oJl15KHMO4WPLy"; 
	public static final long EXPIRATION_TIME = 864_000_000; // 10 days
	public static final String TOKEN_PREFIX = "Bearer ";
	public static final String HEADER_STRING = "Authorization";
	public static final String HEADER_VESSEL_IMO = "vimo";
	public static final String HEADER_VESSEL_NAME = "vnm";
	public static final String SIGN_UP_URL = "/api/v1/demo-sign-up";
	public static final String SIGN_IN_URL = "/api/v1/sign-in";
	
	public static final String HEADER_EMAIL = "email";
	public static final String HEADER_PASSWORD = "password";

}
