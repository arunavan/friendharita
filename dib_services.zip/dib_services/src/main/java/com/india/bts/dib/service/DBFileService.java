package com.india.bts.dib.service;

import java.util.List;

import com.india.bts.dib.domain.File;

public interface DBFileService  {
		
	public abstract File save(File job);
	public abstract List<File> findByJobId(Long jobId);
	public abstract List<File> findByJobIdAndDocumentType(Long jobId, String documentType);


	
}
