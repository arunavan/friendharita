package com.india.bts.dib.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.india.bts.dib.domain.GradeItems;

public interface GradeItemsRepository  extends JpaRepository<GradeItems, Long> {
	
	Set<GradeItems> findByBunkerSafetyChecklistItemsId(long id);
}
