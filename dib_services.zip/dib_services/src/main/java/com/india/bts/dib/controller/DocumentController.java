package com.india.bts.dib.controller;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Base64;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.india.bts.dib.domain.Attachment;
import com.india.bts.dib.domain.BDNData;
import com.india.bts.dib.domain.BunkerRequisitionData;
import com.india.bts.dib.domain.BunkerSafetyChecklistData;
import com.india.bts.dib.domain.CargoLoadingData;
import com.india.bts.dib.domain.File;
import com.india.bts.dib.domain.MFMReadingData;
import com.india.bts.dib.domain.MFMSealsChecklistData;
import com.india.bts.dib.domain.NOPData;
import com.india.bts.dib.domain.Reports;
import com.india.bts.dib.domain.Sof;
import com.india.bts.dib.domain.TimelogData;
import com.india.bts.dib.repository.AttachmentRepository;
import com.india.bts.dib.repository.DBFileRepository;
import com.india.bts.dib.repository.ReportsRepository;
import com.india.bts.dib.service.AsynServices;
import com.india.bts.dib.service.DBFileServiceImpl;
import com.india.bts.dib.service.FileStorageService;
import com.india.bts.dib.service.JobServiceImpl;
import com.india.bts.dib.utils.Utilities;

import lombok.extern.slf4j.Slf4j;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

@RestController
@Slf4j
public class DocumentController {
	
	@Autowired
	JobServiceImpl jobService;
	@Autowired
	FileStorageService fileService;
	@Autowired
	AttachmentRepository attachmentRepository;
	@Autowired
	AsynServices asynServices;
	
	@Autowired
	DBFileServiceImpl dbFileService;
	
	@Autowired 
	ReportsRepository reportsRepository;
	
	@Autowired
	DBFileRepository dbFileRepository;
//	@RequestMapping(value = Utilities.APP_VERSION + "/View/{printName}/{jobId}", method = RequestMethod.GET)
//	@ResponseBody
//    public ResponseEntity<?> viewBDNDocument(@PathVariable("jobId") Long jobId,HttpServletResponse response,
//    		HttpServletRequest request,@PathVariable("printName") String printName) throws Exception {
//    	
//		HttpHeaders httpHeaders = new HttpHeaders();
//		byte[] bytes = null;
//		String targetPath="";
//		Resource fileResource=null;
//		String contentType = null;
//		String strAttachment = "";
//		String strDownloadType ="";
//		String reportPath ="";
//		String subReportPath = "";
//		String reqSubreport = "";
//		byte[] dataList = null;
//		String folderName="";
//		File MFMTicket = new File();
////		 byte[] input_file = Files.readAllBytes(Paths.get("C:\\EBDN\\Documents\\2023\\21\\Bunker DeliveryNote.pdf"));
////		 byte[] encodedBytes = Base64.getEncoder().encode(input_file);
////	        String encodedString =  new String(encodedBytes);
////	        
////	        System.out.print(encodedString);
////	        
//
//		
//		try {
//			if(printName.equals("ebdn")) {
//				BDNData bdnData = jobService.getBDNData(jobId);
//				// common attachment table implemented to increase the performance and integrated with ibms
//				//Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
//				//bytes = Base64.getDecoder().decode(bdnData.getBdnFileBinary());
//				bytes = Base64.getDecoder().decode(bdnData.getBdnFileBinary());
//				folderName ="Bunker DeliveryNote.pdf";
//			}else if(printName.equals("breq")) {
//				//BunkerRequisitionData reqData = jobService.getBunkerRequisition(jobId);
//				Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
//				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
//				folderName="Bunker Requisition.pdf";
//				
//			}else if(printName.equals("safety")) {
//				//BunkerSafetyChecklistData bunkerSafetyChecklistData = jobService.getBunkerSafetyChecklist(jobId);
//				Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
//				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
//				folderName="Bunker Safety Checklist.pdf";
//			}else if(printName.equals("mfm")) {
//				//MFMReadingData mfmData = jobService.getMFMReadingData(jobId);
//				Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
//				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
//				folderName="MFM Meter Reading.pdf";
//			}else if (printName.equals("seals")) {
//				//MFMSealsChecklistData mfmSealsChecklistData = jobService.getMFMSealsChecklist(jobId);
//				Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
//				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
//				folderName="MFM Seals Checklist.pdf";
//			}else if (printName.equals("nop")) {
//				//NOPData bdnData = jobService.getNOPData(jobId);
//				Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
//				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
//				folderName="Note of Protest.pdf";
//			}else if(printName.equals("meterticket")) {
//				MFMTicket = dbFileRepository.getLatestMeterTicket(jobId);
//				bytes = Base64.getDecoder().decode(MFMTicket.getContent());
//				folderName=MFMTicket.getFileName();
//			}else if (printName.equals("cargoloading")) {
//				//CargoLoadingData bdnData = jobService.getCargoLoadingData(jobId);
//				Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
//				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
//				folderName="CargoLoading.pdf";
//			}else if (printName.equals("timelog")) {
//				//TimelogData	timelogData = jobService.getTimelogData(jobId);
//				Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
//				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
//				folderName="TimeLog.pdf";
//			}else if (printName.equals("sof")) {
//				//Sof sofData = jobService.getSOFData(jobId);
//				Reports data =reportsRepository.findByJobIdAndReportName(jobId, printName);
//				bytes = Base64.getDecoder().decode(data.getReportFileBinary());
//				folderName="SOF.pdf";
//			}else {
//				Optional<Attachment> dto =attachmentRepository.findById(Long.parseLong(printName));
//				if(FilenameUtils.getExtension(dto.get().getFileName()).equals("pdf")) {
//					bytes = Base64.getDecoder().decode(dto.get().getContent().substring(28));
//				}else if(FilenameUtils.getExtension(dto.get().getFileName()).equals("jfif")||FilenameUtils.getExtension(dto.get().getFileName()).equals("jpeg")
//						||FilenameUtils.getExtension(dto.get().getFileName()).equals("jpg")) {
//					bytes = Base64.getDecoder().decode(dto.get().getContent().substring(23));
//				}
//				
//				folderName =dto.get().getFileName();
//				
//			}
//			
//		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
//		buffer.write(bytes);
//		targetPath =fileService.storeFile(folderName, buffer,jobId);
//		asynServices.compressPdf(targetPath);
//		fileResource=fileService.loadFileAsResource(targetPath);
//		
//		
//		try {
//			contentType = request.getServletContext().getMimeType(fileResource.getFile().getAbsolutePath());
//			// Fallback to the default content type if type could not be determined
//			if (contentType == null) {
//				contentType = "application/octet-stream";
//			}
//		} catch (IOException ex) {
//			log.info("Could not determine file type.");
//		}
//		strAttachment = "  filename=\"" + fileResource.getFilename() + "\"";
//		if(strDownloadType.equalsIgnoreCase("attachment")) {
//			strAttachment = " attachment; filename=\"" + fileResource.getFilename() + "\"";
//		}
//		return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType))
//				.header(HttpHeaders.CONTENT_DISPOSITION, strAttachment)
//				.contentLength(fileResource.contentLength())
//	            .lastModified(fileResource.lastModified())
//				.body(fileResource);
//   }catch(Exception ex) {
//	   return ResponseEntity.status(200).body("Unable to print Report with binary data : "+ex.getMessage());
//   }
//
//}
	@Value("${file.upload}")
	private String fileupload ;
	@RequestMapping(value = Utilities.APP_VERSION + "/View/{printName}/{jobId}", method = RequestMethod.GET)
	@ResponseBody
    public ResponseEntity<?> viewBDNDocument(@PathVariable("jobId") Long jobId,HttpServletResponse response,
    		HttpServletRequest request,@PathVariable("printName") String printName) throws Exception {
    	
		HttpHeaders httpHeaders = new HttpHeaders();
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		byte[] bytes = null;
		String targetPath="";
		Resource fileResource=null;
		String contentType = null;
		String strAttachment = "";
		String strDownloadType ="";
		String reportPath ="";
		byte[] dataList = null;
		String folderName="";
		File MFMTicket = new File();	
		try {
			Calendar cal = Calendar.getInstance();
			if(printName.equals("ebdn")) {
				BDNData bdnData = jobService.getBDNData(jobId);
				bytes = Base64.getDecoder().decode(bdnData.getBdnFileBinary());
				buffer.write(bytes);
				folderName ="Bunker DeliveryNote.pdf";
				targetPath =fileService.storeFile(folderName, buffer,jobId);
			}else if(printName.equals("breq")) {
				folderName="Bunker Requisition.pdf";	
			}else if(printName.equals("safety")) {
				folderName="Bunker Safety Checklist.pdf";
			}else if(printName.equals("mfm")) {
				folderName="MFM Meter Reading.pdf";
			}else if (printName.equals("seals")) {
				folderName="MFM Seals Checklist.pdf";
			}else if (printName.equals("nop")) {
				folderName="Note of Protest.pdf";
			}else if(printName.equals("meterticket")) {
				MFMTicket = dbFileRepository.getLatestMeterTicket(jobId);
				if(MFMTicket != null) {
					bytes = Base64.getDecoder().decode(MFMTicket.getContent());
					buffer.write(bytes);
					targetPath =fileService.storeFile(MFMTicket.getFileName(), buffer,jobId);
					folderName=MFMTicket.getFileName();
				}
			}else if (printName.equals("cargoloading")) {
				folderName="CargoLoading.pdf";
			}else if (printName.equals("timelog")) {
				folderName="TimeLog.pdf";
			}else if (printName.equals("sof")) {
				folderName="SOF.pdf";
			}else {
				Optional<Attachment> dto =attachmentRepository.findById(Long.parseLong(printName));
				if(FilenameUtils.getExtension(dto.get().getFileName()).equals("pdf")) {
					bytes = Base64.getDecoder().decode(dto.get().getContent().substring(28));
				}else if(FilenameUtils.getExtension(dto.get().getFileName()).equals("jfif")||FilenameUtils.getExtension(dto.get().getFileName()).equals("jpeg")
						||FilenameUtils.getExtension(dto.get().getFileName()).equals("jpg")) {
					bytes = Base64.getDecoder().decode(dto.get().getContent().substring(23));
				}
				folderName =dto.get().getFileName();
				targetPath =fileService.storeFile(folderName, buffer,jobId);
			}		
		Path filePath = Paths.get(fileupload+"\\"+cal.get(Calendar.YEAR)+"\\"+jobId+"\\"+folderName);
		fileResource=fileService.loadFileAsResource(filePath.toString());	
		try {
			contentType = request.getServletContext().getMimeType(fileResource.getFile().getAbsolutePath());
			// Fallback to the default content type if type could not be determined
			if (contentType == null) {
				contentType = "application/octet-stream";
			}
		} catch (IOException ex) {
			log.info("Could not determine file type.");
		}
		strAttachment = "  filename=\"" + fileResource.getFilename() + "\"";
		if(strDownloadType.equalsIgnoreCase("attachment")) {
			strAttachment = " attachment; filename=\"" + fileResource.getFilename() + "\"";
		}
		return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType))
				.header(HttpHeaders.CONTENT_DISPOSITION, strAttachment)
				.contentLength(fileResource.contentLength())
	            .lastModified(fileResource.lastModified())
				.body(fileResource);
   }catch(Exception ex) {
	   return ResponseEntity.status(200).body("Unable to print Report with binary data : "+ex.getMessage());
   }

}

	@Value("${template.path}")
	private String templatePath ;
	
	@Value("${spring.datasource.url}")
	private String Url;
	@Value("${spring.datasource.username}")
	private String userName;
	@Value("${spring.datasource.password}")
	private String password;
	@RequestMapping(value = Utilities.APP_VERSION + "/Print/{printName}/{job_id}", method = RequestMethod.GET)
	@ResponseBody                                  
public ResponseEntity<?> AllFormPrint(@PathVariable("job_id") Long job_id,HttpServletResponse response,@PathVariable("printName") String printName,HttpServletRequest request) throws Exception {
		
		HttpHeaders header = new HttpHeaders();
		String targetPath="";
		Resource fileResource=null;
		String contentType = null;
		String strAttachment = "";
		String strDownloadType ="";
		String reportPath ="";
		byte[] dataList = null;
		String Header ="";
		//String subReportPath = "";
		
		try {
			 Connection con = DriverManager.getConnection(Url, userName, password);
		if(printName.equals("breq")) {
			reportPath=templatePath+"/BunkerReq.jrxml";
		}else if(printName.equals("safety")) {
			reportPath=templatePath+"/Safety_Checklist.jrxml";
		}else if(printName.equals("seals")) {
			reportPath=templatePath+"/Seals_Checklist.jrxml";
		}else if(printName.equals("ebdn")) {
			reportPath=templatePath+"/BDNData.jrxml";
		}else if(printName.equals("mfm")) {
			reportPath=templatePath+"/MFMReading.jrxml";
		}
			//subReportPath=templatePath+"/HeaderReport.jasper"; 
	 		Map<String, Object> parameters = new HashMap<>();
			parameters.put("job_id",job_id);		
			JasperReport compileReport = JasperCompileManager
					.compileReport(new FileInputStream(reportPath));
			JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, parameters,con);
			dataList = JasperExportManager.exportReportToPdf(jasperPrint);
			header.setContentType(MediaType.APPLICATION_PDF);
			header.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=requisition.pdf");
			ByteArrayOutputStream buffer = new ByteArrayOutputStream();
			buffer.write(dataList);
			if(printName.equals("breq")) {
				targetPath =fileService.storeFile("Bunker Requisition.pdf",buffer,job_id);
			}else if(printName.equals("safety")) {
				targetPath =fileService.storeFile("Bunker Safety Checklist.pdf",buffer,job_id);
			}else if(printName.equals("seals")) {
				targetPath =fileService.storeFile("MFM Seals Checklist.pdf",buffer,job_id);
			}else if(printName.equals("ebdn")) {
				targetPath =fileService.storeFile("Bunker DeliveryNote.pdf",buffer,job_id);
			}else if(printName.equals("mfm")) {
				targetPath =fileService.storeFile("MFM Meter Reading.pdf",buffer,job_id);
			}
			//targetPath =fileService.storeFile("breq",buffer,job_id);
			fileResource=fileService.loadFileAsResource(targetPath);
			
			try {
				contentType = request.getServletContext().getMimeType(fileResource.getFile().getAbsolutePath());
				// Fallback to the default content type if type could not be determined
				if (contentType == null) {
					contentType = "application/octet-stream";
				}
			} catch (IOException ex) {
				 throw ex;
			}
			strAttachment = "  filename=\"" + fileResource.getFilename() + "\"";
			if(strDownloadType.equalsIgnoreCase("attachment")) {
				strAttachment = " attachment; filename=\"" + fileResource.getFilename() + "\"";
			}
			return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType))
					.header(HttpHeaders.CONTENT_DISPOSITION, strAttachment)
					.contentLength(fileResource.contentLength())
		            .lastModified(fileResource.lastModified())
					.body(fileResource);

		} catch (Exception ex) {
			return ResponseEntity.status(500).headers(header).body("Unable to print Requisition Report: "+ex.getMessage());
		}
	
	}

	public String generateBinaryData(Long job_id,String reportPath) throws Exception {
		byte[] dataList = null;
		try {
		 Connection con = DriverManager.getConnection(Url, userName, password);
		Map<String, Object> parameters = new HashMap<>();
		parameters.put("job_id",job_id);		
		JasperReport compileReport = JasperCompileManager
				.compileReport(new FileInputStream(reportPath));
		JasperPrint jasperPrint = JasperFillManager.fillReport(compileReport, parameters,con);
		dataList = JasperExportManager.exportReportToPdf(jasperPrint);
		String encodedString = Base64.getEncoder().encodeToString(dataList);
		return encodedString;
		}catch (Exception ex) {
			throw ex;
		}

	}
	

	
}
