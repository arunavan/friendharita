package com.india.bts.dib.domain;

public enum JOBTYPE {
	
	//"Loading, Delivery, Ship-To-Ship"
	
	loading,
	delivery,
	transfer,
	transfer_in,
	transfer_out,

}
