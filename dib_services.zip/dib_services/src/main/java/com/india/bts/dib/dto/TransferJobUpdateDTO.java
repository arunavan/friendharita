package com.india.bts.dib.dto;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.india.bts.dib.domain.JOBTYPE;
import com.india.bts.dib.domain.StatusType;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
public class TransferJobUpdateDTO {
	
	private long id;

	
	@ApiModelProperty(notes = "specify the jobtype", required = true, example = "loading, delivery, transfer")
	@Enumerated(EnumType.STRING)
    private JOBTYPE jobType;
	
	@Enumerated(EnumType.STRING)
    private StatusType status;
	
	private TransferOrderDTO transferOrder;

}
